<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>AbstractWidgetList</name>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/abstract_widget_list.cpp" line="67"/>
        <source>Add New</source>
        <translation>Añadir Nuevo</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/abstract_widget_list.cpp" line="118"/>
        <source>Move Up</source>
        <translation>Subir</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/abstract_widget_list.cpp" line="119"/>
        <source>Move Down</source>
        <translation>Bajar</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/abstract_widget_list.cpp" line="120"/>
        <source>Remove</source>
        <translation>Eliminar</translation>
    </message>
</context>
<context>
    <name>AcceptTool</name>
    <message>
        <location filename="../../src/tools/accept/accepttool.cpp" line="31"/>
        <source>Accept</source>
        <translation>Aceptar</translation>
    </message>
    <message>
        <location filename="../../src/tools/accept/accepttool.cpp" line="41"/>
        <source>Accept the capture</source>
        <translation>Aceptar la captura</translation>
    </message>
</context>
<context>
    <name>AppLauncher</name>
    <message>
        <location filename="../../src/tools/launcher/applaunchertool.cpp" line="23"/>
        <source>App Launcher</source>
        <translation>Lanzador de Aplicaciones</translation>
    </message>
    <message>
        <location filename="../../src/tools/launcher/applaunchertool.cpp" line="33"/>
        <source>Choose an app to open the capture</source>
        <translation>Elige una aplicación con la que abrir la captura</translation>
    </message>
</context>
<context>
    <name>AppLauncherWidget</name>
    <message>
        <location filename="../../src/tools/launcher/applauncherwidget.cpp" line="43"/>
        <source>Open With</source>
        <translation>Abrir Con</translation>
    </message>
    <message>
        <location filename="../../src/tools/launcher/applauncherwidget.cpp" line="58"/>
        <source>Launch in terminal</source>
        <translation>Lanzar en terminal</translation>
    </message>
    <message>
        <location filename="../../src/tools/launcher/applauncherwidget.cpp" line="59"/>
        <source>Keep open after selection</source>
        <translation>Mantener abierto tras la selección</translation>
    </message>
    <message>
        <location filename="../../src/tools/launcher/applauncherwidget.cpp" line="95"/>
        <location filename="../../src/tools/launcher/applauncherwidget.cpp" line="110"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../../src/tools/launcher/applauncherwidget.cpp" line="95"/>
        <source>Unable to write in</source>
        <translation>Imposible escribir en</translation>
    </message>
    <message>
        <location filename="../../src/tools/launcher/applauncherwidget.cpp" line="110"/>
        <source>Unable to launch in terminal.</source>
        <translation>Imposible lanzar en terminal.</translation>
    </message>
</context>
<context>
    <name>ArrowTool</name>
    <message>
        <location filename="../../src/tools/arrow/arrowtool.cpp" line="72"/>
        <source>Arrow</source>
        <translation>Flecha</translation>
    </message>
    <message>
        <location filename="../../src/tools/arrow/arrowtool.cpp" line="82"/>
        <source>Set the Arrow as the paint tool</source>
        <translation>Establecer la Flecha como la herramienta de dibujo</translation>
    </message>
</context>
<context>
    <name>BlurTool</name>
    <message>
        <source>Blur</source>
        <translation type="vanished">Desenfoque</translation>
    </message>
    <message>
        <source>Set Blur as the paint tool</source>
        <translation type="vanished">Establece el Desenfoque como herramienta de dibujo</translation>
    </message>
</context>
<context>
    <name>CaptureLauncher</name>
    <message>
        <source>&lt;b&gt;Capture Mode&lt;/b&gt;</source>
        <translation type="vanished">&lt;b&gt;Modo de captura&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.cpp" line="31"/>
        <source>Rectangular Region</source>
        <translation>Región rectangular</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.cpp" line="37"/>
        <source>Full Screen (Current Display)</source>
        <translation>Pantalla Completa (Monitor Actual)</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.cpp" line="40"/>
        <source>Full Screen (All Monitors)</source>
        <translation>Pantalla Completa (Todos los monitores)</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.cpp" line="43"/>
        <source>No Delay</source>
        <translation>Sin demora</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.cpp" line="51"/>
        <source> second</source>
        <translation> segundo</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.ui" line="75"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_capturelauncher.h" line="125"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_capturelauncher.h" line="125"/>
        <location filename="../../src/widgets/capturelauncher.cpp" line="51"/>
        <source> seconds</source>
        <translation> segundos</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.ui" line="96"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_capturelauncher.h" line="126"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_capturelauncher.h" line="126"/>
        <source>Take new screenshot</source>
        <translation>Tomar nueva captura de pantalla</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.ui" line="54"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_capturelauncher.h" line="122"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_capturelauncher.h" line="122"/>
        <source>Area:</source>
        <translation>Área:</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.ui" line="14"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_capturelauncher.h" line="119"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_capturelauncher.h" line="119"/>
        <source>Capture Launcher</source>
        <translation>Capturar Lanzador</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.ui" line="22"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_capturelauncher.h" line="120"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_capturelauncher.h" line="120"/>
        <source>TextLabel</source>
        <translation>Etiqueta de texto</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.ui" line="39"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_capturelauncher.h" line="121"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_capturelauncher.h" line="121"/>
        <source>Capture Mode</source>
        <translation>Modo de Captura</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.ui" line="61"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_capturelauncher.h" line="123"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_capturelauncher.h" line="123"/>
        <source>Delay:</source>
        <translation>Demora:</translation>
    </message>
</context>
<context>
    <name>CaptureWidget</name>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="105"/>
        <source>Unable to capture screen</source>
        <translation>Imposible capturar la pantalla</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="378"/>
        <source>Mouse</source>
        <translation>Mouse</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="378"/>
        <source>Select screenshot area</source>
        <translation>Seleccionar área de captura de pantalla</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="393"/>
        <source>Mouse Wheel</source>
        <translation>Rueda del Ratón</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="393"/>
        <source>Change tool size</source>
        <translation>Cambiar tamaño de la herramienta</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="394"/>
        <source>Right Click</source>
        <translation>Clic Derecho</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="394"/>
        <source>Show color picker</source>
        <translation>Mostrar el selector de color</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="396"/>
        <source>Open side panel</source>
        <translation>Abrir panel lateral</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="397"/>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="397"/>
        <source>Exit</source>
        <translation>Salir</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="505"/>
        <source>Flameshot has lost focus. Keyboard shortcuts won&apos;t work until you click somewhere.</source>
        <translation>Flameshot ha perdido el foco. Los atajos de teclado no funcionarán a menos de que hagas clic en alguna parte.</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="511"/>
        <source>Configuration error resolved. Launch `flameshot gui` again to apply it.</source>
        <translation>Error de configuración resuelto. Lanza `flameshot gui` de nuevo para aplicarlo.</translation>
    </message>
    <message>
        <source>Select an area with the mouse, or press Esc to exit.
Press Enter to capture the screen.
Press Right Click to show the color picker.
Use the Mouse Wheel to change the thickness of your tool.
Press Space to open the side panel.</source>
        <translation type="vanished">Selecciona un área con el ratón, o presiona Esc para salir.
Presiona Enter para capturar la pantalla.
Presion Click Derecho para mostrar el selector de color.
Usa la rueda del ratón para cambiar el grosor de la herramienta.
Presiona Espacio para abrir el panel lateral.</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="949"/>
        <source>Tool Settings</source>
        <translation>Ajustes de herramienta</translation>
    </message>
</context>
<context>
    <name>CircleCountTool</name>
    <message>
        <location filename="../../src/tools/circlecount/circlecounttool.cpp" line="57"/>
        <source>Circle Counter</source>
        <translation>Contador Circular</translation>
    </message>
    <message>
        <location filename="../../src/tools/circlecount/circlecounttool.cpp" line="75"/>
        <source>Add an autoincrementing counter bubble</source>
        <translation>Añadir una burbuja contadora de incremento automático</translation>
    </message>
</context>
<context>
    <name>CircleTool</name>
    <message>
        <location filename="../../src/tools/circle/circletool.cpp" line="20"/>
        <source>Circle</source>
        <translation>Círculo</translation>
    </message>
    <message>
        <location filename="../../src/tools/circle/circletool.cpp" line="30"/>
        <source>Set the Circle as the paint tool</source>
        <translation>Establecer el Círculo como la herramienta de dibujo</translation>
    </message>
</context>
<context>
    <name>ColorDialog</name>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_dialog.ui" line="14"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="318"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="318"/>
        <source>Select Color</source>
        <translation>Seleccionar Color</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_dialog.ui" line="55"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="319"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="319"/>
        <source>Saturation</source>
        <translation>Saturación</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_dialog.ui" line="62"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="320"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="320"/>
        <source>Hue</source>
        <translation>Tono</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_dialog.ui" line="79"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="321"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="321"/>
        <source>Hex</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_dialog.ui" line="86"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="322"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="322"/>
        <source>Blue</source>
        <translation>Azul</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_dialog.ui" line="123"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="323"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="323"/>
        <source>Value</source>
        <translation>Valor</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_dialog.ui" line="130"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="324"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="324"/>
        <source>Green</source>
        <translation>Verde</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_dialog.ui" line="137"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="325"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="325"/>
        <source>Alpha</source>
        <translation>Alfa</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_dialog.ui" line="144"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="326"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="326"/>
        <source>Red</source>
        <translation>Rojo</translation>
    </message>
</context>
<context>
    <name>ColorGrabWidget</name>
    <message>
        <location filename="../../src/widgets/panel/colorgrabwidget.cpp" line="58"/>
        <source>Accept color</source>
        <translation>Aceptar color</translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/colorgrabwidget.cpp" line="59"/>
        <source>Precisely select color</source>
        <translation>Seleccionar color precisamente</translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/colorgrabwidget.cpp" line="60"/>
        <source>Toggle magnifier</source>
        <translation>Alternar lupa</translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/colorgrabwidget.cpp" line="61"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>ColorPickerEditor</name>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="42"/>
        <source>Select Preset:</source>
        <translation>Seleccionar Preajuste:</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="53"/>
        <source>Select preset using the spinbox</source>
        <translation>Seleccione preestablecido usando el cuadro de número</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="56"/>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="58"/>
        <source>Press button to delete the selected preset</source>
        <translation>Presiona el botón para borrar el preajuste seleccionado</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="72"/>
        <source>Add Preset:</source>
        <translation>Añadir Preajuste:</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="78"/>
        <source>Enter color manually or select it using the color-wheel</source>
        <translation>Ingresa un color manualmente o selecciónalo utilizando la rueda de colores</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="88"/>
        <source>Add</source>
        <translation>Añadir</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="89"/>
        <source>Press button to add preset</source>
        <translation>Presiona el botón para añadir preajuste</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="117"/>
        <location filename="../../src/config/colorpickereditor.cpp" line="137"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="118"/>
        <source>Unable to add preset. Maximum limit reached.</source>
        <translation>No se puede añadir el preajuste. Se ha alcanzado el límite máximo.</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="138"/>
        <source>Unable to remove preset. Minimum limit reached.</source>
        <translation>No se puede borrar el preajuste. Se ha alcanzado el límite mínimo.</translation>
    </message>
</context>
<context>
    <name>ConfigErrorDetails</name>
    <message>
        <location filename="../../src/config/configerrordetails.cpp" line="20"/>
        <source>Configuration errors</source>
        <translation>Errores de configuración</translation>
    </message>
</context>
<context>
    <name>ConfigHandler</name>
    <message>
        <location filename="../../src/utils/confighandler.cpp" line="549"/>
        <source>Unrecognized setting: &apos;%1&apos;
</source>
        <translation>Ajuste no reconocido: &quot;%1&quot;
</translation>
    </message>
    <message>
        <location filename="../../src/utils/confighandler.cpp" line="557"/>
        <source>Unrecognized shortcut name: &apos;%1&apos;.
</source>
        <translation>Nombre de atajo no reconocido: &quot;%1&quot;
</translation>
    </message>
    <message>
        <location filename="../../src/utils/confighandler.cpp" line="600"/>
        <source>Shortcut conflict: &apos;%1&apos; and &apos;%2&apos; have the same shortcut: %3
</source>
        <translation>Conflicto de atajos: &quot;%1&quot; y &quot;%2&quot; tienen el mismo atajo: %3
</translation>
    </message>
    <message>
        <location filename="../../src/utils/confighandler.cpp" line="640"/>
        <source>Bad value in &apos;%1&apos;. Expected: %2
</source>
        <translation>Valor inadecuado en &quot;%1&quot;. Se espera: %2
</translation>
    </message>
    <message>
        <location filename="../../src/utils/confighandler.cpp" line="690"/>
        <source>You have successfully resolved the configuration error.</source>
        <translation>Has resuelto exitosamente el error de configuración.</translation>
    </message>
    <message>
        <location filename="../../src/utils/confighandler.cpp" line="713"/>
        <source>The configuration contains an error. Open configuration to resolve.</source>
        <translation>La configuración contiene un error. Abre la configuración para resolverlo.</translation>
    </message>
    <message>
        <source>The configuration contains an error. Falling back to default.</source>
        <translation type="vanished">La configuración contiene un error. Revirtiendo a la predeterminada.</translation>
    </message>
    <message>
        <location filename="../../src/utils/confighandler.cpp" line="767"/>
        <source>Bad config key &apos;%1&apos; in ConfigHandler. Please report this as a bug.</source>
        <translation>Clave de configuración inadecuada &quot;%1&quot; en ConfigHandler. Por favor, reporta esto como un error.</translation>
    </message>
</context>
<context>
    <name>ConfigResolver</name>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="14"/>
        <source>Resolve configuration errors</source>
        <translation>Resolver errores de configuración</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="50"/>
        <source>&lt;b&gt;You must resolve all errors before continuing:&lt;/b&gt;</source>
        <translation>&lt;b&gt;Debes resolver todos los errores antes de continuar:&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="61"/>
        <source>Reset</source>
        <translation>Reiniciar</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="63"/>
        <source>Reset to the default value.</source>
        <translation>Restablecer al valor por defecto.</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="77"/>
        <source>Remove</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="79"/>
        <source>Remove this setting.</source>
        <translation>Eliminar este ajuste.</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="90"/>
        <source>Some keyboard shortcuts have conflicts.
This will NOT prevent flameshot from starting.
Please solve them manually in the configuration file.</source>
        <translation>Algunos atajos de teclado tienen conflictos.
Esto NO impedirá que Flameshot inicie.
Por favor, resuélvelos manualmente en el archivo de configuración.</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="112"/>
        <source>Resolve all</source>
        <translation>Resolver todo</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="113"/>
        <source>Resolve all listed errors.</source>
        <translation>Resolver todos los errores listados.</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="125"/>
        <source>Details</source>
        <translation>Detalles</translation>
    </message>
</context>
<context>
    <name>ConfigWindow</name>
    <message>
        <location filename="../../src/config/configwindow.cpp" line="42"/>
        <source>Configuration</source>
        <translation>Configuración</translation>
    </message>
    <message>
        <location filename="../../src/config/configwindow.cpp" line="61"/>
        <source>Interface</source>
        <translation>Interfaz</translation>
    </message>
    <message>
        <location filename="../../src/config/configwindow.cpp" line="71"/>
        <source>Filename Editor</source>
        <translation>Editor de Nombre</translation>
    </message>
    <message>
        <location filename="../../src/config/configwindow.cpp" line="80"/>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <location filename="../../src/config/configwindow.cpp" line="89"/>
        <source>Shortcuts</source>
        <translation>Atajos</translation>
    </message>
    <message>
        <location filename="../../src/config/configwindow.cpp" line="122"/>
        <source>Resolve</source>
        <translation>Resolver</translation>
    </message>
    <message>
        <location filename="../../src/config/configwindow.cpp" line="126"/>
        <source>&lt;b&gt;Configuration file has errors. Resolve them before continuing.&lt;/b&gt;</source>
        <translation>&lt;b&gt;El archivo de configuración contiene errores. Resuélvelos antes de continuar.&lt;/b&gt;</translation>
    </message>
</context>
<context>
    <name>Controller</name>
    <message>
        <location filename="../../src/core/controller.cpp" line="217"/>
        <source>New version %1 is available</source>
        <translation>Nueva version %1 está disponible</translation>
    </message>
    <message>
        <location filename="../../src/core/controller.cpp" line="226"/>
        <source>You have the latest version</source>
        <translation>Tienes la última versión</translation>
    </message>
    <message>
        <location filename="../../src/core/controller.cpp" line="234"/>
        <source>Failed to get information about the latest version.</source>
        <translation>No se pudo obtener información sobre la última versión.</translation>
    </message>
    <message>
        <location filename="../../src/core/controller.cpp" line="317"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../../src/core/controller.cpp" line="317"/>
        <source>Unable to close active modal widgets</source>
        <translation>No se pueden cerrar los widgets modales activos</translation>
    </message>
    <message>
        <location filename="../../src/core/controller.cpp" line="463"/>
        <source>&amp;Take Screenshot</source>
        <translation>&amp;Tomar Captura de Pantalla</translation>
    </message>
    <message>
        <location filename="../../src/core/controller.cpp" line="479"/>
        <source>&amp;Open Launcher</source>
        <translation>&amp;Abrir Lanzador</translation>
    </message>
    <message>
        <location filename="../../src/core/controller.cpp" line="484"/>
        <source>&amp;Configuration</source>
        <translation>&amp;Configuración</translation>
    </message>
    <message>
        <location filename="../../src/core/controller.cpp" line="487"/>
        <source>&amp;About</source>
        <translation>&amp;Acerca de</translation>
    </message>
    <message>
        <location filename="../../src/core/controller.cpp" line="490"/>
        <source>Check for updates</source>
        <translation>Buscar actualizaciones</translation>
    </message>
    <message>
        <location filename="../../src/core/controller.cpp" line="497"/>
        <source>&amp;Latest Uploads</source>
        <translation>&amp;Últimas Subidas</translation>
    </message>
    <message>
        <location filename="../../src/core/controller.cpp" line="678"/>
        <source>URL copied to clipboard.</source>
        <translation>URL copiada al portapapeles.</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation type="vanished">&amp;Información</translation>
    </message>
    <message>
        <location filename="../../src/core/controller.cpp" line="493"/>
        <source>&amp;Quit</source>
        <translation>&amp;Salir</translation>
    </message>
</context>
<context>
    <name>CopyTool</name>
    <message>
        <location filename="../../src/tools/copy/copytool.cpp" line="24"/>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <location filename="../../src/tools/copy/copytool.cpp" line="34"/>
        <source>Copy selection to clipboard</source>
        <translation>Copiar selección al portapapeles</translation>
    </message>
    <message>
        <source>Copy the selection into the clipboard</source>
        <translation type="vanished">Copia la selección al portapapeles</translation>
    </message>
</context>
<context>
    <name>DBusUtils</name>
    <message>
        <source>Unable to connect via DBus</source>
        <translation type="vanished">Imposible conectarse mediante DBus</translation>
    </message>
</context>
<context>
    <name>ExitTool</name>
    <message>
        <location filename="../../src/tools/exit/exittool.cpp" line="23"/>
        <source>Exit</source>
        <translation>Salir</translation>
    </message>
    <message>
        <location filename="../../src/tools/exit/exittool.cpp" line="33"/>
        <source>Leave the capture screen</source>
        <translation>Salir de la pantalla de captura</translation>
    </message>
</context>
<context>
    <name>FileNameEditor</name>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="24"/>
        <source>Edit the name of your captures:</source>
        <translation>Edita el nombre de tus capturas:</translation>
    </message>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="28"/>
        <source>Edit:</source>
        <translation>Editar:</translation>
    </message>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="30"/>
        <source>Preview:</source>
        <translation>Previsualización:</translation>
    </message>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="73"/>
        <source>Save</source>
        <translation>Guardar</translation>
    </message>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="76"/>
        <source>Saves the pattern</source>
        <translation>Guarda el patrón</translation>
    </message>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="78"/>
        <source>Restore</source>
        <translation>Restaurar</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="vanished">Reiniciar</translation>
    </message>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="81"/>
        <source>Restores the saved pattern</source>
        <translation>Restaura el patrón guardado</translation>
    </message>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="83"/>
        <source>Clear</source>
        <translation>Limpiar</translation>
    </message>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="89"/>
        <source>Deletes the name</source>
        <translation>Borra el nombre</translation>
    </message>
</context>
<context>
    <name>FlameshotDaemon</name>
    <message>
        <location filename="../../src/core/flameshotdaemon.cpp" line="264"/>
        <source>Unable to connect via DBus</source>
        <translation>No se puede conectar a través de DBus</translation>
    </message>
</context>
<context>
    <name>GeneneralConf</name>
    <message>
        <source>Import</source>
        <translation type="vanished">Importar</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="vanished">Error</translation>
    </message>
    <message>
        <source>Unable to read file.</source>
        <translation type="vanished">Imposible leer el archivo.</translation>
    </message>
    <message>
        <source>Unable to write file.</source>
        <translation type="vanished">Imposible escribir el archivo.</translation>
    </message>
    <message>
        <source>Save File</source>
        <translation type="vanished">Guardar Archivo</translation>
    </message>
    <message>
        <source>Confirm Reset</source>
        <translation type="vanished">Confirmar Reset</translation>
    </message>
    <message>
        <source>Are you sure you want to reset the configuration?</source>
        <translation type="vanished">¿Estás seguro de que quieres reiniciar la configuración?</translation>
    </message>
    <message>
        <source>Show help message</source>
        <translation type="vanished">Mostrar mensaje de ayuda</translation>
    </message>
    <message>
        <source>Show the help message at the beginning in the capture mode.</source>
        <translation type="vanished">Muestra el mensaje de ayuda al iniciar el modo de captura.</translation>
    </message>
    <message>
        <source>Show desktop notifications</source>
        <translation type="vanished">Mostrar notificaciones del escritorio</translation>
    </message>
    <message>
        <source>Show tray icon</source>
        <translation type="vanished">Mostrar icono en la barra de tareas</translation>
    </message>
    <message>
        <source>Show the systemtray icon</source>
        <translation type="vanished">Mostrar el icono en la barra de tareas</translation>
    </message>
    <message>
        <source>Configuration File</source>
        <translation type="vanished">Archivo de Configuración</translation>
    </message>
    <message>
        <source>Export</source>
        <translation type="vanished">Exportar</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="vanished">Reset</translation>
    </message>
    <message>
        <source>Launch at startup</source>
        <translation type="vanished">Lanzar en el arranque</translation>
    </message>
    <message>
        <source>Launch Flameshot</source>
        <translation type="vanished">Lanzar Flameshot</translation>
    </message>
</context>
<context>
    <name>GeneralConf</name>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="149"/>
        <location filename="../../src/config/generalconf.cpp" line="306"/>
        <source>Import</source>
        <translation>Importar</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="156"/>
        <location filename="../../src/config/generalconf.cpp" line="164"/>
        <location filename="../../src/config/generalconf.cpp" line="188"/>
        <location filename="../../src/config/generalconf.cpp" line="626"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="156"/>
        <source>Unable to read file.</source>
        <translation>Imposible leer el archivo.</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="164"/>
        <location filename="../../src/config/generalconf.cpp" line="188"/>
        <source>Unable to write file.</source>
        <translation>Imposible escribir el archivo.</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="175"/>
        <source>Save File</source>
        <translation>Guardar Archivo</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="197"/>
        <source>Confirm Reset</source>
        <translation>Confirmar Reinicio</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="198"/>
        <source>Are you sure you want to reset the configuration?</source>
        <translation>¿Estás seguro de que quieres reiniciar la configuración?</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="229"/>
        <source>Show help message</source>
        <translation>Mostrar mensaje de ayuda</translation>
    </message>
    <message>
        <source>Show the help message at the beginning in the capture mode.</source>
        <translation type="vanished">Muestra el mensaje de ayuda al iniciar el modo de captura.</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="240"/>
        <source>Show the side panel button</source>
        <translation>Mostrar el botón del panel lateral</translation>
    </message>
    <message>
        <source>Show the side panel toggle button in the capture mode.</source>
        <translation type="vanished">Muestra el botón de alternancia del panel lateral en el modo de captura.</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="253"/>
        <source>Show desktop notifications</source>
        <translation>Mostrar notificaciones del escritorio</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="266"/>
        <source>Show tray icon</source>
        <translation>Mostrar icono en la bandeja</translation>
    </message>
    <message>
        <source>Show the systemtray icon</source>
        <translation type="vanished">Mostrar el icono en la bandeja del sistema</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="279"/>
        <source>Confirmation required to delete screenshot from the latest uploads</source>
        <translation>Se requiere confirmación para borrar la captura de pantalla de las últimas subidas</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="294"/>
        <source>Configuration File</source>
        <translation>Archivo de Configuración</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="299"/>
        <source>Export</source>
        <translation>Exportar</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="313"/>
        <source>Reset</source>
        <translation>Reiniciar</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="323"/>
        <source>Automatic check for updates</source>
        <translation>Comprobación automática de actualizaciones</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="336"/>
        <source>Allow multiple flameshot GUI instances simultaneously</source>
        <translation>Permitir múltiples instancias simultáneas del GUI de flameshot</translation>
    </message>
    <message>
        <source>This allows you to take screenshots of flameshot itself for example.</source>
        <translation type="vanished">Esto te permite tomar capturas de pantalla de Flameshot mismo, por ejemplo.</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="349"/>
        <location filename="../../src/config/generalconf.cpp" line="351"/>
        <source>Automatically close daemon when it is not needed</source>
        <translation>Cerrar el daemon automáticamente cuando no se lo necesita</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="361"/>
        <source>Launch at startup</source>
        <translation>Lanzar en el arranque</translation>
    </message>
    <message>
        <source>Launch Flameshot</source>
        <translation type="vanished">Lanzar Flameshot</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="373"/>
        <source>Show welcome message on launch</source>
        <translation>Mostrar mensaje de bienvenida en el lanzamiento</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="388"/>
        <source>Use large predefined color palette</source>
        <translation>Usar una gran paleta de colores predefinida</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="402"/>
        <source>Copy URL after upload</source>
        <translation>Copiar URL después de subir</translation>
    </message>
    <message>
        <source>Copy URL and close window after upload</source>
        <translation type="vanished">Copie la URL y cierre la ventana después de la carga</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="414"/>
        <source>Save image after copy</source>
        <translation>Guardar imagen tras copia</translation>
    </message>
    <message>
        <source>Save image file after copying it</source>
        <translation type="vanished">Guardar archivo de imagen luego de copiarlo</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="230"/>
        <source>Show the help message at the beginning in the capture mode</source>
        <translation>Mostrar el mensaje de ayuda al inicio en el modo de captura</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="242"/>
        <source>Show the side panel toggle button in the capture mode</source>
        <translation>Mostrar el botón de alternancia del panel lateral en el modo de captura</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="254"/>
        <source>Enable desktop notifications</source>
        <translation>Activar notificaciones de escritorio</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="267"/>
        <source>Show icon in the system tray</source>
        <translation>Mostrar icono en la bandeja del sistema</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="282"/>
        <source>Ask for confirmation to delete screenshot from the latest uploads</source>
        <translation>Pedir confirmación para eliminar las capturas de pantalla de las últimas subidas</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="324"/>
        <source>Check for updates automatically</source>
        <translation>Comprobar las actualizaciones automáticamente</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="337"/>
        <source>This allows you to take screenshots of Flameshot itself for example</source>
        <translation>Esto le permite tomar capturas de pantalla de Flameshot mismo, por ejemplo</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="363"/>
        <source>Launch Flameshot daemon when computer is booted</source>
        <translation>Lanzar daemon de Flameshot al iniciar el equipo</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="376"/>
        <source>Show the welcome message box in the middle of the screen while taking a screenshot</source>
        <translation>Mostrar el cuadro de mensaje de bienvenida en el centro de la pantalla mientras se toma una captura de pantalla</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="390"/>
        <source>Use a large predefined color palette</source>
        <translation>Utilice una amplia paleta de colores predefinida</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="404"/>
        <source>Copy URL and close window after uploading was successful</source>
        <translation>Copiar la URL y cerrar la ventana después de que la subida haya sido exitosa</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="416"/>
        <source>After copying the screenshot, save it to a file as well</source>
        <translation>Después de copiar la captura de pantalla, guardarla también en un archivo</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="423"/>
        <source>Save Path</source>
        <translation>Guardar Ubicación</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="439"/>
        <source>Change...</source>
        <translation>Cambiar...</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="447"/>
        <source>Use fixed path for screenshots to save</source>
        <translation>Usar ubicación fija para guardar las capturas</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="459"/>
        <source>Preferred save file extension:</source>
        <translation>Extensión de archivo preferida al guardar:</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="489"/>
        <source>Latest Uploads Max Size</source>
        <translation>Tamaño Máximo de Últimas Subidas</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="516"/>
        <source>Undo limit</source>
        <translation>Límite de deshacer</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="542"/>
        <location filename="../../src/config/generalconf.cpp" line="544"/>
        <source>Use JPG format for clipboard (PNG default)</source>
        <translation>Utilizar el formato JPG para el portapapeles (PNG por defecto)</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="574"/>
        <source>Copy file path after save</source>
        <translation>Copiar ubicación del archivo después de guardar</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="575"/>
        <source>Copy the file path to clipboard after the file is saved</source>
        <translation>Copiar la ruta del archivo al portapapeles luego de guardar el archivo</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="586"/>
        <source>Anti-aliasing image when zoom the pinned image</source>
        <translation>Realizar antialiasing al hacer zoom en la imagen fijada</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="588"/>
        <source>After zooming the pinned image, should the image get smoothened or stay pixelated</source>
        <translation>Después de ampliar la imagen fijada, debería la imagen ser suavizada o permanecer pixelada</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="599"/>
        <location filename="../../src/config/generalconf.cpp" line="601"/>
        <source>Upload image without confirmation</source>
        <translation>Subir imagen sin confirmación</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="617"/>
        <source>Choose a Folder</source>
        <translation>Elegir una carpeta</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="626"/>
        <source>Unable to write to directory.</source>
        <translation>No se puede escribir en el directorio.</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="635"/>
        <source>Show magnifier</source>
        <translation>Mostrar lupa</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="636"/>
        <source>Enable a magnifier while selecting the screenshot area</source>
        <translation>Activar una lupa al seleccionar el área de captura de pantalla</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="647"/>
        <source>Square shaped magnifier</source>
        <translation>Lupa cuadrada</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="648"/>
        <source>Make the magnifier to be square-shaped</source>
        <translation>Hacer que la lupa tenga forma cuadrada</translation>
    </message>
</context>
<context>
    <name>HistoryWidget</name>
    <message>
        <source>Latest Uploads</source>
        <translation type="vanished">Últimas Subidas</translation>
    </message>
    <message>
        <source>Screenshots history is empty</source>
        <translation type="vanished">Historial de capturas vacío</translation>
    </message>
    <message>
        <source>Copy URL</source>
        <translation type="vanished">Copiar URL</translation>
    </message>
    <message>
        <source>URL copied to clipboard.</source>
        <translation type="vanished">URL copiada al portapapeles.</translation>
    </message>
    <message>
        <source>Open in browser</source>
        <translation type="vanished">Abrir en navegador</translation>
    </message>
    <message>
        <source>Confirm to delete</source>
        <translation type="vanished">Confirmar para borrar</translation>
    </message>
    <message>
        <source>Are you sure you want to delete a screenshot from the latest uploads and server?</source>
        <translation type="vanished">¿Estás seguro de que deseas borrar una captura de pantalla de las últimas subidas y el servidor?</translation>
    </message>
</context>
<context>
    <name>ImgS3Uploader</name>
    <message>
        <source>Uploading Image</source>
        <translation type="obsolete">Subiendo Imagen</translation>
    </message>
    <message>
        <source>URL copied to clipboard.</source>
        <translation type="obsolete">URL copiada al portapapeles.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="obsolete">Error</translation>
    </message>
</context>
<context>
    <name>ImgUploadDialog</name>
    <message>
        <location filename="../../src/widgets/imguploaddialog.cpp" line="18"/>
        <source>Upload Confirmation</source>
        <translation>Confirmación de Subida</translation>
    </message>
    <message>
        <location filename="../../src/widgets/imguploaddialog.cpp" line="22"/>
        <source>Do you want to upload this capture?</source>
        <translation>¿Deseas subir esta captura?</translation>
    </message>
    <message>
        <location filename="../../src/widgets/imguploaddialog.cpp" line="35"/>
        <location filename="../../src/widgets/imguploaddialog.cpp" line="36"/>
        <source>Upload without confirmation</source>
        <translation>Subir sin confirmación</translation>
    </message>
</context>
<context>
    <name>ImgUploader</name>
    <message>
        <source>Uploading Image</source>
        <translation type="obsolete">Subiendo Imagen</translation>
    </message>
    <message>
        <source>Unable to open the URL.</source>
        <translation type="obsolete">No puede abrir la URL.</translation>
    </message>
    <message>
        <source>URL copied to clipboard.</source>
        <translation type="obsolete">URL copiada al portapapeles.</translation>
    </message>
    <message>
        <source>Screenshot copied to clipboard.</source>
        <translation type="obsolete">Captura copiada al portapapeles.</translation>
    </message>
    <message>
        <source>Copy URL</source>
        <translation type="obsolete">Copiar URL</translation>
    </message>
    <message>
        <source>Open URL</source>
        <translation type="obsolete">Abrir URL</translation>
    </message>
    <message>
        <source>Delete image</source>
        <translation type="obsolete">Borrar imagen</translation>
    </message>
    <message>
        <source>Image to Clipboard.</source>
        <translation type="obsolete">Imagen al Portapapeles.</translation>
    </message>
</context>
<context>
    <name>ImgUploaderBase</name>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="37"/>
        <source>Upload image</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="51"/>
        <source>Uploading Image</source>
        <translation>Subiendo Imagen</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="130"/>
        <source>Copy URL</source>
        <translation>Copiar URL</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="131"/>
        <source>Open URL</source>
        <translation>Abrir URL</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="132"/>
        <source>Delete image</source>
        <translation>Borrar imagen</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="133"/>
        <source>Image to Clipboard.</source>
        <translation>Imagen al Portapapeles.</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="134"/>
        <source>Save image</source>
        <translation>Guardar imagen</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="164"/>
        <source>Unable to open the URL.</source>
        <translation>No se puede abrir la URL.</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="171"/>
        <source>URL copied to clipboard.</source>
        <translation>URL copiada al portapapeles.</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="177"/>
        <source>Screenshot copied to clipboard.</source>
        <translation>Captura copiada al portapapeles.</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="191"/>
        <source>Unable to save the screenshot to disk.</source>
        <translation>No se puede guardar la captura de pantalla en el disco.</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="194"/>
        <source>Screenshot saved.</source>
        <translation>Captura de pantalla guardada.</translation>
    </message>
</context>
<context>
    <name>ImgUploaderTool</name>
    <message>
        <location filename="../../src/tools/imgupload/imguploadertool.cpp" line="23"/>
        <source>Image Uploader</source>
        <translation>Cargador de Imágenes</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/imguploadertool.cpp" line="33"/>
        <source>Upload the selection</source>
        <translation>Subir la selección</translation>
    </message>
</context>
<context>
    <name>ImgurUploader</name>
    <message>
        <source>Upload to Imgur</source>
        <translation type="vanished">Subir a Imgur</translation>
    </message>
    <message>
        <source>Uploading Image</source>
        <translation type="vanished">Subiendo Imagen</translation>
    </message>
    <message>
        <source>Copy URL</source>
        <translation type="vanished">Copiar URL</translation>
    </message>
    <message>
        <source>Open URL</source>
        <translation type="vanished">Abrir URL</translation>
    </message>
    <message>
        <source>Delete image</source>
        <translation type="vanished">Borrar imagen</translation>
    </message>
    <message>
        <source>Image to Clipboard.</source>
        <translation type="vanished">Imagen al Portapapeles.</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imgur/imguruploader.cpp" line="92"/>
        <source>Unable to open the URL.</source>
        <translation>No se puede abrir la URL.</translation>
    </message>
    <message>
        <source>URL copied to clipboard.</source>
        <translation type="vanished">URL copiada al portapapeles.</translation>
    </message>
    <message>
        <source>Screenshot copied to clipboard.</source>
        <translation type="vanished">Captura copiada al portapapeles.</translation>
    </message>
</context>
<context>
    <name>ImgurUploaderTool</name>
    <message>
        <source>Image Uploader</source>
        <translation type="vanished">Subir Imagen</translation>
    </message>
    <message>
        <source>Upload the selection to Imgur</source>
        <translation type="vanished">Sube la selección a Imgur</translation>
    </message>
</context>
<context>
    <name>InfoWindow</name>
    <message>
        <location filename="../../src/widgets/infowindow.ui" line="14"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_infowindow.h" line="117"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_infowindow.h" line="117"/>
        <source>About</source>
        <translation>Información</translation>
    </message>
    <message>
        <location filename="../../src/widgets/infowindow.ui" line="26"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_infowindow.h" line="118"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_infowindow.h" line="118"/>
        <source>Icon</source>
        <translation>Ícono</translation>
    </message>
    <message>
        <location filename="../../src/widgets/infowindow.ui" line="43"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_infowindow.h" line="119"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_infowindow.h" line="119"/>
        <source>License</source>
        <translation>Licencia</translation>
    </message>
    <message>
        <location filename="../../src/widgets/infowindow.ui" line="56"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_infowindow.h" line="120"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_infowindow.h" line="120"/>
        <source>GPLv3+</source>
        <translation>GPLv3+</translation>
    </message>
    <message>
        <location filename="../../src/widgets/infowindow.ui" line="89"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_infowindow.h" line="121"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_infowindow.h" line="121"/>
        <source>Version</source>
        <translation>Versión</translation>
    </message>
    <message>
        <location filename="../../src/widgets/infowindow.ui" line="102"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_infowindow.h" line="122"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_infowindow.h" line="122"/>
        <source>Flameshot v</source>
        <translation>Flameshot v</translation>
    </message>
    <message>
        <location filename="../../src/widgets/infowindow.ui" line="115"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_infowindow.h" line="123"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_infowindow.h" line="123"/>
        <source>OS Info</source>
        <translation>Información del sistema operativo</translation>
    </message>
    <message>
        <location filename="../../src/widgets/infowindow.ui" line="128"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_infowindow.h" line="124"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_infowindow.h" line="124"/>
        <source>Copy Info</source>
        <translation>Copiar Información</translation>
    </message>
    <message>
        <source>Right Click</source>
        <translation type="vanished">Click Derecho</translation>
    </message>
    <message>
        <source>Mouse Wheel</source>
        <translation type="vanished">Rueda del Ratón</translation>
    </message>
    <message>
        <source>Move selection 1px</source>
        <translation type="vanished">Mover la selección 1px</translation>
    </message>
    <message>
        <source>Resize selection 1px</source>
        <translation type="vanished">Redimensionar la selección 1px</translation>
    </message>
    <message>
        <source>Quit capture</source>
        <translation type="vanished">Salir de la captura</translation>
    </message>
    <message>
        <source>Copy to clipboard</source>
        <translation type="vanished">Copiar al portapapeles</translation>
    </message>
    <message>
        <source>Save selection as a file</source>
        <translation type="vanished">Guardar la selección como un archivo</translation>
    </message>
    <message>
        <source>Undo the last modification</source>
        <translation type="vanished">Deshacer la última modificación</translation>
    </message>
    <message>
        <source>Toggle visibility of sidebar with options of the selected tool</source>
        <translation type="vanished">Alternar la visualización de la barra lateral de opciones de la herramienta seleccionada</translation>
    </message>
    <message>
        <source>Show color picker</source>
        <translation type="vanished">Mostrar el selector de color</translation>
    </message>
    <message>
        <source>Change the tool&apos;s thickness</source>
        <translation type="vanished">Cambiar el grosor de la herramienta</translation>
    </message>
    <message>
        <source>Available shortcuts in the screen capture mode.</source>
        <translation type="vanished">Atajos disponibles en el modo captura de pantalla.</translation>
    </message>
    <message>
        <source>Key</source>
        <translation type="vanished">Tecla</translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="vanished">Descripción</translation>
    </message>
    <message>
        <source>&lt;u&gt;&lt;b&gt;License&lt;/b&gt;&lt;/u&gt;</source>
        <translation type="vanished">&lt;u&gt;&lt;b&gt;Licencia&lt;/b&gt;&lt;/u&gt;</translation>
    </message>
    <message>
        <source>&lt;u&gt;&lt;b&gt;Version&lt;/b&gt;&lt;/u&gt;</source>
        <translation type="vanished">&lt;u&gt;&lt;b&gt;Versión&lt;/b&gt;&lt;/u&gt;</translation>
    </message>
    <message>
        <source>&lt;u&gt;&lt;b&gt;Shortcuts&lt;/b&gt;&lt;/u&gt;</source>
        <translation type="vanished">&lt;u&gt;&lt;b&gt;Atajos&lt;/b&gt;&lt;/u&gt;</translation>
    </message>
</context>
<context>
    <name>InvertTool</name>
    <message>
        <location filename="../../src/tools/invert/inverttool.cpp" line="25"/>
        <source>Invert</source>
        <translation>Invertir</translation>
    </message>
    <message>
        <location filename="../../src/tools/invert/inverttool.cpp" line="35"/>
        <source>Set Inverter as the paint tool</source>
        <translation>Establecer el Inversor como la herramienta de dibujo</translation>
    </message>
</context>
<context>
    <name>LineTool</name>
    <message>
        <location filename="../../src/tools/line/linetool.cpp" line="22"/>
        <source>Line</source>
        <translation>Línea</translation>
    </message>
    <message>
        <location filename="../../src/tools/line/linetool.cpp" line="32"/>
        <source>Set the Line as the paint tool</source>
        <translation>Establecer la Línea como la herramienta de dibujo</translation>
    </message>
</context>
<context>
    <name>MarkerTool</name>
    <message>
        <location filename="../../src/tools/marker/markertool.cpp" line="23"/>
        <source>Marker</source>
        <translation>Marcador</translation>
    </message>
    <message>
        <location filename="../../src/tools/marker/markertool.cpp" line="33"/>
        <source>Set the Marker as the paint tool</source>
        <translation>Establecer el Marcador como la herramienta de dibujo</translation>
    </message>
</context>
<context>
    <name>MoveTool</name>
    <message>
        <location filename="../../src/tools/move/movetool.cpp" line="23"/>
        <source>Move</source>
        <translation>Mover</translation>
    </message>
    <message>
        <location filename="../../src/tools/move/movetool.cpp" line="33"/>
        <source>Move the selection area</source>
        <translation>Mover el área seleccionada</translation>
    </message>
</context>
<context>
    <name>PencilTool</name>
    <message>
        <location filename="../../src/tools/pencil/penciltool.cpp" line="18"/>
        <source>Pencil</source>
        <translation>Lápiz</translation>
    </message>
    <message>
        <location filename="../../src/tools/pencil/penciltool.cpp" line="28"/>
        <source>Set the Pencil as the paint tool</source>
        <translation>Establecer el Lápiz como la herramienta de dibujo</translation>
    </message>
</context>
<context>
    <name>PinTool</name>
    <message>
        <location filename="../../src/tools/pin/pintool.cpp" line="25"/>
        <source>Pin Tool</source>
        <translation>Chincheta</translation>
    </message>
    <message>
        <location filename="../../src/tools/pin/pintool.cpp" line="35"/>
        <source>Pin image on the desktop</source>
        <translation>Fijar imagen en el escritorio</translation>
    </message>
</context>
<context>
    <name>PixelateTool</name>
    <message>
        <location filename="../../src/tools/pixelate/pixelatetool.cpp" line="24"/>
        <source>Pixelate</source>
        <translation>Pixelar</translation>
    </message>
    <message>
        <location filename="../../src/tools/pixelate/pixelatetool.cpp" line="34"/>
        <source>Set Pixelate as the paint tool</source>
        <translation>Establecer Pixelar como la herramienta de pintura</translation>
    </message>
</context>
<context>
    <name>QHotkey</name>
    <message>
        <location filename="../../external/QHotkey/qhotkey.cpp" line="307"/>
        <source>Failed to register %1. Error: %2</source>
        <translation>Falla al registrar %1. Error: %2</translation>
    </message>
    <message>
        <location filename="../../external/QHotkey/qhotkey.cpp" line="329"/>
        <source>Failed to unregister %1. Error: %2</source>
        <translation>Falla al desregistrar %1. Error: %2</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../src/utils/screenshotsaver.cpp" line="214"/>
        <source>Save Error</source>
        <translation>Error al Guardar</translation>
    </message>
    <message>
        <location filename="../../src/utils/screenshotsaver.cpp" line="46"/>
        <location filename="../../src/utils/screenshotsaver.cpp" line="198"/>
        <source>Capture saved as </source>
        <translation>Captura guardada como </translation>
    </message>
    <message>
        <location filename="../../src/utils/screenshotsaver.cpp" line="136"/>
        <location filename="../../src/utils/screenshotsaver.cpp" line="138"/>
        <source>Capture saved to clipboard.</source>
        <translation>Captura guardada en el portapapeles.</translation>
    </message>
    <message>
        <source>Capture saved to clipboard</source>
        <translation type="vanished">Captura guardada en el portapapeles</translation>
    </message>
    <message>
        <location filename="../../src/utils/screenshotsaver.cpp" line="122"/>
        <source>Error while saving to clipboard</source>
        <translation>Error al guardar en el portapapeles</translation>
    </message>
    <message>
        <location filename="../../src/utils/screenshotsaver.cpp" line="50"/>
        <location filename="../../src/utils/screenshotsaver.cpp" line="207"/>
        <source>Error trying to save as </source>
        <translation>Error intentando guardar como </translation>
    </message>
    <message>
        <location filename="../../src/utils/screenshotsaver.cpp" line="181"/>
        <source>Save screenshot</source>
        <translation>Guardar captura de pantalla</translation>
    </message>
    <message>
        <location filename="../../src/utils/screenshotsaver.cpp" line="203"/>
        <source>Path copied to clipboard as </source>
        <translation>Ruta copiada al portapapeles como </translation>
    </message>
    <message>
        <source>Saving canceled</source>
        <translation type="vanished">Saving canceled</translation>
    </message>
    <message>
        <source>Save canceled</source>
        <translation type="vanished">Save canceled</translation>
    </message>
    <message>
        <source>Capture is saved and copied to the clipboard as </source>
        <translation type="vanished">Capture is saved and copied to the clipboard as </translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="135"/>
        <source>Unable to connect via DBus</source>
        <translation>Imposible conectar mediante DBus</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="151"/>
        <source>Powerful yet simple to use screenshot software.</source>
        <translation>Software de captura de pantalla poderoso pero sencillo de usar.</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="152"/>
        <source>See</source>
        <translation>Ver</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="155"/>
        <source>Capture the entire desktop.</source>
        <translation>Capturar el escritorio completo.</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="157"/>
        <source>Open the capture launcher.</source>
        <translation>Abrir el lanzador de capturas.</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="160"/>
        <source>Start a manual capture in GUI mode.</source>
        <translation>Iniciar una captura manual en el modo GUI.</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="162"/>
        <source>Configure</source>
        <translation>Configurar</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="164"/>
        <source>Capture a single screen.</source>
        <translation>Capturar una sola pantalla.</translation>
    </message>
    <message>
        <source>Path where the capture will be saved</source>
        <translation type="vanished">Path where the capture will be saved</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="169"/>
        <source>Existing directory or new file to save to</source>
        <translation>Directorio existente o nuevo archivo en el que guardar</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="172"/>
        <source>Save the capture to the clipboard</source>
        <translation>Guarda la captura en el portapapeles</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="174"/>
        <source>Pin the capture to the screen</source>
        <translation>Fija la captura a la pantalla</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="176"/>
        <source>Upload screenshot</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="178"/>
        <source>Delay time in milliseconds</source>
        <translation>Duración de demora en milisegundos</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="181"/>
        <source>Screenshot region to select</source>
        <translation>Región de captura de pantalla a seleccionar</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="184"/>
        <source>Set the filename pattern</source>
        <translation>Establecer el patrón de nombre de archivo</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="188"/>
        <source>Accept capture as soon as a selection is made</source>
        <translation>Aceptar captura en cuanto se haga una selección</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="190"/>
        <source>Enable or disable the trayicon</source>
        <translation>Activar o desactivar el icono de la bandeja</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="194"/>
        <source>Enable or disable run at startup</source>
        <translation>Activar o desactivar la ejecución al inicio</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="197"/>
        <source>Check the configuration for errors</source>
        <translation>Comprobar si hay errores en la configuración</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="200"/>
        <source>Show the help message in the capture mode</source>
        <translation>Mostrar el mensaje de ayuda en el modo de captura</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="203"/>
        <source>Define the main UI color</source>
        <translation>Definir el color principal de la interfaz de usuario</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="207"/>
        <source>Define the contrast UI color</source>
        <translation>Definir el color de contraste de la interfaz de usuario</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="210"/>
        <source>Print raw PNG capture</source>
        <translation>Imprimir la captura PNG sin procesar</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="213"/>
        <source>Print geometry of the selection in the format W H X Y. Does nothing if raw is specified</source>
        <translation>Imprimir geometría de la selección en el formato W H X Y. No hace nada si se especifica que no se procese</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="217"/>
        <source>Define the screen to capture (starting from 0)</source>
        <translation>Definir la pantalla a capturar (empezando por 0)</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="237"/>
        <source>Invalid delay, it must be a number greater than 0</source>
        <translation>Demora inválida, debe ser un valor mayor a 0</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="240"/>
        <source>Invalid region, use &apos;WxH+X+Y&apos; or &apos;all&apos; or &apos;screen0/screen1/...&apos;.</source>
        <translation>Región inválida, utiliza &quot;WxH+X+Y&quot; o &quot;todo&quot; o &quot;pantalla0/pantalla1/...&quot;.</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="253"/>
        <source>Invalid path, must be an existing directory or a new file in an existing directory</source>
        <translation>Ruta inválida, debe ser un directorio existente o un nuevo archivo en un directorio existente</translation>
    </message>
    <message>
        <source>Define the screen to capture</source>
        <translation type="vanished">Define the screen to capture</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="218"/>
        <source>default: screen containing the cursor</source>
        <translation>por defecto: pantalla que contiene el cursor</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="219"/>
        <source>Screen number</source>
        <translation>Screen number</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="228"/>
        <source>Invalid color, this flag supports the following formats:
- #RGB (each of R, G, and B is a single hex digit)
- #RRGGBB
- #RRRGGGBBB
- #RRRRGGGGBBBB
- Named colors like &apos;blue&apos; or &apos;red&apos;
You may need to escape the &apos;#&apos; sign as in &apos;\#FFF&apos;</source>
        <translation>Color inválido, este flag soporta los siguientes formatos:
- #RGB (cada uno de R, G y B es un solo dígito hexadecimal)
- #RRGGBB
- #RRRGGGBBB
- #RRRRGGGGBBBB
- Colores con nombre, como &quot;azul&quot; o &quot;rojo&quot;
Puede ser que necesites preceder el símbolo &quot;#&quot; con &quot;\&quot;, como en &quot;\#FFF&quot;</translation>
    </message>
    <message>
        <source>Invalid delay, it must be higher than 0</source>
        <translation type="vanished">Invalid delay, it must be higher than 0</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="239"/>
        <source>Invalid screen number, it must be non negative</source>
        <translation>Número de pantalla inválido, no debe ser negativo</translation>
    </message>
    <message>
        <source>Invalid path, it must be a real path in the system</source>
        <translation type="vanished">Invalid path, it must be a real path in the system</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="266"/>
        <source>Invalid value, it must be defined as &apos;true&apos; or &apos;false&apos;</source>
        <translation>Valor inválido, debe ser definido como &quot;verdadero&quot; o &quot;falso&quot;</translation>
    </message>
    <message>
        <location filename="../../src/tools/launcher/openwithprogram.cpp" line="30"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../../src/tools/launcher/openwithprogram.cpp" line="31"/>
        <source>Unable to write in</source>
        <translation>Imposible escribir en</translation>
    </message>
    <message>
        <location filename="../../src/core/controller.cpp" line="656"/>
        <source>Full screen screenshot pinned to screen</source>
        <translation>Captura de pantalla completa fijada a la pantalla</translation>
    </message>
    <message>
        <source>URL copied to clipboard.</source>
        <translation type="vanished">URL copiada al portapapeles.</translation>
    </message>
    <message>
        <location filename="../../src/cli/commandlineparser.cpp" line="54"/>
        <source>Options</source>
        <translation>Options</translation>
    </message>
    <message>
        <location filename="../../src/cli/commandlineparser.cpp" line="68"/>
        <source>Arguments</source>
        <translation>Argumentos</translation>
    </message>
    <message>
        <location filename="../../src/cli/commandlineparser.cpp" line="329"/>
        <source>arguments</source>
        <translation>argumentos</translation>
    </message>
    <message>
        <location filename="../../src/cli/commandlineparser.cpp" line="330"/>
        <source>Usage</source>
        <translation>Uso</translation>
    </message>
    <message>
        <location filename="../../src/cli/commandlineparser.cpp" line="330"/>
        <source>options</source>
        <translation>options</translation>
    </message>
    <message>
        <location filename="../../src/cli/commandlineparser.cpp" line="337"/>
        <source>Per default runs Flameshot in the background and adds a tray icon for configuration.</source>
        <translation>Por defecto, Flameshot se ejecuta en segundo plano y añade un icono en la bandeja para su configuración.</translation>
    </message>
    <message>
        <location filename="../../src/core/controller.cpp" line="569"/>
        <source>Hello, I&apos;m here! Click icon in the tray to take a screenshot or click with a right button to see more options.</source>
        <translation>¡Hola, estoy aquí! Haz clic en el icono en la bandeja para tomar una captura de pantalla o clic derecho para ver más opciones.</translation>
    </message>
    <message>
        <source>Toggle side panel</source>
        <translation type="vanished">Toggle side panel</translation>
    </message>
    <message>
        <source>Resize selection left 1px</source>
        <translation type="vanished">Resize selection left 1px</translation>
    </message>
    <message>
        <source>Resize selection right 1px</source>
        <translation type="vanished">Resize selection right 1px</translation>
    </message>
    <message>
        <source>Resize selection up 1px</source>
        <translation type="vanished">Resize selection up 1px</translation>
    </message>
    <message>
        <source>Resize selection down 1px</source>
        <translation type="vanished">Resize selection down 1px</translation>
    </message>
    <message>
        <source>Select entire screen</source>
        <translation type="vanished">Select entire screen</translation>
    </message>
    <message>
        <source>Move selection left 1px</source>
        <translation type="vanished">Move selection left 1px</translation>
    </message>
    <message>
        <source>Move selection right 1px</source>
        <translation type="vanished">Move selection right 1px</translation>
    </message>
    <message>
        <source>Move selection up 1px</source>
        <translation type="vanished">Move selection up 1px</translation>
    </message>
    <message>
        <source>Move selection down 1px</source>
        <translation type="vanished">Move selection down 1px</translation>
    </message>
    <message>
        <source>Commit text in text area</source>
        <translation type="vanished">Commit text in text area</translation>
    </message>
    <message>
        <source>Delete current tool</source>
        <translation type="vanished">Delete current tool</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="187"/>
        <source>Quit capture</source>
        <translation>Salir de la captura</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="195"/>
        <source>Screenshot history</source>
        <translation>Historial de capturas de pantalla</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="198"/>
        <source>Capture screen</source>
        <translation>Capturar pantalla</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="205"/>
        <source>Show color picker</source>
        <translation>Mostrar el selector de color</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="206"/>
        <source>Change the tool&apos;s size</source>
        <translation>Cambiar el tamaño de la herramienta</translation>
    </message>
    <message>
        <source>Change the tool&apos;s thickness</source>
        <translation type="vanished">Cambiar el grosor de la herramienta</translation>
    </message>
</context>
<context>
    <name>RectangleTool</name>
    <message>
        <location filename="../../src/tools/rectangle/rectangletool.cpp" line="22"/>
        <source>Rectangle</source>
        <translation>Rectángulo</translation>
    </message>
    <message>
        <location filename="../../src/tools/rectangle/rectangletool.cpp" line="32"/>
        <source>Set the Rectangle as the paint tool</source>
        <translation>Establecer el Rectángulo como la herramienta de dibujo</translation>
    </message>
</context>
<context>
    <name>RedoTool</name>
    <message>
        <location filename="../../src/tools/redo/redotool.cpp" line="23"/>
        <source>Redo</source>
        <translation>Rehacer</translation>
    </message>
    <message>
        <location filename="../../src/tools/redo/redotool.cpp" line="33"/>
        <source>Redo the next modification</source>
        <translation>Rehacer la siguiente modificación</translation>
    </message>
</context>
<context>
    <name>SaveTool</name>
    <message>
        <location filename="../../src/tools/save/savetool.cpp" line="24"/>
        <source>Save</source>
        <translation>Guardar</translation>
    </message>
    <message>
        <location filename="../../src/tools/save/savetool.cpp" line="34"/>
        <source>Save screenshot to a file</source>
        <translation>Guardar captura de pantalla en un archivo</translation>
    </message>
    <message>
        <source>Save the capture</source>
        <translation type="vanished">Guardar la captura</translation>
    </message>
</context>
<context>
    <name>ScreenGrabber</name>
    <message>
        <location filename="../../src/utils/screengrabber.cpp" line="131"/>
        <source>Unable to capture screen</source>
        <translation>Imposible capturar la pantalla</translation>
    </message>
</context>
<context>
    <name>SelectionTool</name>
    <message>
        <location filename="../../src/tools/selection/selectiontool.cpp" line="25"/>
        <source>Rectangular Selection</source>
        <translation>Selección Rectangular</translation>
    </message>
    <message>
        <location filename="../../src/tools/selection/selectiontool.cpp" line="35"/>
        <source>Set Selection as the paint tool</source>
        <translation>Establecer Selección como la herramienta de dibujo</translation>
    </message>
</context>
<context>
    <name>SetShortcutDialog</name>
    <message>
        <location filename="../../src/config/setshortcutwidget.cpp" line="17"/>
        <source>Set Shortcut</source>
        <translation>Establecer Atajo</translation>
    </message>
    <message>
        <location filename="../../src/config/setshortcutwidget.cpp" line="23"/>
        <source>Enter new shortcut to change </source>
        <translation>Introduce un nuevo atajo para cambiar este </translation>
    </message>
    <message>
        <location filename="../../src/config/setshortcutwidget.cpp" line="37"/>
        <source>Press Esc to cancel or ⌘+Backspace to disable the keyboard shortcut.</source>
        <translation>Presiona Esc para cancelar o ⌘+Retroceso para desactivar el atajo de teclado.</translation>
    </message>
    <message>
        <location filename="../../src/config/setshortcutwidget.cpp" line="41"/>
        <source>Press Esc to cancel or Backspace to disable the keyboard shortcut.</source>
        <translation>Presiona Esc para cancelar o Retroceso para desactivar el atajo de teclado.</translation>
    </message>
    <message>
        <location filename="../../src/config/setshortcutwidget.cpp" line="46"/>
        <source>Flameshot must be restarted for changes to take effect.</source>
        <translation>Flameshot debe ser reiniciado para que los cambios tengan efecto.</translation>
    </message>
</context>
<context>
    <name>ShortcutsWidget</name>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="30"/>
        <source>Hot Keys</source>
        <translation>Teclas de Acceso Rápido</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="53"/>
        <source>Available shortcuts in the screen capture mode.</source>
        <translation>Atajos disponibles en el modo captura de pantalla.</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="64"/>
        <source>Description</source>
        <translation>Descripción</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="64"/>
        <source>Key</source>
        <translation>Tecla</translation>
    </message>
</context>
<context>
    <name>SidePanelWidget</name>
    <message>
        <source>Active thickness:</source>
        <translation type="vanished">Espesor activo:</translation>
    </message>
    <message>
        <source>Active color:</source>
        <translation type="vanished">Color activo:</translation>
    </message>
    <message>
        <source>Press ESC to cancel</source>
        <translation type="vanished">Presiona ESC para cancelar</translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/sidepanelwidget.cpp" line="36"/>
        <source>Active tool size: </source>
        <translation>Tamaño de la herramienta activa: </translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/sidepanelwidget.cpp" line="48"/>
        <source>Active Color: </source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/sidepanelwidget.cpp" line="69"/>
        <source>Grab Color</source>
        <translation>Tomar Color</translation>
    </message>
</context>
<context>
    <name>SizeDecreaseTool</name>
    <message>
        <location filename="../../src/tools/sizedecrease/sizedecreasetool.cpp" line="37"/>
        <source>Decrease Tool Size</source>
        <translation>Disminuir el Tamaño de la Herramienta</translation>
    </message>
    <message>
        <location filename="../../src/tools/sizedecrease/sizedecreasetool.cpp" line="47"/>
        <source>Decrease the size of the other tools</source>
        <translation>Disminuir el tamaño de las otras herramientas</translation>
    </message>
</context>
<context>
    <name>SizeIncreaseTool</name>
    <message>
        <location filename="../../src/tools/sizeincrease/sizeincreasetool.cpp" line="37"/>
        <source>Increase Tool Size</source>
        <translation>Aumentar el Tamaño de la Herramienta</translation>
    </message>
    <message>
        <location filename="../../src/tools/sizeincrease/sizeincreasetool.cpp" line="47"/>
        <source>Increase the size of the other tools</source>
        <translation>Aumentar el tamaño de las otras herramientas</translation>
    </message>
</context>
<context>
    <name>SizeIndicatorTool</name>
    <message>
        <location filename="../../src/tools/sizeindicator/sizeindicatortool.cpp" line="23"/>
        <source>Selection Size Indicator</source>
        <translation>Indicador de Tamaño de Selección</translation>
    </message>
    <message>
        <location filename="../../src/tools/sizeindicator/sizeindicatortool.cpp" line="33"/>
        <source>Show X and Y dimensions of the selection</source>
        <translation>Mostrar las dimensiones X e Y de la selección</translation>
    </message>
    <message>
        <source>Show the dimensions of the selection (X Y)</source>
        <translation type="vanished">Muestra la dimensión de la selección (X Y)</translation>
    </message>
</context>
<context>
    <name>StrftimeChooserWidget</name>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="37"/>
        <source>Century (00-99)</source>
        <translation>Siglo (00-99)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="38"/>
        <source>Year (00-99)</source>
        <translation>Año (00-99)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="39"/>
        <source>Year (2000)</source>
        <translation>Año (2000)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="42"/>
        <source>Month Name (jan)</source>
        <translation>Nombre del Mes (jul)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="43"/>
        <source>Month Name (january)</source>
        <translation>Nombre del Mes (julio)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="45"/>
        <source>Month (01-12)</source>
        <translation>Mes (01-12)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="46"/>
        <source>Week Day (1-7)</source>
        <translation>Día de la Semana (1-7)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="47"/>
        <source>Week (01-53)</source>
        <translation>Semana (01-53)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="50"/>
        <source>Day Name (mon)</source>
        <translation>Nombre del Día (dom)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="51"/>
        <source>Day Name (monday)</source>
        <translation>Nombre del Día (domingo)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="53"/>
        <source>Day (01-31)</source>
        <translation>Día (01-31)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="54"/>
        <source>Day of Month (1-31)</source>
        <translation>Día del Mes (1-31)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="55"/>
        <source>Day (001-366)</source>
        <translation>Día (001-366)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="58"/>
        <source>Time (%H-%M-%S)</source>
        <translation>Tiempo (%H-%M-%S)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="59"/>
        <source>Time (%H-%M)</source>
        <translation>Tiempo (%H-%M)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="61"/>
        <source>Hour (00-23)</source>
        <translation>Hora (00-23)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="62"/>
        <source>Hour (01-12)</source>
        <translation>Hora (01-12)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="63"/>
        <source>Minute (00-59)</source>
        <translation>Minuto (00-59)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="64"/>
        <source>Second (00-59)</source>
        <translation>Segundo (00-59)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="67"/>
        <source>Full Date (%m/%d/%y)</source>
        <translation>Fecha (%m/%d/%y)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="69"/>
        <source>Full Date (%Y-%m-%d)</source>
        <translation>Fecha (%Y-%m-%d)</translation>
    </message>
</context>
<context>
    <name>SystemNotification</name>
    <message>
        <location filename="../../src/utils/systemnotification.cpp" line="30"/>
        <source>Flameshot Info</source>
        <translation>Información de Flameshot</translation>
    </message>
</context>
<context>
    <name>TextConfig</name>
    <message>
        <location filename="../../src/tools/text/textconfig.cpp" line="47"/>
        <source>StrikeOut</source>
        <translation>Tachado</translation>
    </message>
    <message>
        <location filename="../../src/tools/text/textconfig.cpp" line="56"/>
        <source>Underline</source>
        <translation>Subrayado</translation>
    </message>
    <message>
        <location filename="../../src/tools/text/textconfig.cpp" line="65"/>
        <source>Bold</source>
        <translation>Negrita</translation>
    </message>
    <message>
        <location filename="../../src/tools/text/textconfig.cpp" line="74"/>
        <source>Italic</source>
        <translation>Cursiva</translation>
    </message>
    <message>
        <location filename="../../src/tools/text/textconfig.cpp" line="84"/>
        <source>Left Align</source>
        <translation>Alinear a la Izquierda</translation>
    </message>
    <message>
        <location filename="../../src/tools/text/textconfig.cpp" line="93"/>
        <source>Center Align</source>
        <translation>Alinear al Centro</translation>
    </message>
    <message>
        <location filename="../../src/tools/text/textconfig.cpp" line="102"/>
        <source>Right Align</source>
        <translation>Alinear a la Derecha</translation>
    </message>
</context>
<context>
    <name>TextTool</name>
    <message>
        <location filename="../../src/tools/text/texttool.cpp" line="73"/>
        <source>Text</source>
        <translation>Texto</translation>
    </message>
    <message>
        <location filename="../../src/tools/text/texttool.cpp" line="97"/>
        <source>Add text to your capture</source>
        <translation>Agregar texto a la captura</translation>
    </message>
</context>
<context>
    <name>UIcolorEditor</name>
    <message>
        <source>UI Color Editor</source>
        <translation type="vanished">Editor de Color de Interfaz</translation>
    </message>
    <message>
        <location filename="../../src/config/uicoloreditor.cpp" line="88"/>
        <source>Change the color moving the selectors and see the changes in the preview buttons.</source>
        <translation>Cambia el color moviendo los selectores y observa los cambios en los botones de previsualización.</translation>
    </message>
    <message>
        <location filename="../../src/config/uicoloreditor.cpp" line="99"/>
        <source>Select a Button to modify it</source>
        <translation>Selecciona un Botón para modificarlo</translation>
    </message>
    <message>
        <location filename="../../src/config/uicoloreditor.cpp" line="109"/>
        <source>Main Color</source>
        <translation>Color Principal</translation>
    </message>
    <message>
        <location filename="../../src/config/uicoloreditor.cpp" line="113"/>
        <source>Click on this button to set the edition mode of the main color.</source>
        <translation>Clica en este botón para aplicar el modo edición para el color primario.</translation>
    </message>
    <message>
        <location filename="../../src/config/uicoloreditor.cpp" line="124"/>
        <source>Contrast Color</source>
        <translation>Color de Contraste</translation>
    </message>
    <message>
        <location filename="../../src/config/uicoloreditor.cpp" line="129"/>
        <source>Click on this button to set the edition mode of the contrast color.</source>
        <translation>Clica en este botón para aplicar el modo edición para el color de contraste.</translation>
    </message>
</context>
<context>
    <name>UndoTool</name>
    <message>
        <location filename="../../src/tools/undo/undotool.cpp" line="23"/>
        <source>Undo</source>
        <translation>Deshacer</translation>
    </message>
    <message>
        <location filename="../../src/tools/undo/undotool.cpp" line="33"/>
        <source>Undo the last modification</source>
        <translation>Borra la última modificación</translation>
    </message>
</context>
<context>
    <name>UpdateNotificationWidget</name>
    <message>
        <location filename="../../src/widgets/updatenotificationwidget.cpp" line="69"/>
        <source>New Flameshot version %1 is available</source>
        <translation>Nueva versión %1 de Flameshot está disponible</translation>
    </message>
    <message>
        <location filename="../../src/widgets/updatenotificationwidget.cpp" line="122"/>
        <source>Ignore</source>
        <translation>Ignorar</translation>
    </message>
    <message>
        <location filename="../../src/widgets/updatenotificationwidget.cpp" line="130"/>
        <source>Later</source>
        <translation>Luego</translation>
    </message>
    <message>
        <location filename="../../src/widgets/updatenotificationwidget.cpp" line="138"/>
        <source>Update</source>
        <translation>Actualizar</translation>
    </message>
</context>
<context>
    <name>UploadHistory</name>
    <message>
        <location filename="../../src/widgets/uploadhistory.ui" line="14"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_uploadhistory.h" line="67"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_uploadhistory.h" line="67"/>
        <source>Upload History</source>
        <translation>Subir Historial</translation>
    </message>
    <message>
        <location filename="../../src/widgets/uploadhistory.cpp" line="62"/>
        <source>Screenshots history is empty</source>
        <translation>El historial de capturas está vacío</translation>
    </message>
</context>
<context>
    <name>UploadLineItem</name>
    <message>
        <location filename="../../src/widgets/uploadlineitem.ui" line="20"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_uploadlineitem.h" line="113"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_uploadlineitem.h" line="113"/>
        <source>Form</source>
        <translation>Forma</translation>
    </message>
    <message>
        <location filename="../../src/widgets/uploadlineitem.ui" line="49"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_uploadlineitem.h" line="114"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_uploadlineitem.h" line="114"/>
        <source>TextLabel</source>
        <translation>Etiqueta de texto</translation>
    </message>
    <message>
        <location filename="../../src/widgets/uploadlineitem.ui" line="82"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_uploadlineitem.h" line="115"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_uploadlineitem.h" line="115"/>
        <source>Copy URL</source>
        <translation>Copiar URL</translation>
    </message>
    <message>
        <location filename="../../src/widgets/uploadlineitem.ui" line="95"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_uploadlineitem.h" line="116"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_uploadlineitem.h" line="116"/>
        <source>Open In Browser</source>
        <translation>Abrir en Navegador</translation>
    </message>
    <message>
        <location filename="../../src/widgets/uploadlineitem.cpp" line="50"/>
        <source>Confirm to delete</source>
        <translation>Confirmar la eliminación</translation>
    </message>
    <message>
        <location filename="../../src/widgets/uploadlineitem.cpp" line="51"/>
        <source>Are you sure you want to delete a screenshot from the latest uploads and server?</source>
        <translation>¿Estás seguro de que deseas borrar una captura de pantalla de las últimas subidas y el servidor?</translation>
    </message>
</context>
<context>
    <name>UtilityPanel</name>
    <message>
        <location filename="../../src/widgets/panel/utilitypanel.cpp" line="190"/>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/utilitypanel.cpp" line="200"/>
        <source>&lt;Empty&gt;</source>
        <translation>&lt;Empty&gt;</translation>
    </message>
</context>
<context>
    <name>VisualsEditor</name>
    <message>
        <location filename="../../src/config/visualseditor.cpp" line="41"/>
        <source>Opacity of area outside selection:</source>
        <translation>Opacidad del area fuera de la selección:</translation>
    </message>
    <message>
        <location filename="../../src/config/visualseditor.cpp" line="68"/>
        <source>UI Color Editor</source>
        <translation>Editor de Color de la Interfaz</translation>
    </message>
    <message>
        <location filename="../../src/config/visualseditor.cpp" line="74"/>
        <source>Colorpicker Editor</source>
        <translation>Editor del Selector de Color</translation>
    </message>
    <message>
        <location filename="../../src/config/visualseditor.cpp" line="79"/>
        <source>Button Selection</source>
        <translation>Selección de Botón</translation>
    </message>
    <message>
        <location filename="../../src/config/visualseditor.cpp" line="85"/>
        <source>Select All</source>
        <translation>Seleccionar Todos</translation>
    </message>
</context>
<context>
    <name>color_widgets::ColorDialog</name>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_dialog.cpp" line="79"/>
        <source>Pick</source>
        <translation>Elegir</translation>
    </message>
</context>
<context>
    <name>color_widgets::ColorPalette</name>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette.cpp" line="428"/>
        <source>Unnamed</source>
        <translation>Sin Nombre</translation>
    </message>
</context>
<context>
    <name>color_widgets::ColorPaletteModel</name>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_model.cpp" line="70"/>
        <source>Unnamed</source>
        <translation>Sin Nombre</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_model.cpp" line="144"/>
        <source>%1 (%2 colors)</source>
        <translation>%1 (%2 colores)</translation>
    </message>
</context>
<context>
    <name>color_widgets::ColorPaletteWidget</name>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.ui" line="59"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="209"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="209"/>
        <source>Open a new palette from file</source>
        <translation>Abrir una nueva paleta desde un archivo</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.ui" line="71"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="212"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="212"/>
        <source>Create a new palette</source>
        <translation>Crear una nueva paleta</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.ui" line="83"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="215"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="215"/>
        <source>Duplicate the current palette</source>
        <translation>Duplicar la paleta actual</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.ui" line="121"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="218"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="218"/>
        <source>Delete the current palette</source>
        <translation>Borrar la paleta actual</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.ui" line="133"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="221"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="221"/>
        <source>Revert changes to the current palette</source>
        <translation>Revertir cambios a la paleta actual</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.ui" line="145"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="224"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="224"/>
        <source>Save changes to the current palette</source>
        <translation>Guardar cambios a la paleta actual</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.ui" line="170"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="227"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="227"/>
        <source>Add a color to the palette</source>
        <translation>Añadir un color a la paleta</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.ui" line="182"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="230"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="230"/>
        <source>Remove the selected color from the palette</source>
        <translation>Eliminar el color seleccionado de la paleta</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.cpp" line="186"/>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.cpp" line="201"/>
        <source>New Palette</source>
        <translation>Nueva Paleta</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.cpp" line="187"/>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.cpp" line="202"/>
        <source>Name</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.cpp" line="228"/>
        <source>GIMP Palettes (*.gpl)</source>
        <translation>Paletas de GIMP(*.gpl)</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.cpp" line="229"/>
        <source>Palette Image (%1)</source>
        <translation>Imagen de paleta (%1)</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.cpp" line="230"/>
        <source>All Files (*)</source>
        <translation>Todos los Archivos (*)</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.cpp" line="231"/>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.cpp" line="244"/>
        <source>Open Palette</source>
        <translation>Abrir Paleta</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.cpp" line="245"/>
        <source>Failed to load the palette file
%1</source>
        <translation>No se pudo cargar el archivo de paleta
%1</translation>
    </message>
</context>
<context>
    <name>color_widgets::GradientEditor</name>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/gradient_editor.cpp" line="335"/>
        <source>Add Color</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/gradient_editor.cpp" line="344"/>
        <source>Remove Color</source>
        <translation>Eliminar color</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/gradient_editor.cpp" line="352"/>
        <source>Edit Color...</source>
        <translation>Editar Color...</translation>
    </message>
</context>
<context>
    <name>color_widgets::GradientListModel</name>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/gradient_list_model.cpp" line="231"/>
        <source>%1 (%2 colors)</source>
        <translation>%1 (%2 colores)</translation>
    </message>
</context>
<context>
    <name>color_widgets::Swatch</name>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/swatch.cpp" line="824"/>
        <source>Clear Color</source>
        <translation>Quitar Color</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/swatch.cpp" line="833"/>
        <source>%1 (%2)</source>
        <translation></translation>
    </message>
</context>
</TS>
