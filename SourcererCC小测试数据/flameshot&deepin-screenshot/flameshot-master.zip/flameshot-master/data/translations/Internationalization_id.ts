<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="id">
<context>
    <name>AbstractWidgetList</name>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/abstract_widget_list.cpp" line="67"/>
        <source>Add New</source>
        <translation>Tambah Baru</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/abstract_widget_list.cpp" line="118"/>
        <source>Move Up</source>
        <translation>Pindah Ke Atas</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/abstract_widget_list.cpp" line="119"/>
        <source>Move Down</source>
        <translation>Pindah Ke Bawah</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/abstract_widget_list.cpp" line="120"/>
        <source>Remove</source>
        <translation>Hapus</translation>
    </message>
</context>
<context>
    <name>AcceptTool</name>
    <message>
        <location filename="../../src/tools/accept/accepttool.cpp" line="31"/>
        <source>Accept</source>
        <translation>Terima</translation>
    </message>
    <message>
        <location filename="../../src/tools/accept/accepttool.cpp" line="41"/>
        <source>Accept the capture</source>
        <translation>Terima cuplikan</translation>
    </message>
</context>
<context>
    <name>AppLauncher</name>
    <message>
        <location filename="../../src/tools/launcher/applaunchertool.cpp" line="23"/>
        <source>App Launcher</source>
        <translation>Peluncur Aplikasi</translation>
    </message>
    <message>
        <location filename="../../src/tools/launcher/applaunchertool.cpp" line="33"/>
        <source>Choose an app to open the capture</source>
        <translation>Pilih aplikasi untuk membuka cuplikan layar</translation>
    </message>
</context>
<context>
    <name>AppLauncherWidget</name>
    <message>
        <location filename="../../src/tools/launcher/applauncherwidget.cpp" line="43"/>
        <source>Open With</source>
        <translation>Buka Dengan</translation>
    </message>
    <message>
        <location filename="../../src/tools/launcher/applauncherwidget.cpp" line="58"/>
        <source>Launch in terminal</source>
        <translation>Luncurkan di terminal</translation>
    </message>
    <message>
        <location filename="../../src/tools/launcher/applauncherwidget.cpp" line="59"/>
        <source>Keep open after selection</source>
        <translation>Tetap buka setelah memilih</translation>
    </message>
    <message>
        <location filename="../../src/tools/launcher/applauncherwidget.cpp" line="95"/>
        <location filename="../../src/tools/launcher/applauncherwidget.cpp" line="110"/>
        <source>Error</source>
        <translation>Galat</translation>
    </message>
    <message>
        <location filename="../../src/tools/launcher/applauncherwidget.cpp" line="110"/>
        <source>Unable to launch in terminal.</source>
        <translation>Tidak dapat meluncurkan pada terminal.</translation>
    </message>
    <message>
        <location filename="../../src/tools/launcher/applauncherwidget.cpp" line="95"/>
        <source>Unable to write in</source>
        <translation>Tidak dapat menulis</translation>
    </message>
</context>
<context>
    <name>ArrowTool</name>
    <message>
        <location filename="../../src/tools/arrow/arrowtool.cpp" line="72"/>
        <source>Arrow</source>
        <translation>Panah</translation>
    </message>
    <message>
        <location filename="../../src/tools/arrow/arrowtool.cpp" line="82"/>
        <source>Set the Arrow as the paint tool</source>
        <translation>Atur Panah sebagai paint tool</translation>
    </message>
</context>
<context>
    <name>BlurTool</name>
    <message>
        <source>Blur</source>
        <translation type="vanished">Desenfocament</translation>
    </message>
    <message>
        <source>Set Blur as the paint tool</source>
        <translation type="vanished">Estableix el desenfocament com a eina de dibuix</translation>
    </message>
</context>
<context>
    <name>CaptureLauncher</name>
    <message>
        <source>&lt;b&gt;Capture Mode&lt;/b&gt;</source>
        <translation type="vanished">&lt;b&gt;Mode Cuplikan&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.cpp" line="31"/>
        <source>Rectangular Region</source>
        <translation>Daerah Persegi Panjang</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.cpp" line="37"/>
        <source>Full Screen (Current Display)</source>
        <translation>Layar Penuh (Tampilan saat ini)</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.cpp" line="40"/>
        <source>Full Screen (All Monitors)</source>
        <translation>Layar Penuh (Semua Monitor)</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.cpp" line="43"/>
        <source>No Delay</source>
        <translation>Tanpa Jeda</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.cpp" line="51"/>
        <source> second</source>
        <translation> detik</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.ui" line="75"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_capturelauncher.h" line="125"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_capturelauncher.h" line="125"/>
        <location filename="../../src/widgets/capturelauncher.cpp" line="51"/>
        <source> seconds</source>
        <translation> detik</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.ui" line="96"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_capturelauncher.h" line="126"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_capturelauncher.h" line="126"/>
        <source>Take new screenshot</source>
        <translation>Ambil tangkapan layar baru</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.ui" line="54"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_capturelauncher.h" line="122"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_capturelauncher.h" line="122"/>
        <source>Area:</source>
        <translation>Area:</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.ui" line="14"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_capturelauncher.h" line="119"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_capturelauncher.h" line="119"/>
        <source>Capture Launcher</source>
        <translation>Peluncur Penangkap</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.ui" line="22"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_capturelauncher.h" line="120"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_capturelauncher.h" line="120"/>
        <source>TextLabel</source>
        <translation>LabelTeks</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.ui" line="39"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_capturelauncher.h" line="121"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_capturelauncher.h" line="121"/>
        <source>Capture Mode</source>
        <translation>Mode Penangkapan</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.ui" line="61"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_capturelauncher.h" line="123"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_capturelauncher.h" line="123"/>
        <source>Delay:</source>
        <translation>Jeda:</translation>
    </message>
</context>
<context>
    <name>CaptureWidget</name>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="105"/>
        <source>Unable to capture screen</source>
        <translatorcomment>Impossible capturar la pantalla</translatorcomment>
        <translation>Tidak dapat menangkap layar</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="378"/>
        <source>Mouse</source>
        <translation>Mouse</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="378"/>
        <source>Select screenshot area</source>
        <translation>Pilih area tangkapan layar</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="393"/>
        <source>Mouse Wheel</source>
        <translation>Roda Mouse</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="393"/>
        <source>Change tool size</source>
        <translation>Ubah ukuran alat</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="394"/>
        <source>Right Click</source>
        <translation>Klik Kanan</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="394"/>
        <source>Show color picker</source>
        <translation>Tampilkan pemilih warna</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="396"/>
        <source>Open side panel</source>
        <translation>Buka panel samping</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="397"/>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="397"/>
        <source>Exit</source>
        <translation>Keluar</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="505"/>
        <source>Flameshot has lost focus. Keyboard shortcuts won&apos;t work until you click somewhere.</source>
        <translation>Flameshot telah kehilangan fokus. Pintasan keyboard tidak akan berfungsi sampai Anda mengklik di suatu tempat.</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="511"/>
        <source>Configuration error resolved. Launch `flameshot gui` again to apply it.</source>
        <translation>Kesalahan konfigurasi teratasi. Jalankan `flameshot gui` lagi untuk menerapkannya.</translation>
    </message>
    <message>
        <source>Select an area with the mouse, or press Esc to exit.
Press Enter to capture the screen.
Press Right Click to show the color picker.
Use the Mouse Wheel to change the thickness of your tool.
Press Space to open the side panel.</source>
        <translation type="vanished">Select an area with the mouse, or press Esc to exit.
Press Enter to capture the screen.
Press Right Click to show the color picker.
Use the Mouse Wheel to change the thickness of your tool.
Press Space to open the side panel.</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="949"/>
        <source>Tool Settings</source>
        <translation>Pengaturan Alat</translation>
    </message>
</context>
<context>
    <name>CircleCountTool</name>
    <message>
        <location filename="../../src/tools/circlecount/circlecounttool.cpp" line="57"/>
        <source>Circle Counter</source>
        <translation>Penghitung Lingkaran</translation>
    </message>
    <message>
        <location filename="../../src/tools/circlecount/circlecounttool.cpp" line="75"/>
        <source>Add an autoincrementing counter bubble</source>
        <translation>Tambahkan gelembung penghitung autoincrementing</translation>
    </message>
</context>
<context>
    <name>CircleTool</name>
    <message>
        <location filename="../../src/tools/circle/circletool.cpp" line="20"/>
        <source>Circle</source>
        <translation>Lingkaran</translation>
    </message>
    <message>
        <location filename="../../src/tools/circle/circletool.cpp" line="30"/>
        <source>Set the Circle as the paint tool</source>
        <translation>Atur Lingkaran sebagai paint tool</translation>
    </message>
</context>
<context>
    <name>ColorDialog</name>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_dialog.ui" line="14"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="318"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="318"/>
        <source>Select Color</source>
        <translation>Pilih Warna</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_dialog.ui" line="55"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="319"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="319"/>
        <source>Saturation</source>
        <translation>Saturasi</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_dialog.ui" line="62"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="320"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="320"/>
        <source>Hue</source>
        <translation>Warna</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_dialog.ui" line="79"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="321"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="321"/>
        <source>Hex</source>
        <translation>Hex</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_dialog.ui" line="86"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="322"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="322"/>
        <source>Blue</source>
        <translation>Biru</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_dialog.ui" line="123"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="323"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="323"/>
        <source>Value</source>
        <translation>Nilai</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_dialog.ui" line="130"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="324"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="324"/>
        <source>Green</source>
        <translation>Hijau</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_dialog.ui" line="137"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="325"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="325"/>
        <source>Alpha</source>
        <translation>Alfa</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_dialog.ui" line="144"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="326"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="326"/>
        <source>Red</source>
        <translation>Merah</translation>
    </message>
</context>
<context>
    <name>ColorGrabWidget</name>
    <message>
        <location filename="../../src/widgets/panel/colorgrabwidget.cpp" line="58"/>
        <source>Accept color</source>
        <translation>Terima warna</translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/colorgrabwidget.cpp" line="59"/>
        <source>Precisely select color</source>
        <translation>Pilih warna dengan tepat</translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/colorgrabwidget.cpp" line="60"/>
        <source>Toggle magnifier</source>
        <translation>Alihkan kaca pembesar</translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/colorgrabwidget.cpp" line="61"/>
        <source>Cancel</source>
        <translation>Batalkan</translation>
    </message>
</context>
<context>
    <name>ColorPickerEditor</name>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="42"/>
        <source>Select Preset:</source>
        <translation>Pilih Preset:</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="53"/>
        <source>Select preset using the spinbox</source>
        <translation>Pilih preset memakai kotak putar</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="56"/>
        <source>Delete</source>
        <translation>Hapus</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="58"/>
        <source>Press button to delete the selected preset</source>
        <translation>Tekan tombol untuk menghapus preset yang dipilih</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="72"/>
        <source>Add Preset:</source>
        <translation>Tambah Prasetel:</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="78"/>
        <source>Enter color manually or select it using the color-wheel</source>
        <translation>Masukkan warna secara manual atau pilih itu dengan menggunakan roda-warna</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="88"/>
        <source>Add</source>
        <translation>Tambah</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="89"/>
        <source>Press button to add preset</source>
        <translation>Tekan tombol untuk menambah prasetel</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="117"/>
        <location filename="../../src/config/colorpickereditor.cpp" line="137"/>
        <source>Error</source>
        <translation>Galat</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="118"/>
        <source>Unable to add preset. Maximum limit reached.</source>
        <translation>Tidak dapat menambahkan prasetel. Batas maksimum tercapai.</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="138"/>
        <source>Unable to remove preset. Minimum limit reached.</source>
        <translation>Tidak dapat menghapus prasetel. Batas minimum tercapai.</translation>
    </message>
</context>
<context>
    <name>ConfigErrorDetails</name>
    <message>
        <location filename="../../src/config/configerrordetails.cpp" line="20"/>
        <source>Configuration errors</source>
        <translation>Kesalahan konfigurasi</translation>
    </message>
</context>
<context>
    <name>ConfigHandler</name>
    <message>
        <location filename="../../src/utils/confighandler.cpp" line="549"/>
        <source>Unrecognized setting: &apos;%1&apos;
</source>
        <translation>Pengaturan tidak dikenal: &apos;%1&apos;
</translation>
    </message>
    <message>
        <location filename="../../src/utils/confighandler.cpp" line="557"/>
        <source>Unrecognized shortcut name: &apos;%1&apos;.
</source>
        <translation>Nama shortcut tidak dikenal: &apos;%1&apos;.
</translation>
    </message>
    <message>
        <location filename="../../src/utils/confighandler.cpp" line="600"/>
        <source>Shortcut conflict: &apos;%1&apos; and &apos;%2&apos; have the same shortcut: %3
</source>
        <translation>Konflik shortcut: &apos;%1&apos; dan &apos;%2&apos; memiliki shortcut yang samaL %3
</translation>
    </message>
    <message>
        <location filename="../../src/utils/confighandler.cpp" line="640"/>
        <source>Bad value in &apos;%1&apos;. Expected: %2
</source>
        <translation>Nilai buruk pada &apos;%1&apos;: Seharusnya: %2
</translation>
    </message>
    <message>
        <location filename="../../src/utils/confighandler.cpp" line="690"/>
        <source>You have successfully resolved the configuration error.</source>
        <translation>Anda telah berhasil mengatasi kesalahan konfigurasi.</translation>
    </message>
    <message>
        <location filename="../../src/utils/confighandler.cpp" line="713"/>
        <source>The configuration contains an error. Open configuration to resolve.</source>
        <translation>Konfigurasi berisi kesalahan. Buka konfigurasi untuk mengatasinya.</translation>
    </message>
    <message>
        <location filename="../../src/utils/confighandler.cpp" line="767"/>
        <source>Bad config key &apos;%1&apos; in ConfigHandler. Please report this as a bug.</source>
        <translation>Kunci konfig &apos;%1&apos; buruk pada ConfigHandler. Mohon laporkan ini sebagai bug.</translation>
    </message>
</context>
<context>
    <name>ConfigResolver</name>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="14"/>
        <source>Resolve configuration errors</source>
        <translation>Atasi kesalahan konfigurasi</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="50"/>
        <source>&lt;b&gt;You must resolve all errors before continuing:&lt;/b&gt;</source>
        <translation>&lt;b&gt;Anda harus mengatasi semua kesalahan sebelum lanjut:&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="61"/>
        <source>Reset</source>
        <translation>Atur ulang</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="63"/>
        <source>Reset to the default value.</source>
        <translation>Atur ulang ke nilai default.</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="77"/>
        <source>Remove</source>
        <translation>Hapus</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="79"/>
        <source>Remove this setting.</source>
        <translation>Hapus pengaturan ini.</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="90"/>
        <source>Some keyboard shortcuts have conflicts.
This will NOT prevent flameshot from starting.
Please solve them manually in the configuration file.</source>
        <translation>Beberapa shortcut keyboard memiliki konflik.
Ini TIDAK akan menahan flameshot untuk memulai.
Mohon atasi mereka secara manual di file konfigurasi.</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="112"/>
        <source>Resolve all</source>
        <translation>Atasi semua</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="113"/>
        <source>Resolve all listed errors.</source>
        <translation>Atasi semua kesalahan yang terdaftar.</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="125"/>
        <source>Details</source>
        <translation>Detail</translation>
    </message>
</context>
<context>
    <name>ConfigWindow</name>
    <message>
        <location filename="../../src/config/configwindow.cpp" line="42"/>
        <source>Configuration</source>
        <translation>Pengaturan</translation>
    </message>
    <message>
        <location filename="../../src/config/configwindow.cpp" line="61"/>
        <source>Interface</source>
        <translation>Antarmuka</translation>
    </message>
    <message>
        <location filename="../../src/config/configwindow.cpp" line="71"/>
        <source>Filename Editor</source>
        <translation>Pengaturan Nama File</translation>
    </message>
    <message>
        <location filename="../../src/config/configwindow.cpp" line="80"/>
        <source>General</source>
        <translation>Umum</translation>
    </message>
    <message>
        <location filename="../../src/config/configwindow.cpp" line="89"/>
        <source>Shortcuts</source>
        <translation>Pintasan</translation>
    </message>
    <message>
        <location filename="../../src/config/configwindow.cpp" line="122"/>
        <source>Resolve</source>
        <translation>Atasi</translation>
    </message>
    <message>
        <location filename="../../src/config/configwindow.cpp" line="126"/>
        <source>&lt;b&gt;Configuration file has errors. Resolve them before continuing.&lt;/b&gt;</source>
        <translation>&lt;b&gt;File konfigurasi memiliki kesalahan. Atasi mereka sebelum melanjutkan.&lt;/b&gt;</translation>
    </message>
</context>
<context>
    <name>Controller</name>
    <message>
        <location filename="../../src/core/controller.cpp" line="217"/>
        <source>New version %1 is available</source>
        <translation>Versi baru %1 tersedia</translation>
    </message>
    <message>
        <location filename="../../src/core/controller.cpp" line="226"/>
        <source>You have the latest version</source>
        <translation>Anda telah menggunakan versi terbaru</translation>
    </message>
    <message>
        <location filename="../../src/core/controller.cpp" line="234"/>
        <source>Failed to get information about the latest version.</source>
        <translation>Gagal mengambil informasi versi terbaru.</translation>
    </message>
    <message>
        <location filename="../../src/core/controller.cpp" line="317"/>
        <source>Error</source>
        <translation>Galat</translation>
    </message>
    <message>
        <location filename="../../src/core/controller.cpp" line="317"/>
        <source>Unable to close active modal widgets</source>
        <translation>Tidak dapat menutup widget modal aktif</translation>
    </message>
    <message>
        <location filename="../../src/core/controller.cpp" line="479"/>
        <source>&amp;Open Launcher</source>
        <translation>&amp;Buka Peluncur</translation>
    </message>
    <message>
        <location filename="../../src/core/controller.cpp" line="484"/>
        <source>&amp;Configuration</source>
        <translation>&amp;Pengaturan</translation>
    </message>
    <message>
        <location filename="../../src/core/controller.cpp" line="487"/>
        <source>&amp;About</source>
        <translation>&amp;Ihwal</translation>
    </message>
    <message>
        <location filename="../../src/core/controller.cpp" line="490"/>
        <source>Check for updates</source>
        <translation>Periksa pembaruan</translation>
    </message>
    <message>
        <location filename="../../src/core/controller.cpp" line="497"/>
        <source>&amp;Latest Uploads</source>
        <translation>&amp;Unggahan Terbaru</translation>
    </message>
    <message>
        <location filename="../../src/core/controller.cpp" line="678"/>
        <source>URL copied to clipboard.</source>
        <translation>URL tersalin ke clipboard.</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation type="vanished">&amp;Informació</translation>
    </message>
    <message>
        <location filename="../../src/core/controller.cpp" line="493"/>
        <source>&amp;Quit</source>
        <translation>&amp;Hentikan Flameshot</translation>
    </message>
    <message>
        <location filename="../../src/core/controller.cpp" line="463"/>
        <source>&amp;Take Screenshot</source>
        <translation>&amp;Ambil Cuplikan Layar</translation>
    </message>
</context>
<context>
    <name>CopyTool</name>
    <message>
        <location filename="../../src/tools/copy/copytool.cpp" line="24"/>
        <source>Copy</source>
        <translation>Salin</translation>
    </message>
    <message>
        <location filename="../../src/tools/copy/copytool.cpp" line="34"/>
        <source>Copy selection to clipboard</source>
        <translation>Salin pilihan ke clipboard</translation>
    </message>
    <message>
        <source>Copy the selection into the clipboard</source>
        <translation type="vanished">Salin seleksi terpilih ke papan klip</translation>
    </message>
</context>
<context>
    <name>DBusUtils</name>
    <message>
        <source>Unable to connect via DBus</source>
        <translation type="vanished">Tidak dapat terhubung melalui DBus</translation>
    </message>
</context>
<context>
    <name>ExitTool</name>
    <message>
        <location filename="../../src/tools/exit/exittool.cpp" line="23"/>
        <source>Exit</source>
        <translation>Keluar</translation>
    </message>
    <message>
        <location filename="../../src/tools/exit/exittool.cpp" line="33"/>
        <source>Leave the capture screen</source>
        <translation>Tinggalkan cuplikan layar</translation>
    </message>
</context>
<context>
    <name>FileNameEditor</name>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="24"/>
        <source>Edit the name of your captures:</source>
        <translation>Ubah nama hasil tangkapan:</translation>
    </message>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="28"/>
        <source>Edit:</source>
        <translation>Sunting:</translation>
    </message>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="30"/>
        <source>Preview:</source>
        <translation>Pratinjau:</translation>
    </message>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="73"/>
        <source>Save</source>
        <translation>Simpan</translation>
    </message>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="76"/>
        <source>Saves the pattern</source>
        <translation>Simpan pola</translation>
    </message>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="78"/>
        <source>Restore</source>
        <translation>Pulihkan</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="vanished">Reinicialitza</translation>
    </message>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="81"/>
        <source>Restores the saved pattern</source>
        <translation>Pulihkan pola yang tersimpan</translation>
    </message>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="83"/>
        <source>Clear</source>
        <translation>Kosongkan</translation>
    </message>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="89"/>
        <source>Deletes the name</source>
        <translation>Hapus nama</translation>
    </message>
</context>
<context>
    <name>FlameshotDaemon</name>
    <message>
        <location filename="../../src/core/flameshotdaemon.cpp" line="264"/>
        <source>Unable to connect via DBus</source>
        <translation>Tidak dapat terhubung via DBus</translation>
    </message>
</context>
<context>
    <name>GeneneralConf</name>
    <message>
        <source>Show help message</source>
        <translation type="vanished">Mostra el missatge d&apos;ajuda</translation>
    </message>
    <message>
        <source>Show the help message at the beginning in the capture mode.</source>
        <translation type="vanished">Mostra el missatge d&apos;ajuda en iniciar el mode de captura.</translation>
    </message>
    <message>
        <source>Show desktop notifications</source>
        <translation type="vanished">Mostra les notificacions d&apos;escriptori</translation>
    </message>
    <message>
        <source>Show tray icon</source>
        <translation type="vanished">Mostra la icona en la barra de tasques</translation>
    </message>
    <message>
        <source>Show the systemtray icon</source>
        <translation type="vanished">Mostra la icona en la barra de tasques</translation>
    </message>
    <message>
        <source>Import</source>
        <translation type="vanished">Importar</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="vanished">Error</translation>
    </message>
    <message>
        <source>Unable to read file.</source>
        <translation type="vanished">Impossible llegir el fitxer.</translation>
    </message>
    <message>
        <source>Unable to write file.</source>
        <translation type="vanished">Impossible escriure al fitxer.</translation>
    </message>
    <message>
        <source>Save File</source>
        <translation type="vanished">Guardar Arxiu</translation>
    </message>
    <message>
        <source>Confirm Reset</source>
        <translation type="vanished">Confirmar Reset</translation>
    </message>
    <message>
        <source>Are you sure you want to reset the configuration?</source>
        <translation type="vanished">Esteu segur que voleu reiniciar la configuració?</translation>
    </message>
    <message>
        <source>Configuration File</source>
        <translation type="vanished">Fitxer de Configuració</translation>
    </message>
    <message>
        <source>Export</source>
        <translation type="vanished">Exportar</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="vanished">Reset</translation>
    </message>
    <message>
        <source>Launch at startup</source>
        <translation type="vanished">Llançament a l&apos;inici</translation>
    </message>
</context>
<context>
    <name>GeneralConf</name>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="149"/>
        <location filename="../../src/config/generalconf.cpp" line="306"/>
        <source>Import</source>
        <translation>Impor</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="156"/>
        <location filename="../../src/config/generalconf.cpp" line="164"/>
        <location filename="../../src/config/generalconf.cpp" line="188"/>
        <location filename="../../src/config/generalconf.cpp" line="626"/>
        <source>Error</source>
        <translation>Galat</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="156"/>
        <source>Unable to read file.</source>
        <translation>Tidak bisa membaca berkas.</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="164"/>
        <location filename="../../src/config/generalconf.cpp" line="188"/>
        <source>Unable to write file.</source>
        <translation>Tak bisa menulis berkas.</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="175"/>
        <source>Save File</source>
        <translation>Simpan File</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="197"/>
        <source>Confirm Reset</source>
        <translation>Konfirmasi atur ulang</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="198"/>
        <source>Are you sure you want to reset the configuration?</source>
        <translation>Apakah Anda yakin ingin mengatur ulang konfigurasi?</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="229"/>
        <source>Show help message</source>
        <translation>Tampilkan pesan bantuan</translation>
    </message>
    <message>
        <source>Show the help message at the beginning in the capture mode.</source>
        <translation type="vanished">Tampilkan pesan bantuan di awal dalam mode capture.</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="240"/>
        <source>Show the side panel button</source>
        <translation>Tampilkan tombol panel samping</translation>
    </message>
    <message>
        <source>Show the side panel toggle button in the capture mode.</source>
        <translation type="vanished">Tampilkan tombol panel samping di mode capture.</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="253"/>
        <source>Show desktop notifications</source>
        <translation>Tampilkan notifikasi desktop</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="266"/>
        <source>Show tray icon</source>
        <translation>Tampilkan ikon baki</translation>
    </message>
    <message>
        <source>Show the systemtray icon</source>
        <translation type="vanished">Tampilkan ikon baki sistem</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="279"/>
        <source>Confirmation required to delete screenshot from the latest uploads</source>
        <translation>Konfirmasi diperlukan untuk menghapus screenshot dari unggahan terbaru</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="294"/>
        <source>Configuration File</source>
        <translation>Konfigurasi Berkas</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="299"/>
        <source>Export</source>
        <translation>Ekspor</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="313"/>
        <source>Reset</source>
        <translation>Setel ulang</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="323"/>
        <source>Automatic check for updates</source>
        <translation>Pemeriksaan otomatis pembaruan</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="336"/>
        <source>Allow multiple flameshot GUI instances simultaneously</source>
        <translation>Izinkan beberapa instance flameshot GUI secara bersamaan</translation>
    </message>
    <message>
        <source>This allows you to take screenshots of flameshot itself for example.</source>
        <translation type="vanished">Ini memungkinkan Anda untuk mengambil screenshot dari flameshot itu sendiri misalnya.</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="349"/>
        <location filename="../../src/config/generalconf.cpp" line="351"/>
        <source>Automatically close daemon when it is not needed</source>
        <translation>Otomatis tutup daemon ketika tidak dibutuhkan</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="361"/>
        <source>Launch at startup</source>
        <translation>Luncurkan saat startup</translation>
    </message>
    <message>
        <source>Launch Flameshot</source>
        <translation type="vanished">Luncurkan Flameshot</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="373"/>
        <source>Show welcome message on launch</source>
        <translation>Tampilkan pesan selamat datang saat peluncuran</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="388"/>
        <source>Use large predefined color palette</source>
        <translation>Gunakan palet warna besar yang telah ditentukan</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="402"/>
        <source>Copy URL after upload</source>
        <translation>Salin URL setelah mengunggah</translation>
    </message>
    <message>
        <source>Copy URL and close window after upload</source>
        <translation type="vanished">Salin URL dan tutup jendela setelah mengunggah</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="414"/>
        <source>Save image after copy</source>
        <translation>Simpan gambar setelah menyalin</translation>
    </message>
    <message>
        <source>Save image file after copying it</source>
        <translation type="vanished">Simpan file gambar setelah menyalinnya</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="230"/>
        <source>Show the help message at the beginning in the capture mode</source>
        <translation>Tampilkan pesan bantuan pada awal dalam mode penangkapan</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="242"/>
        <source>Show the side panel toggle button in the capture mode</source>
        <translation>Tampilkan tombol jungkit Panel samping pada mode penangkapan</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="254"/>
        <source>Enable desktop notifications</source>
        <translation>Aktifkan pemberitahuan desktop</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="267"/>
        <source>Show icon in the system tray</source>
        <translation>Tampilkan ikon di baki sistem</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="282"/>
        <source>Ask for confirmation to delete screenshot from the latest uploads</source>
        <translation>Tanyakan konfirmasi untuk menghapus cuplikan layar dari upload terbaru</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="324"/>
        <source>Check for updates automatically</source>
        <translation>Periksa pemutakhiran secara otomatis</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="337"/>
        <source>This allows you to take screenshots of Flameshot itself for example</source>
        <translation>Hal ini memungkinkan Anda untuk mengambil cuplikan layar dari nyala api sendiri misalnya</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="363"/>
        <source>Launch Flameshot daemon when computer is booted</source>
        <translation>Luncurkan Jurik Flameshot ketika komputer dinyalakan</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="376"/>
        <source>Show the welcome message box in the middle of the screen while taking a screenshot</source>
        <translation>Tampilkan kotak pesan sambutan di tengah layar saat mengambil cuplikan layar</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="390"/>
        <source>Use a large predefined color palette</source>
        <translation>Palet warna terpradefinisi</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="404"/>
        <source>Copy URL and close window after uploading was successful</source>
        <translation>Salin URL dan tutup jendela setelah mengunggah berhasil</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="416"/>
        <source>After copying the screenshot, save it to a file as well</source>
        <translation>Setelah menyalin cuplikan layar, simpan ke berkas juga</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="423"/>
        <source>Save Path</source>
        <translation>Simpan Jalur</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="439"/>
        <source>Change...</source>
        <translation>Ubah...</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="447"/>
        <source>Use fixed path for screenshots to save</source>
        <translation>Gunakan lokasi tetap untuk menyimpan tangkapan layar</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="459"/>
        <source>Preferred save file extension:</source>
        <translation>Ekstensi file penyimpanan yang disukai:</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="489"/>
        <source>Latest Uploads Max Size</source>
        <translation>Ukuran Maksimal Unggahan Terbaru</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="516"/>
        <source>Undo limit</source>
        <translation>Batas undurkan</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="542"/>
        <location filename="../../src/config/generalconf.cpp" line="544"/>
        <source>Use JPG format for clipboard (PNG default)</source>
        <translation>Gunakan format JPG untuk clipboard (PNG default)</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="574"/>
        <source>Copy file path after save</source>
        <translation>Salin lokasi file setelah menyimpan</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="575"/>
        <source>Copy the file path to clipboard after the file is saved</source>
        <translation>Salin lokasi berkas ke papan klip setelah berkas disimpan</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="586"/>
        <source>Anti-aliasing image when zoom the pinned image</source>
        <translation>Gambar anti-aliasing saat memperbesar gambar yang disematkan</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="588"/>
        <source>After zooming the pinned image, should the image get smoothened or stay pixelated</source>
        <translation>Setelah memperbesar gambar tersemat, harusnya gambar diperhalus atau tetap ber pixel</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="599"/>
        <location filename="../../src/config/generalconf.cpp" line="601"/>
        <source>Upload image without confirmation</source>
        <translation>Unggah gambar tanpa konfirmasi</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="617"/>
        <source>Choose a Folder</source>
        <translation>Pilih Folder</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="626"/>
        <source>Unable to write to directory.</source>
        <translation>Tidak dapat menulis ke direktori.</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="635"/>
        <source>Show magnifier</source>
        <translation>Tampilkan pembesar</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="636"/>
        <source>Enable a magnifier while selecting the screenshot area</source>
        <translation>Aktifkan magnifier saat memilih area cuplikan layar</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="647"/>
        <source>Square shaped magnifier</source>
        <translation>Kaca pembesar persegi</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="648"/>
        <source>Make the magnifier to be square-shaped</source>
        <translation>Membuat pembesar harus berbentuk persegi</translation>
    </message>
</context>
<context>
    <name>HistoryWidget</name>
    <message>
        <source>Latest Uploads</source>
        <translation type="vanished">Upload Terbaru</translation>
    </message>
    <message>
        <source>Screenshots history is empty</source>
        <translation type="vanished">Riwayat cuplikan layar kosong</translation>
    </message>
    <message>
        <source>Copy URL</source>
        <translation type="vanished">Salin URL</translation>
    </message>
    <message>
        <source>URL copied to clipboard.</source>
        <translation type="vanished">URL disalin ke papan klip.</translation>
    </message>
    <message>
        <source>Open in browser</source>
        <translation type="vanished">Buka di peramban</translation>
    </message>
    <message>
        <source>Confirm to delete</source>
        <translation type="vanished">Konfirmasi hapus</translation>
    </message>
    <message>
        <source>Are you sure you want to delete a screenshot from the latest uploads and server?</source>
        <translation type="vanished">Apakah Anda yakin ingin menghapus screenshot dari unggahan terbaru dan server?</translation>
    </message>
</context>
<context>
    <name>ImgS3Uploader</name>
    <message>
        <source>Uploading Image</source>
        <translation type="obsolete">S&apos;està pujant la imatge</translation>
    </message>
    <message>
        <source>URL copied to clipboard.</source>
        <translation type="obsolete">L&apos;URL s&apos;ha copiat al porta-retalls.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="obsolete">Error</translation>
    </message>
</context>
<context>
    <name>ImgUploadDialog</name>
    <message>
        <location filename="../../src/widgets/imguploaddialog.cpp" line="18"/>
        <source>Upload Confirmation</source>
        <translation>Konfirmasi Unggahan</translation>
    </message>
    <message>
        <location filename="../../src/widgets/imguploaddialog.cpp" line="22"/>
        <source>Do you want to upload this capture?</source>
        <translation>Apakah Anda ingin mengunggah capture ini?</translation>
    </message>
    <message>
        <location filename="../../src/widgets/imguploaddialog.cpp" line="35"/>
        <location filename="../../src/widgets/imguploaddialog.cpp" line="36"/>
        <source>Upload without confirmation</source>
        <translation>Unggah tanpa konfirmasi</translation>
    </message>
</context>
<context>
    <name>ImgUploader</name>
    <message>
        <source>Uploading Image</source>
        <translation type="obsolete">S&apos;està pujant la imatge</translation>
    </message>
    <message>
        <source>Delete image</source>
        <translation type="obsolete">Esborra la imatge</translation>
    </message>
    <message>
        <source>Unable to open the URL.</source>
        <translation type="obsolete">No es pot obrir l&apos;URL.</translation>
    </message>
    <message>
        <source>URL copied to clipboard.</source>
        <translation type="obsolete">L&apos;URL s&apos;ha copiat al porta-retalls.</translation>
    </message>
    <message>
        <source>Screenshot copied to clipboard.</source>
        <translation type="obsolete">La captura s&apos;ha copiat al porta-retalls.</translation>
    </message>
    <message>
        <source>Copy URL</source>
        <translation type="obsolete">Copia l&apos;URL</translation>
    </message>
    <message>
        <source>Open URL</source>
        <translation type="obsolete">Obri l&apos;URL</translation>
    </message>
    <message>
        <source>Image to Clipboard.</source>
        <translation type="obsolete">Imatge al porta-retalls.</translation>
    </message>
</context>
<context>
    <name>ImgUploaderBase</name>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="37"/>
        <source>Upload image</source>
        <translation>Unggah gambar</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="51"/>
        <source>Uploading Image</source>
        <translation>Mengunggah Gambar</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="130"/>
        <source>Copy URL</source>
        <translation>Salin URL</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="131"/>
        <source>Open URL</source>
        <translation>Buka URL</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="132"/>
        <source>Delete image</source>
        <translation>Hapus gambar</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="133"/>
        <source>Image to Clipboard.</source>
        <translation>Gambar ke Clipboard.</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="134"/>
        <source>Save image</source>
        <translation>Simpan gambar</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="164"/>
        <source>Unable to open the URL.</source>
        <translation>Tidak dapat membuka URL.</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="171"/>
        <source>URL copied to clipboard.</source>
        <translation>URL tersalin ke clipboard.</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="177"/>
        <source>Screenshot copied to clipboard.</source>
        <translation>Screenshot tersalin ke clipboard.</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="191"/>
        <source>Unable to save the screenshot to disk.</source>
        <translation>Tidak dapat menyimpan cuplikan layar ke disk.</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="194"/>
        <source>Screenshot saved.</source>
        <translation>Cuplikan layar disimpan.</translation>
    </message>
</context>
<context>
    <name>ImgUploaderTool</name>
    <message>
        <location filename="../../src/tools/imgupload/imguploadertool.cpp" line="23"/>
        <source>Image Uploader</source>
        <translation>Pengunggah Gambar</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/imguploadertool.cpp" line="33"/>
        <source>Upload the selection</source>
        <translation>Unggah pilihan</translation>
    </message>
</context>
<context>
    <name>ImgurUploader</name>
    <message>
        <source>Upload to Imgur</source>
        <translation type="vanished">Unggah ke Imgur</translation>
    </message>
    <message>
        <source>Uploading Image</source>
        <translation type="vanished">Mengunggah Gambar</translation>
    </message>
    <message>
        <source>Copy URL</source>
        <translation type="vanished">Salin URL</translation>
    </message>
    <message>
        <source>Open URL</source>
        <translation type="vanished">Buka URL</translation>
    </message>
    <message>
        <source>Delete image</source>
        <translation type="vanished">Hapus gambar</translation>
    </message>
    <message>
        <source>Image to Clipboard.</source>
        <translation type="vanished">Image to Clipboard.</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imgur/imguruploader.cpp" line="92"/>
        <source>Unable to open the URL.</source>
        <translation>Tidak dapat membuka URL.</translation>
    </message>
    <message>
        <source>URL copied to clipboard.</source>
        <translation type="vanished">URL disalin ke papan klip.</translation>
    </message>
    <message>
        <source>Screenshot copied to clipboard.</source>
        <translation type="vanished">Cuplikan layar disalin ke papan klip.</translation>
    </message>
</context>
<context>
    <name>ImgurUploaderTool</name>
    <message>
        <source>Image Uploader</source>
        <translation type="vanished">Pengunggah Gambar</translation>
    </message>
    <message>
        <source>Upload the selection to Imgur</source>
        <translation type="vanished">Upload the selection to Imgur</translation>
    </message>
</context>
<context>
    <name>InfoWindow</name>
    <message>
        <location filename="../../src/widgets/infowindow.ui" line="14"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_infowindow.h" line="117"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_infowindow.h" line="117"/>
        <source>About</source>
        <translation>Tentang</translation>
    </message>
    <message>
        <location filename="../../src/widgets/infowindow.ui" line="26"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_infowindow.h" line="118"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_infowindow.h" line="118"/>
        <source>Icon</source>
        <translation>Ikon</translation>
    </message>
    <message>
        <location filename="../../src/widgets/infowindow.ui" line="43"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_infowindow.h" line="119"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_infowindow.h" line="119"/>
        <source>License</source>
        <translation>Lisensi</translation>
    </message>
    <message>
        <location filename="../../src/widgets/infowindow.ui" line="56"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_infowindow.h" line="120"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_infowindow.h" line="120"/>
        <source>GPLv3+</source>
        <translation>GPL v3+</translation>
    </message>
    <message>
        <location filename="../../src/widgets/infowindow.ui" line="89"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_infowindow.h" line="121"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_infowindow.h" line="121"/>
        <source>Version</source>
        <translation>Versi</translation>
    </message>
    <message>
        <location filename="../../src/widgets/infowindow.ui" line="102"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_infowindow.h" line="122"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_infowindow.h" line="122"/>
        <source>Flameshot v</source>
        <translation>Flameshot v</translation>
    </message>
    <message>
        <location filename="../../src/widgets/infowindow.ui" line="115"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_infowindow.h" line="123"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_infowindow.h" line="123"/>
        <source>OS Info</source>
        <translation>Info OS</translation>
    </message>
    <message>
        <location filename="../../src/widgets/infowindow.ui" line="128"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_infowindow.h" line="124"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_infowindow.h" line="124"/>
        <source>Copy Info</source>
        <translation>Salin Info</translation>
    </message>
    <message>
        <source>Right Click</source>
        <translation type="vanished">Clic dret</translation>
    </message>
    <message>
        <source>Mouse Wheel</source>
        <translation type="vanished">Roda del ratolí</translation>
    </message>
    <message>
        <source>Move selection 1px</source>
        <translation type="vanished">Mou la selecció 1 px</translation>
    </message>
    <message>
        <source>Resize selection 1px</source>
        <translation type="vanished">Redimensiona la selecció 1 px</translation>
    </message>
    <message>
        <source>Quit capture</source>
        <translation type="vanished">Ix de la captura</translation>
    </message>
    <message>
        <source>Copy to clipboard</source>
        <translation type="vanished">Copia al porta-retalls</translation>
    </message>
    <message>
        <source>Save selection as a file</source>
        <translation type="vanished">Guarda la selecció com a fitxer</translation>
    </message>
    <message>
        <source>Undo the last modification</source>
        <translation type="vanished">Desfés l&apos;última modificació</translation>
    </message>
    <message>
        <source>Show color picker</source>
        <translation type="vanished">Mostra el selector de color</translation>
    </message>
    <message>
        <source>Change the tool&apos;s thickness</source>
        <translation type="vanished">Canvia el gruix de l&apos;eina</translation>
    </message>
    <message>
        <source>Key</source>
        <translation type="vanished">Tecla</translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="vanished">Descripció</translation>
    </message>
    <message>
        <source>&lt;u&gt;&lt;b&gt;License&lt;/b&gt;&lt;/u&gt;</source>
        <translation type="vanished">&lt;u&gt;&lt;b&gt;Lisensi&lt;/b&gt;&lt;/u&gt;</translation>
    </message>
    <message>
        <source>&lt;u&gt;&lt;b&gt;Version&lt;/b&gt;&lt;/u&gt;</source>
        <translation type="vanished">&lt;u&gt;&lt;b&gt;Versi&lt;/b&gt;&lt;/u&gt;</translation>
    </message>
    <message>
        <source>&lt;u&gt;&lt;b&gt;Shortcuts&lt;/b&gt;&lt;/u&gt;</source>
        <translation type="vanished">&lt;u&gt;&lt;b&gt;Dreceres&lt;/b&gt;&lt;/u&gt;</translation>
    </message>
    <message>
        <source>Available shortcuts in the screen capture mode.</source>
        <translation type="vanished">Dreceres disponibles en el mode de captura de pantalla.</translation>
    </message>
</context>
<context>
    <name>InvertTool</name>
    <message>
        <location filename="../../src/tools/invert/inverttool.cpp" line="25"/>
        <source>Invert</source>
        <translation>Balikkan</translation>
    </message>
    <message>
        <location filename="../../src/tools/invert/inverttool.cpp" line="35"/>
        <source>Set Inverter as the paint tool</source>
        <translation>Atur inverter sebagai paint tool</translation>
    </message>
</context>
<context>
    <name>LineTool</name>
    <message>
        <location filename="../../src/tools/line/linetool.cpp" line="22"/>
        <source>Line</source>
        <translation>Garis</translation>
    </message>
    <message>
        <location filename="../../src/tools/line/linetool.cpp" line="32"/>
        <source>Set the Line as the paint tool</source>
        <translation>Atur garis sebagai alat gambar</translation>
    </message>
</context>
<context>
    <name>MarkerTool</name>
    <message>
        <location filename="../../src/tools/marker/markertool.cpp" line="23"/>
        <source>Marker</source>
        <translation>Penanda</translation>
    </message>
    <message>
        <location filename="../../src/tools/marker/markertool.cpp" line="33"/>
        <source>Set the Marker as the paint tool</source>
        <translation>Atur penanda sebagai paint tool</translation>
    </message>
</context>
<context>
    <name>MoveTool</name>
    <message>
        <location filename="../../src/tools/move/movetool.cpp" line="23"/>
        <source>Move</source>
        <translation>Geser</translation>
    </message>
    <message>
        <location filename="../../src/tools/move/movetool.cpp" line="33"/>
        <source>Move the selection area</source>
        <translation>Geser daerah terseleksi</translation>
    </message>
</context>
<context>
    <name>PencilTool</name>
    <message>
        <location filename="../../src/tools/pencil/penciltool.cpp" line="18"/>
        <source>Pencil</source>
        <translation>Pensil</translation>
    </message>
    <message>
        <location filename="../../src/tools/pencil/penciltool.cpp" line="28"/>
        <source>Set the Pencil as the paint tool</source>
        <translation>Atur pensil sebagai alat gambar</translation>
    </message>
</context>
<context>
    <name>PinTool</name>
    <message>
        <location filename="../../src/tools/pin/pintool.cpp" line="25"/>
        <source>Pin Tool</source>
        <translation>Alat Semat</translation>
    </message>
    <message>
        <location filename="../../src/tools/pin/pintool.cpp" line="35"/>
        <source>Pin image on the desktop</source>
        <translation>Sematkan gambar ke desktop</translation>
    </message>
</context>
<context>
    <name>PixelateTool</name>
    <message>
        <location filename="../../src/tools/pixelate/pixelatetool.cpp" line="24"/>
        <source>Pixelate</source>
        <translation>Piksel</translation>
    </message>
    <message>
        <location filename="../../src/tools/pixelate/pixelatetool.cpp" line="34"/>
        <source>Set Pixelate as the paint tool</source>
        <translation>Atur Pixelate sebagai paint tool</translation>
    </message>
</context>
<context>
    <name>QHotkey</name>
    <message>
        <location filename="../../external/QHotkey/qhotkey.cpp" line="307"/>
        <source>Failed to register %1. Error: %2</source>
        <translation>Gagal untuk mendaftarkan %1. Kesalahan: %2</translation>
    </message>
    <message>
        <location filename="../../external/QHotkey/qhotkey.cpp" line="329"/>
        <source>Failed to unregister %1. Error: %2</source>
        <translation>Gagal untuk membatalkan pendaftaran %1. Kesalahan: %2</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../src/utils/screenshotsaver.cpp" line="136"/>
        <location filename="../../src/utils/screenshotsaver.cpp" line="138"/>
        <source>Capture saved to clipboard.</source>
        <translation>Cuplikan layar tersimpan ke papan klip.</translation>
    </message>
    <message>
        <location filename="../../src/utils/screenshotsaver.cpp" line="122"/>
        <source>Error while saving to clipboard</source>
        <translation>Gagal saat menyimpan ke papan klip</translation>
    </message>
    <message>
        <location filename="../../src/utils/screenshotsaver.cpp" line="181"/>
        <source>Save screenshot</source>
        <translation>Simpan cuplikan layar</translation>
    </message>
    <message>
        <location filename="../../src/utils/screenshotsaver.cpp" line="203"/>
        <source>Path copied to clipboard as </source>
        <translation>Jalur tersalin ke clipboard sebagai </translation>
    </message>
    <message>
        <source>Saving canceled</source>
        <translation type="vanished">Menyimpan dibatalkan</translation>
    </message>
    <message>
        <source>Save canceled</source>
        <translation type="vanished">Simpan dibatalkan</translation>
    </message>
    <message>
        <source>Capture is saved and copied to the clipboard as </source>
        <translation type="vanished">Cuplikan layar tersimpan dan disalin ke papan klip sebagai </translation>
    </message>
    <message>
        <location filename="../../src/utils/screenshotsaver.cpp" line="214"/>
        <source>Save Error</source>
        <translation>Gagal menyimpan</translation>
    </message>
    <message>
        <location filename="../../src/utils/screenshotsaver.cpp" line="46"/>
        <location filename="../../src/utils/screenshotsaver.cpp" line="198"/>
        <source>Capture saved as </source>
        <translation>Cuplikan layar disimpan sebagai </translation>
    </message>
    <message>
        <location filename="../../src/utils/screenshotsaver.cpp" line="50"/>
        <location filename="../../src/utils/screenshotsaver.cpp" line="207"/>
        <source>Error trying to save as </source>
        <translation>Gagal ketika mencoba menyimpan sebagai </translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="135"/>
        <source>Unable to connect via DBus</source>
        <translation>Tidak dapat terhubung melalui DBus</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="151"/>
        <source>Powerful yet simple to use screenshot software.</source>
        <translation>Software screenshot yang kuat namun mudah digunakan.</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="152"/>
        <source>See</source>
        <translation>Lihat</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="155"/>
        <source>Capture the entire desktop.</source>
        <translation>Ambil cuplikan layar seluruh desktop.</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="157"/>
        <source>Open the capture launcher.</source>
        <translation>Buka peluncur capture.</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="160"/>
        <source>Start a manual capture in GUI mode.</source>
        <translation>Jalankan capture manual di mode GUI.</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="162"/>
        <source>Configure</source>
        <translation>Konfigurasikan</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="164"/>
        <source>Capture a single screen.</source>
        <translation>Caputre satu layar.</translation>
    </message>
    <message>
        <source>Path where the capture will be saved</source>
        <translation type="vanished">Path where the capture will be saved</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="169"/>
        <source>Existing directory or new file to save to</source>
        <translation>Direktori yang ada atau file baru untuk disimpan</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="172"/>
        <source>Save the capture to the clipboard</source>
        <translation>Simpan cuplikan layar ke papan klip</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="174"/>
        <source>Pin the capture to the screen</source>
        <translation>Sematkan capture ke layar</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="176"/>
        <source>Upload screenshot</source>
        <translation>Unggah tangkapan layar</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="178"/>
        <source>Delay time in milliseconds</source>
        <translation>Waktu jeda dalam milidetik</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="181"/>
        <source>Screenshot region to select</source>
        <translation>Daerah tangkapan layar untuk dipilih</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="184"/>
        <source>Set the filename pattern</source>
        <translation>Atur pola nama file</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="188"/>
        <source>Accept capture as soon as a selection is made</source>
        <translation>Terima capture segera setelah seleksi dibuat</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="190"/>
        <source>Enable or disable the trayicon</source>
        <translation>Hidupkan atau matikan ikon baki</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="194"/>
        <source>Enable or disable run at startup</source>
        <translation>Hidupkan atau matikan jalan saat startup</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="197"/>
        <source>Check the configuration for errors</source>
        <translation>Cek kesalahan dari konfigurasi</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="200"/>
        <source>Show the help message in the capture mode</source>
        <translation>Tampilkan pesan bantuan di mode capture</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="203"/>
        <source>Define the main UI color</source>
        <translation>Definisikan warna utama UI</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="207"/>
        <source>Define the contrast UI color</source>
        <translation>Definisikan warna kontras UI</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="210"/>
        <source>Print raw PNG capture</source>
        <translation>Cetak capture PNG raw</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="213"/>
        <source>Print geometry of the selection in the format W H X Y. Does nothing if raw is specified</source>
        <translation>Cetak geometri pilihan dalam format W H X Y. Tidak melakukan apa pun jika raw ditentukan</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="217"/>
        <source>Define the screen to capture (starting from 0)</source>
        <translation>Definisikan layar untuk capture (dimulai dari 0)</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="237"/>
        <source>Invalid delay, it must be a number greater than 0</source>
        <translation>Jeda tidak valid, harus berupa angka yang lebih dari 0</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="240"/>
        <source>Invalid region, use &apos;WxH+X+Y&apos; or &apos;all&apos; or &apos;screen0/screen1/...&apos;.</source>
        <translation>Bagian tidak valid, gunakan &apos;WxH+X+Y&apos; atau &apos;all&apos; atau &apos;screen0/screen1/...&apos;.</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="253"/>
        <source>Invalid path, must be an existing directory or a new file in an existing directory</source>
        <translation>Jalur tidak valid, harus berupa direkotri yang sudah ada atau file baru di direktori yang sudah ada</translation>
    </message>
    <message>
        <source>Define the screen to capture</source>
        <translation type="vanished">Define the screen to capture</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="218"/>
        <source>default: screen containing the cursor</source>
        <translation>default: layar berisi kursor</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="219"/>
        <source>Screen number</source>
        <translation>Angka layar</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="228"/>
        <source>Invalid color, this flag supports the following formats:
- #RGB (each of R, G, and B is a single hex digit)
- #RRGGBB
- #RRRGGGBBB
- #RRRRGGGGBBBB
- Named colors like &apos;blue&apos; or &apos;red&apos;
You may need to escape the &apos;#&apos; sign as in &apos;\#FFF&apos;</source>
        <translation>Warna tidak valid, tanda ini mendukung dengan format berikut:
- #RGB (masing-masing R, G, dan B adalah satu digit hex)
- #RRGGBB
- #RRRGGGBBB
- #RRRRGGGGBBBB
- Warna yang bernama seperti &apos;blue&apos; atau &apos;red&apos;
Anda mungkin perlu untuk escape dari tanda &apos;#&apos; seperti pada &apos;\#FFF&apos;</translation>
    </message>
    <message>
        <source>Invalid delay, it must be higher than 0</source>
        <translation type="vanished">Waktu jeda tidak valid, harus lebih besar dari 0</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="239"/>
        <source>Invalid screen number, it must be non negative</source>
        <translation>Angka layar tidak valid, harus berupa non negatif</translation>
    </message>
    <message>
        <source>Invalid path, it must be a real path in the system</source>
        <translation type="vanished">Invalid path, it must be a real path in the system</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="266"/>
        <source>Invalid value, it must be defined as &apos;true&apos; or &apos;false&apos;</source>
        <translation>Nilai tidak valid, harus bernilai &apos;true&apos; atau &apos;false&apos;</translation>
    </message>
    <message>
        <location filename="../../src/tools/launcher/openwithprogram.cpp" line="30"/>
        <source>Error</source>
        <translation>Galat</translation>
    </message>
    <message>
        <location filename="../../src/tools/launcher/openwithprogram.cpp" line="31"/>
        <source>Unable to write in</source>
        <translation>Gagal menulis</translation>
    </message>
    <message>
        <source>Capture saved to clipboard</source>
        <translation type="vanished">Cuplikan layar tersimpan ke papan klip</translation>
    </message>
    <message>
        <source>URL copied to clipboard.</source>
        <translation type="vanished">URL disalin ke papan klip.</translation>
    </message>
    <message>
        <location filename="../../src/cli/commandlineparser.cpp" line="54"/>
        <source>Options</source>
        <translation>Opsi</translation>
    </message>
    <message>
        <location filename="../../src/cli/commandlineparser.cpp" line="68"/>
        <source>Arguments</source>
        <translation>Argumen</translation>
    </message>
    <message>
        <location filename="../../src/cli/commandlineparser.cpp" line="329"/>
        <source>arguments</source>
        <translation>argumen</translation>
    </message>
    <message>
        <location filename="../../src/cli/commandlineparser.cpp" line="330"/>
        <source>Usage</source>
        <translation>Penggunaan</translation>
    </message>
    <message>
        <location filename="../../src/cli/commandlineparser.cpp" line="330"/>
        <source>options</source>
        <translation>opsi</translation>
    </message>
    <message>
        <location filename="../../src/cli/commandlineparser.cpp" line="337"/>
        <source>Per default runs Flameshot in the background and adds a tray icon for configuration.</source>
        <translation>Per default menjalankan Flameshot di latar belakang dan menambahkan ikon baki untuk konfigurasi.</translation>
    </message>
    <message>
        <location filename="../../src/core/controller.cpp" line="569"/>
        <source>Hello, I&apos;m here! Click icon in the tray to take a screenshot or click with a right button to see more options.</source>
        <translation>Halo, Saya disini! Klik ikon di baki untuk mengambil screenshot atau klik dengan tombol kanan untuk melihat opsi lebih banyak.</translation>
    </message>
    <message>
        <location filename="../../src/core/controller.cpp" line="656"/>
        <source>Full screen screenshot pinned to screen</source>
        <translation>Screenshot layar penuh disematkan ke layar</translation>
    </message>
    <message>
        <source>Toggle side panel</source>
        <translation type="vanished">Toggle side panel</translation>
    </message>
    <message>
        <source>Resize selection left 1px</source>
        <translation type="vanished">Ubah ukuran seleksi sebesar 1px ke kiri</translation>
    </message>
    <message>
        <source>Resize selection right 1px</source>
        <translation type="vanished">Ubah ukuran seleksi sebesar 1px ke kanan</translation>
    </message>
    <message>
        <source>Resize selection up 1px</source>
        <translation type="vanished">Ubah ukuran seleksi sebesar 1px ke atas</translation>
    </message>
    <message>
        <source>Resize selection down 1px</source>
        <translation type="vanished">Ubah ukuran seleksi sebesar 1px ke bawah</translation>
    </message>
    <message>
        <source>Select entire screen</source>
        <translation type="vanished">Seleksi seluruh layar</translation>
    </message>
    <message>
        <source>Move selection left 1px</source>
        <translation type="vanished">Geser seleksi sebesar 1px ke kiri</translation>
    </message>
    <message>
        <source>Move selection right 1px</source>
        <translation type="vanished">Geser seleksi sebesar 1px ke kanan</translation>
    </message>
    <message>
        <source>Move selection up 1px</source>
        <translation type="vanished">Geser seleksi sebesar 1px ke atas</translation>
    </message>
    <message>
        <source>Move selection down 1px</source>
        <translation type="vanished">Geser seleksi sebesar 1px ke bawah</translation>
    </message>
    <message>
        <source>Commit text in text area</source>
        <translation type="vanished">Commit text in text area</translation>
    </message>
    <message>
        <source>Delete current tool</source>
        <translation type="vanished">Delete current tool</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="187"/>
        <source>Quit capture</source>
        <translation>Keluar capture</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="195"/>
        <source>Screenshot history</source>
        <translation>Riwayat screenshot</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="198"/>
        <source>Capture screen</source>
        <translation>Ambil capture</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="205"/>
        <source>Show color picker</source>
        <translation>Tampilkan pemilih warna</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="206"/>
        <source>Change the tool&apos;s size</source>
        <translation>Ubah ukuran alat</translation>
    </message>
    <message>
        <source>Change the tool&apos;s thickness</source>
        <translation type="vanished">Change the tool&apos;s thickness</translation>
    </message>
</context>
<context>
    <name>RectangleTool</name>
    <message>
        <location filename="../../src/tools/rectangle/rectangletool.cpp" line="22"/>
        <source>Rectangle</source>
        <translation>Persegi panjang</translation>
    </message>
    <message>
        <location filename="../../src/tools/rectangle/rectangletool.cpp" line="32"/>
        <source>Set the Rectangle as the paint tool</source>
        <translation>Atur persegi panjang sebagai paint tool</translation>
    </message>
</context>
<context>
    <name>RedoTool</name>
    <message>
        <location filename="../../src/tools/redo/redotool.cpp" line="23"/>
        <source>Redo</source>
        <translation>Ulangi</translation>
    </message>
    <message>
        <location filename="../../src/tools/redo/redotool.cpp" line="33"/>
        <source>Redo the next modification</source>
        <translation>Ulangi modifikasi berikutnya</translation>
    </message>
</context>
<context>
    <name>SaveTool</name>
    <message>
        <location filename="../../src/tools/save/savetool.cpp" line="24"/>
        <source>Save</source>
        <translation>Simpan</translation>
    </message>
    <message>
        <location filename="../../src/tools/save/savetool.cpp" line="34"/>
        <source>Save screenshot to a file</source>
        <translation>Simpan screenshot sebagai file</translation>
    </message>
    <message>
        <source>Save the capture</source>
        <translation type="vanished">Save the capture</translation>
    </message>
</context>
<context>
    <name>ScreenGrabber</name>
    <message>
        <location filename="../../src/utils/screengrabber.cpp" line="131"/>
        <source>Unable to capture screen</source>
        <translation>Tidak dapat capture layar</translation>
    </message>
</context>
<context>
    <name>SelectionTool</name>
    <message>
        <location filename="../../src/tools/selection/selectiontool.cpp" line="25"/>
        <source>Rectangular Selection</source>
        <translation>Seleksi persegi panjang</translation>
    </message>
    <message>
        <location filename="../../src/tools/selection/selectiontool.cpp" line="35"/>
        <source>Set Selection as the paint tool</source>
        <translation>Atur Seleksian sebagai paint tool</translation>
    </message>
</context>
<context>
    <name>SetShortcutDialog</name>
    <message>
        <location filename="../../src/config/setshortcutwidget.cpp" line="17"/>
        <source>Set Shortcut</source>
        <translation>Atur Shortcut</translation>
    </message>
    <message>
        <location filename="../../src/config/setshortcutwidget.cpp" line="23"/>
        <source>Enter new shortcut to change </source>
        <translation>Masukkan shortcut baru untuk mengubah </translation>
    </message>
    <message>
        <location filename="../../src/config/setshortcutwidget.cpp" line="37"/>
        <source>Press Esc to cancel or ⌘+Backspace to disable the keyboard shortcut.</source>
        <translation>Tekan Esc untuk membatalkan atau ⌘+Backspace untuk mematikan shortcut keyboard.</translation>
    </message>
    <message>
        <location filename="../../src/config/setshortcutwidget.cpp" line="41"/>
        <source>Press Esc to cancel or Backspace to disable the keyboard shortcut.</source>
        <translation>Tekan Esc untuk membatalkan atau Backspace untuk mematikan shorcut keyboard.</translation>
    </message>
    <message>
        <location filename="../../src/config/setshortcutwidget.cpp" line="46"/>
        <source>Flameshot must be restarted for changes to take effect.</source>
        <translation>Flameshot harus di mulai ulang agar perubahan diterapkan.</translation>
    </message>
</context>
<context>
    <name>ShortcutsWidget</name>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="30"/>
        <source>Hot Keys</source>
        <translation>Tombol Panas</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="53"/>
        <source>Available shortcuts in the screen capture mode.</source>
        <translation>Shortcut yang tersedia di mode capture layar.</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="64"/>
        <source>Description</source>
        <translation>Deskripsi</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="64"/>
        <source>Key</source>
        <translation>Kunci</translation>
    </message>
</context>
<context>
    <name>SidePanelWidget</name>
    <message>
        <source>Active thickness:</source>
        <translation type="vanished">Active thickness:</translation>
    </message>
    <message>
        <source>Active color:</source>
        <translation type="vanished">Active color:</translation>
    </message>
    <message>
        <source>Press ESC to cancel</source>
        <translation type="vanished">Press ESC to cancel</translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/sidepanelwidget.cpp" line="36"/>
        <source>Active tool size: </source>
        <translation>Ukuran alat aktif: </translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/sidepanelwidget.cpp" line="48"/>
        <source>Active Color: </source>
        <translation>Warna aktif: </translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/sidepanelwidget.cpp" line="69"/>
        <source>Grab Color</source>
        <translation>Ambil Warna</translation>
    </message>
</context>
<context>
    <name>SizeDecreaseTool</name>
    <message>
        <location filename="../../src/tools/sizedecrease/sizedecreasetool.cpp" line="37"/>
        <source>Decrease Tool Size</source>
        <translation>Kecilkan Ukuran Alat</translation>
    </message>
    <message>
        <location filename="../../src/tools/sizedecrease/sizedecreasetool.cpp" line="47"/>
        <source>Decrease the size of the other tools</source>
        <translation>Kecilkan ukuran dari alat yang lainnya</translation>
    </message>
</context>
<context>
    <name>SizeIncreaseTool</name>
    <message>
        <location filename="../../src/tools/sizeincrease/sizeincreasetool.cpp" line="37"/>
        <source>Increase Tool Size</source>
        <translation>Besarkan Alat</translation>
    </message>
    <message>
        <location filename="../../src/tools/sizeincrease/sizeincreasetool.cpp" line="47"/>
        <source>Increase the size of the other tools</source>
        <translation>Besarkan ukuran dari alat yang lain</translation>
    </message>
</context>
<context>
    <name>SizeIndicatorTool</name>
    <message>
        <location filename="../../src/tools/sizeindicator/sizeindicatortool.cpp" line="23"/>
        <source>Selection Size Indicator</source>
        <translation>Indikator Ukuran Pilihan</translation>
    </message>
    <message>
        <location filename="../../src/tools/sizeindicator/sizeindicatortool.cpp" line="33"/>
        <source>Show X and Y dimensions of the selection</source>
        <translation>Tampilkan dimensi X dan Y pada seleksi</translation>
    </message>
    <message>
        <source>Show the dimensions of the selection (X Y)</source>
        <translation type="vanished">Show the dimensions of the selection (X Y)</translation>
    </message>
</context>
<context>
    <name>StrftimeChooserWidget</name>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="37"/>
        <source>Century (00-99)</source>
        <translation>Abad (00-99)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="38"/>
        <source>Year (00-99)</source>
        <translation>Tahun (00-99)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="39"/>
        <source>Year (2000)</source>
        <translation>Tahun (2000)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="42"/>
        <source>Month Name (jan)</source>
        <translation>Nama Bulan (jan)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="43"/>
        <source>Month Name (january)</source>
        <translation>Nama Bulan (january)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="45"/>
        <source>Month (01-12)</source>
        <translation>Bulan (01-12)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="46"/>
        <source>Week Day (1-7)</source>
        <translation>Hari Mingguan (1-7)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="47"/>
        <source>Week (01-53)</source>
        <translation>Minggu (01-53)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="50"/>
        <source>Day Name (mon)</source>
        <translation>Nama Hari (mon)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="51"/>
        <source>Day Name (monday)</source>
        <translation>Nama Hari (monday)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="53"/>
        <source>Day (01-31)</source>
        <translation>Hari (01-31)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="54"/>
        <source>Day of Month (1-31)</source>
        <translation>Tanggal (1-31)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="55"/>
        <source>Day (001-366)</source>
        <translation>Hari (001-366)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="61"/>
        <source>Hour (00-23)</source>
        <translation>Jam (00-23)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="62"/>
        <source>Hour (01-12)</source>
        <translation>Jam (01-12)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="63"/>
        <source>Minute (00-59)</source>
        <translation>Menit (00-59)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="64"/>
        <source>Second (00-59)</source>
        <translation>Detik (00-59)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="67"/>
        <source>Full Date (%m/%d/%y)</source>
        <translation>Tanggal Penuh (%m/%d/%y)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="69"/>
        <source>Full Date (%Y-%m-%d)</source>
        <translation>Tanggal Penuh (%Y-%m-%d)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="58"/>
        <source>Time (%H-%M-%S)</source>
        <translation>Waktu (%H-%M-%S)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="59"/>
        <source>Time (%H-%M)</source>
        <translation>Waktu (%H-%M)</translation>
    </message>
</context>
<context>
    <name>SystemNotification</name>
    <message>
        <location filename="../../src/utils/systemnotification.cpp" line="30"/>
        <source>Flameshot Info</source>
        <translation>Info Flameshot</translation>
    </message>
</context>
<context>
    <name>TextConfig</name>
    <message>
        <location filename="../../src/tools/text/textconfig.cpp" line="47"/>
        <source>StrikeOut</source>
        <translation>Coretan</translation>
    </message>
    <message>
        <location filename="../../src/tools/text/textconfig.cpp" line="56"/>
        <source>Underline</source>
        <translation>Garis bawah</translation>
    </message>
    <message>
        <location filename="../../src/tools/text/textconfig.cpp" line="65"/>
        <source>Bold</source>
        <translation>Tebal</translation>
    </message>
    <message>
        <location filename="../../src/tools/text/textconfig.cpp" line="74"/>
        <source>Italic</source>
        <translation>Miring</translation>
    </message>
    <message>
        <location filename="../../src/tools/text/textconfig.cpp" line="84"/>
        <source>Left Align</source>
        <translation>Rata Kiri</translation>
    </message>
    <message>
        <location filename="../../src/tools/text/textconfig.cpp" line="93"/>
        <source>Center Align</source>
        <translation>Rata Tengah</translation>
    </message>
    <message>
        <location filename="../../src/tools/text/textconfig.cpp" line="102"/>
        <source>Right Align</source>
        <translation>Rata Kanan</translation>
    </message>
</context>
<context>
    <name>TextTool</name>
    <message>
        <location filename="../../src/tools/text/texttool.cpp" line="73"/>
        <source>Text</source>
        <translation>Teks</translation>
    </message>
    <message>
        <location filename="../../src/tools/text/texttool.cpp" line="97"/>
        <source>Add text to your capture</source>
        <translation>Tambahkan teks ke cuplikan layar Anda</translation>
    </message>
</context>
<context>
    <name>UIcolorEditor</name>
    <message>
        <source>UI Color Editor</source>
        <translation type="vanished">Pengedit Warna UI</translation>
    </message>
    <message>
        <location filename="../../src/config/uicoloreditor.cpp" line="88"/>
        <source>Change the color moving the selectors and see the changes in the preview buttons.</source>
        <translation>Ubah warna dengan memindahkan pemilih dan lihat perubahan di tombol pratinjau.</translation>
    </message>
    <message>
        <location filename="../../src/config/uicoloreditor.cpp" line="99"/>
        <source>Select a Button to modify it</source>
        <translation>Pilih Tombol untuk mengubahnya</translation>
    </message>
    <message>
        <location filename="../../src/config/uicoloreditor.cpp" line="109"/>
        <source>Main Color</source>
        <translation>Warna Utama</translation>
    </message>
    <message>
        <location filename="../../src/config/uicoloreditor.cpp" line="113"/>
        <source>Click on this button to set the edition mode of the main color.</source>
        <translation>Klik pada tombol ini untuk mengatur warna utama dari mode edisi.</translation>
    </message>
    <message>
        <location filename="../../src/config/uicoloreditor.cpp" line="124"/>
        <source>Contrast Color</source>
        <translation>Warna Kontras</translation>
    </message>
    <message>
        <location filename="../../src/config/uicoloreditor.cpp" line="129"/>
        <source>Click on this button to set the edition mode of the contrast color.</source>
        <translation>Klik pada tombol ini untuk mengatur warna kontras pada mode edisi.</translation>
    </message>
</context>
<context>
    <name>UndoTool</name>
    <message>
        <location filename="../../src/tools/undo/undotool.cpp" line="23"/>
        <source>Undo</source>
        <translation>Batalkan</translation>
    </message>
    <message>
        <location filename="../../src/tools/undo/undotool.cpp" line="33"/>
        <source>Undo the last modification</source>
        <translation>Batalkan perubahan terakhir</translation>
    </message>
</context>
<context>
    <name>UpdateNotificationWidget</name>
    <message>
        <location filename="../../src/widgets/updatenotificationwidget.cpp" line="69"/>
        <source>New Flameshot version %1 is available</source>
        <translation>Versi Flameshot terbaru %1 tersedia</translation>
    </message>
    <message>
        <location filename="../../src/widgets/updatenotificationwidget.cpp" line="122"/>
        <source>Ignore</source>
        <translation>Abaikan</translation>
    </message>
    <message>
        <location filename="../../src/widgets/updatenotificationwidget.cpp" line="130"/>
        <source>Later</source>
        <translation>Nanti</translation>
    </message>
    <message>
        <location filename="../../src/widgets/updatenotificationwidget.cpp" line="138"/>
        <source>Update</source>
        <translation>Perbarui</translation>
    </message>
</context>
<context>
    <name>UploadHistory</name>
    <message>
        <location filename="../../src/widgets/uploadhistory.ui" line="14"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_uploadhistory.h" line="67"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_uploadhistory.h" line="67"/>
        <source>Upload History</source>
        <translation>Unggah Riwayat</translation>
    </message>
    <message>
        <location filename="../../src/widgets/uploadhistory.cpp" line="62"/>
        <source>Screenshots history is empty</source>
        <translation>Riwayat cuplikan layar kosong</translation>
    </message>
</context>
<context>
    <name>UploadLineItem</name>
    <message>
        <location filename="../../src/widgets/uploadlineitem.ui" line="20"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_uploadlineitem.h" line="113"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_uploadlineitem.h" line="113"/>
        <source>Form</source>
        <translation>Formulir</translation>
    </message>
    <message>
        <location filename="../../src/widgets/uploadlineitem.ui" line="49"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_uploadlineitem.h" line="114"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_uploadlineitem.h" line="114"/>
        <source>TextLabel</source>
        <translation>LabelTeks</translation>
    </message>
    <message>
        <location filename="../../src/widgets/uploadlineitem.ui" line="82"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_uploadlineitem.h" line="115"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_uploadlineitem.h" line="115"/>
        <source>Copy URL</source>
        <translation>Salin URL</translation>
    </message>
    <message>
        <location filename="../../src/widgets/uploadlineitem.ui" line="95"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_uploadlineitem.h" line="116"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_uploadlineitem.h" line="116"/>
        <source>Open In Browser</source>
        <translation>Buka Dalam Peramban</translation>
    </message>
    <message>
        <location filename="../../src/widgets/uploadlineitem.cpp" line="50"/>
        <source>Confirm to delete</source>
        <translation>Konfirmasi hapus</translation>
    </message>
    <message>
        <location filename="../../src/widgets/uploadlineitem.cpp" line="51"/>
        <source>Are you sure you want to delete a screenshot from the latest uploads and server?</source>
        <translation>Apakah Anda yakin ingin menghapus screenshot dari unggahan terbaru dan server?</translation>
    </message>
</context>
<context>
    <name>UtilityPanel</name>
    <message>
        <location filename="../../src/widgets/panel/utilitypanel.cpp" line="190"/>
        <source>Close</source>
        <translation>Tutup</translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/utilitypanel.cpp" line="200"/>
        <source>&lt;Empty&gt;</source>
        <translation>&lt;Kosong&gt;</translation>
    </message>
</context>
<context>
    <name>VisualsEditor</name>
    <message>
        <location filename="../../src/config/visualseditor.cpp" line="41"/>
        <source>Opacity of area outside selection:</source>
        <translation>Opacity area di luar seleksi:</translation>
    </message>
    <message>
        <location filename="../../src/config/visualseditor.cpp" line="68"/>
        <source>UI Color Editor</source>
        <translation>Pengedit Warna UI</translation>
    </message>
    <message>
        <location filename="../../src/config/visualseditor.cpp" line="74"/>
        <source>Colorpicker Editor</source>
        <translation>Penyunting pemilih warna</translation>
    </message>
    <message>
        <location filename="../../src/config/visualseditor.cpp" line="79"/>
        <source>Button Selection</source>
        <translation>Seleksi Tombol</translation>
    </message>
    <message>
        <location filename="../../src/config/visualseditor.cpp" line="85"/>
        <source>Select All</source>
        <translation>Pilih Semua</translation>
    </message>
</context>
<context>
    <name>color_widgets::ColorDialog</name>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_dialog.cpp" line="79"/>
        <source>Pick</source>
        <translation>Ambil</translation>
    </message>
</context>
<context>
    <name>color_widgets::ColorPalette</name>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette.cpp" line="428"/>
        <source>Unnamed</source>
        <translation>Tidak bernama</translation>
    </message>
</context>
<context>
    <name>color_widgets::ColorPaletteModel</name>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_model.cpp" line="70"/>
        <source>Unnamed</source>
        <translation>Tidak bernama</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_model.cpp" line="144"/>
        <source>%1 (%2 colors)</source>
        <translation>%1 (warna %2)</translation>
    </message>
</context>
<context>
    <name>color_widgets::ColorPaletteWidget</name>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.ui" line="59"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="209"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="209"/>
        <source>Open a new palette from file</source>
        <translation>Buka palet baru dari file</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.ui" line="71"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="212"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="212"/>
        <source>Create a new palette</source>
        <translation>Buat palet baru</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.ui" line="83"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="215"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="215"/>
        <source>Duplicate the current palette</source>
        <translation>Duplikat palet saat ini</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.ui" line="121"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="218"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="218"/>
        <source>Delete the current palette</source>
        <translation>Hapus palet saat ini</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.ui" line="133"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="221"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="221"/>
        <source>Revert changes to the current palette</source>
        <translation>Kembalikan perubahan palet saat ini</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.ui" line="145"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="224"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="224"/>
        <source>Save changes to the current palette</source>
        <translation>Simpan perubahan palet saat ini</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.ui" line="170"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="227"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="227"/>
        <source>Add a color to the palette</source>
        <translation>Tambahkan warna pada palet</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.ui" line="182"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="230"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="230"/>
        <source>Remove the selected color from the palette</source>
        <translation>Hapus warna yang terpilih dari palet</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.cpp" line="186"/>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.cpp" line="201"/>
        <source>New Palette</source>
        <translation>Palet Baru</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.cpp" line="187"/>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.cpp" line="202"/>
        <source>Name</source>
        <translation>Nama</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.cpp" line="228"/>
        <source>GIMP Palettes (*.gpl)</source>
        <translation>Palet GIMP (*.gpl)</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.cpp" line="229"/>
        <source>Palette Image (%1)</source>
        <translation>Gambar Palet (%1)</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.cpp" line="230"/>
        <source>All Files (*)</source>
        <translation>Semua File (*)</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.cpp" line="231"/>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.cpp" line="244"/>
        <source>Open Palette</source>
        <translation>Buka Palet</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.cpp" line="245"/>
        <source>Failed to load the palette file
%1</source>
        <translation>Gagal memuat file palet
%1</translation>
    </message>
</context>
<context>
    <name>color_widgets::GradientEditor</name>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/gradient_editor.cpp" line="335"/>
        <source>Add Color</source>
        <translation>Tambahkan Warna</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/gradient_editor.cpp" line="344"/>
        <source>Remove Color</source>
        <translation>Hapus Warna</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/gradient_editor.cpp" line="352"/>
        <source>Edit Color...</source>
        <translation>Ubah Warna...</translation>
    </message>
</context>
<context>
    <name>color_widgets::GradientListModel</name>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/gradient_list_model.cpp" line="231"/>
        <source>%1 (%2 colors)</source>
        <translation>%1 (warna %2)</translation>
    </message>
</context>
<context>
    <name>color_widgets::Swatch</name>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/swatch.cpp" line="824"/>
        <source>Clear Color</source>
        <translation>Hapus Warna</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/swatch.cpp" line="833"/>
        <source>%1 (%2)</source>
        <translation>%1 (%2)</translation>
    </message>
</context>
</TS>
