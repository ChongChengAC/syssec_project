<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="cs_CZ">
<context>
    <name>AbstractWidgetList</name>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/abstract_widget_list.cpp" line="67"/>
        <source>Add New</source>
        <translation>Přidat nový</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/abstract_widget_list.cpp" line="118"/>
        <source>Move Up</source>
        <translation>Posunout nahoru</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/abstract_widget_list.cpp" line="119"/>
        <source>Move Down</source>
        <translation>Posunout dolů</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/abstract_widget_list.cpp" line="120"/>
        <source>Remove</source>
        <translation>Odstranit</translation>
    </message>
</context>
<context>
    <name>AcceptTool</name>
    <message>
        <location filename="../../src/tools/accept/accepttool.cpp" line="31"/>
        <source>Accept</source>
        <translation>Přijmout</translation>
    </message>
    <message>
        <location filename="../../src/tools/accept/accepttool.cpp" line="41"/>
        <source>Accept the capture</source>
        <translation>Přijmout zachycenou obrazovku</translation>
    </message>
</context>
<context>
    <name>AppLauncher</name>
    <message>
        <location filename="../../src/tools/launcher/applaunchertool.cpp" line="23"/>
        <source>App Launcher</source>
        <translation>Spouštěč programů</translation>
    </message>
    <message>
        <location filename="../../src/tools/launcher/applaunchertool.cpp" line="33"/>
        <source>Choose an app to open the capture</source>
        <translation>Vyberte program pro otevření zachycené obrazovky</translation>
    </message>
</context>
<context>
    <name>AppLauncherWidget</name>
    <message>
        <location filename="../../src/tools/launcher/applauncherwidget.cpp" line="43"/>
        <source>Open With</source>
        <translation>Otevřít s</translation>
    </message>
    <message>
        <location filename="../../src/tools/launcher/applauncherwidget.cpp" line="58"/>
        <source>Launch in terminal</source>
        <translation>Spustit v terminálu</translation>
    </message>
    <message>
        <location filename="../../src/tools/launcher/applauncherwidget.cpp" line="59"/>
        <source>Keep open after selection</source>
        <translation>Ponechat otevřené po výběru</translation>
    </message>
    <message>
        <location filename="../../src/tools/launcher/applauncherwidget.cpp" line="95"/>
        <location filename="../../src/tools/launcher/applauncherwidget.cpp" line="110"/>
        <source>Error</source>
        <translation>Chyba</translation>
    </message>
    <message>
        <location filename="../../src/tools/launcher/applauncherwidget.cpp" line="95"/>
        <source>Unable to write in</source>
        <translation>Nelze zapsat</translation>
    </message>
    <message>
        <location filename="../../src/tools/launcher/applauncherwidget.cpp" line="110"/>
        <source>Unable to launch in terminal.</source>
        <translation>Nelze spustit v terminálu.</translation>
    </message>
</context>
<context>
    <name>ArrowTool</name>
    <message>
        <location filename="../../src/tools/arrow/arrowtool.cpp" line="72"/>
        <source>Arrow</source>
        <translation>Šipka</translation>
    </message>
    <message>
        <location filename="../../src/tools/arrow/arrowtool.cpp" line="82"/>
        <source>Set the Arrow as the paint tool</source>
        <translation>Nastavit šipku jako malovací nástroj</translation>
    </message>
</context>
<context>
    <name>BlurTool</name>
    <message>
        <source>Blur</source>
        <translation type="vanished">Rozmazání</translation>
    </message>
    <message>
        <source>Set Blur as the paint tool</source>
        <translation type="vanished">Nastavit rozmazání jako malovací nástroj</translation>
    </message>
</context>
<context>
    <name>CaptureLauncher</name>
    <message>
        <source>&lt;b&gt;Capture Mode&lt;/b&gt;</source>
        <translation type="vanished">&lt;b&gt;Režim zachytávání&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.cpp" line="31"/>
        <source>Rectangular Region</source>
        <translation>Pravouhlá oblast</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.cpp" line="37"/>
        <source>Full Screen (Current Display)</source>
        <translation>Celá obrazovka (nynější obrazovka)</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.cpp" line="40"/>
        <source>Full Screen (All Monitors)</source>
        <translation>Celá obrazovka (všechny monitory)</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.cpp" line="43"/>
        <source>No Delay</source>
        <translation>Bez zpoždění</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.cpp" line="51"/>
        <source> second</source>
        <translation> sekunda</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.ui" line="75"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_capturelauncher.h" line="125"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_capturelauncher.h" line="125"/>
        <location filename="../../src/widgets/capturelauncher.cpp" line="51"/>
        <source> seconds</source>
        <translation> sekund</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.ui" line="96"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_capturelauncher.h" line="126"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_capturelauncher.h" line="126"/>
        <source>Take new screenshot</source>
        <translation>Zachytit nový snímek</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.ui" line="54"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_capturelauncher.h" line="122"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_capturelauncher.h" line="122"/>
        <source>Area:</source>
        <translation>Oblast:</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.ui" line="14"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_capturelauncher.h" line="119"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_capturelauncher.h" line="119"/>
        <source>Capture Launcher</source>
        <translation>Spouštěč zachytávání obrazovky</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.ui" line="22"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_capturelauncher.h" line="120"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_capturelauncher.h" line="120"/>
        <source>TextLabel</source>
        <translation>Textový štítek</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.ui" line="39"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_capturelauncher.h" line="121"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_capturelauncher.h" line="121"/>
        <source>Capture Mode</source>
        <translation>Režim zachytávání obrazovky</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.ui" line="61"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_capturelauncher.h" line="123"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_capturelauncher.h" line="123"/>
        <source>Delay:</source>
        <translation>Zpoždění:</translation>
    </message>
</context>
<context>
    <name>CaptureWidget</name>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="105"/>
        <source>Unable to capture screen</source>
        <translation>Nelze zachytit obrazovku</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="378"/>
        <source>Mouse</source>
        <translation>Myš</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="378"/>
        <source>Select screenshot area</source>
        <translation>Vybrat oblast snímku obrazovky</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="393"/>
        <source>Mouse Wheel</source>
        <translation>Kolečko myši</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="393"/>
        <source>Change tool size</source>
        <translation>Změnit velikost nástroje</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="394"/>
        <source>Right Click</source>
        <translation>Klepnutí pravým tlačítkem myši</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="394"/>
        <source>Show color picker</source>
        <translation>Ukázat volič barev</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="396"/>
        <source>Open side panel</source>
        <translation>Otevřít postranní panel</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="397"/>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="397"/>
        <source>Exit</source>
        <translation>Ukončit</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="505"/>
        <source>Flameshot has lost focus. Keyboard shortcuts won&apos;t work until you click somewhere.</source>
        <translation>Flameshot ztratil zaměření. Klávesové zkratky nebudou pracovat, dokud někam neklepnete.</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="511"/>
        <source>Configuration error resolved. Launch `flameshot gui` again to apply it.</source>
        <translation>Chyba v nastavení vyřešena. Spusťte znovu `flameshot gui` pro jeho použití.</translation>
    </message>
    <message>
        <source>Select an area with the mouse, or press Esc to exit.
Press Enter to capture the screen.
Press Right Click to show the color picker.
Use the Mouse Wheel to change the thickness of your tool.
Press Space to open the side panel.</source>
        <translation type="vanished">Vyberte oblast myší nebo stiskněte Esc pro opuštění.
Stiskněte Enter pro zachycení obrazovky
Stiskněte pravé tlačítko myši pro zobrazení voliče barev.
Použijte kolečko myši pro změnu tloušťky nástroje.
Stiskněte mezerník pro otevření postranního panelu.</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="949"/>
        <source>Tool Settings</source>
        <translation>Nastavení nástrojů</translation>
    </message>
</context>
<context>
    <name>CircleCountTool</name>
    <message>
        <location filename="../../src/tools/circlecount/circlecounttool.cpp" line="57"/>
        <source>Circle Counter</source>
        <translation>Kruhové počítadlo</translation>
    </message>
    <message>
        <location filename="../../src/tools/circlecount/circlecounttool.cpp" line="75"/>
        <source>Add an autoincrementing counter bubble</source>
        <translation>Přidat bublinu s počítadlem (s číslem automaticky vždy zvýšeným o jednotku)</translation>
    </message>
</context>
<context>
    <name>CircleTool</name>
    <message>
        <location filename="../../src/tools/circle/circletool.cpp" line="20"/>
        <source>Circle</source>
        <translation>Kruh</translation>
    </message>
    <message>
        <location filename="../../src/tools/circle/circletool.cpp" line="30"/>
        <source>Set the Circle as the paint tool</source>
        <translation>Nastavit kruh jako malovací nástroj</translation>
    </message>
</context>
<context>
    <name>ColorDialog</name>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_dialog.ui" line="14"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="318"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="318"/>
        <source>Select Color</source>
        <translation>Vybrat barvu</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_dialog.ui" line="55"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="319"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="319"/>
        <source>Saturation</source>
        <translation>Sytost</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_dialog.ui" line="62"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="320"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="320"/>
        <source>Hue</source>
        <translation>Odstín</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_dialog.ui" line="79"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="321"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="321"/>
        <source>Hex</source>
        <translation>Hex</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_dialog.ui" line="86"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="322"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="322"/>
        <source>Blue</source>
        <translation>Modrá</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_dialog.ui" line="123"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="323"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="323"/>
        <source>Value</source>
        <translation>Hodnota</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_dialog.ui" line="130"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="324"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="324"/>
        <source>Green</source>
        <translation>Zelená</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_dialog.ui" line="137"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="325"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="325"/>
        <source>Alpha</source>
        <translation>Alfa</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_dialog.ui" line="144"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="326"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_dialog.h" line="326"/>
        <source>Red</source>
        <translation>Červená</translation>
    </message>
</context>
<context>
    <name>ColorGrabWidget</name>
    <message>
        <location filename="../../src/widgets/panel/colorgrabwidget.cpp" line="58"/>
        <source>Accept color</source>
        <translation>Přijmout barvu</translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/colorgrabwidget.cpp" line="59"/>
        <source>Precisely select color</source>
        <translation>Přesně vybrat barvu</translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/colorgrabwidget.cpp" line="60"/>
        <source>Toggle magnifier</source>
        <translation>Přepnout lupu</translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/colorgrabwidget.cpp" line="61"/>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
</context>
<context>
    <name>ColorPickerEditor</name>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="42"/>
        <source>Select Preset:</source>
        <translation>Vybrat přednastavení:</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="53"/>
        <source>Select preset using the spinbox</source>
        <translation>Vyberte přednastavení pomocí číselníku</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="56"/>
        <source>Delete</source>
        <translation>Smazat</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="58"/>
        <source>Press button to delete the selected preset</source>
        <translation>Stisknutím tlačítka odstraníte vybrané přednastavení</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="72"/>
        <source>Add Preset:</source>
        <translation>Přidat přednastavení:</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="78"/>
        <source>Enter color manually or select it using the color-wheel</source>
        <translation>Zadejte barvu ručně nebo ji vyberte pomocí barevného kolečka</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="88"/>
        <source>Add</source>
        <translation>Přidat</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="89"/>
        <source>Press button to add preset</source>
        <translation>Stiskněte tlačítko pro přidání přednastavení</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="117"/>
        <location filename="../../src/config/colorpickereditor.cpp" line="137"/>
        <source>Error</source>
        <translation>Chyba</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="118"/>
        <source>Unable to add preset. Maximum limit reached.</source>
        <translation>Přednastavení nelze přidat. Bylo dosaženo největší meze.</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="138"/>
        <source>Unable to remove preset. Minimum limit reached.</source>
        <translation>Přednastavení nelze odstranit. Bylo dosaženo nejmenší meze.</translation>
    </message>
</context>
<context>
    <name>ConfigErrorDetails</name>
    <message>
        <location filename="../../src/config/configerrordetails.cpp" line="20"/>
        <source>Configuration errors</source>
        <translation>Chyby v nastavení</translation>
    </message>
</context>
<context>
    <name>ConfigHandler</name>
    <message>
        <location filename="../../src/utils/confighandler.cpp" line="549"/>
        <source>Unrecognized setting: &apos;%1&apos;
</source>
        <translation>Nerozpoznané nastavení: &apos;%1&apos;
</translation>
    </message>
    <message>
        <location filename="../../src/utils/confighandler.cpp" line="557"/>
        <source>Unrecognized shortcut name: &apos;%1&apos;.
</source>
        <translation>Nerozpoznaný název klávesové zkratky: &apos;%1&apos;.
</translation>
    </message>
    <message>
        <location filename="../../src/utils/confighandler.cpp" line="600"/>
        <source>Shortcut conflict: &apos;%1&apos; and &apos;%2&apos; have the same shortcut: %3
</source>
        <translation>Střet klávesových zkratek: &apos;%1&apos; a &apos;%2&apos; mají stejnou klávesovou zkratku: %3
</translation>
    </message>
    <message>
        <location filename="../../src/utils/confighandler.cpp" line="640"/>
        <source>Bad value in &apos;%1&apos;. Expected: %2
</source>
        <translation>Špatná hodnota v &apos;%1&apos;. Očekáváno: %2
</translation>
    </message>
    <message>
        <location filename="../../src/utils/confighandler.cpp" line="690"/>
        <source>You have successfully resolved the configuration error.</source>
        <translation>Úspěšně jste vyřešili chybu v nastavení.</translation>
    </message>
    <message>
        <location filename="../../src/utils/confighandler.cpp" line="713"/>
        <source>The configuration contains an error. Open configuration to resolve.</source>
        <translation>Nastavení obsahuje chybu. Otevřete nastavení pro její vyřešení.</translation>
    </message>
    <message>
        <location filename="../../src/utils/confighandler.cpp" line="767"/>
        <source>Bad config key &apos;%1&apos; in ConfigHandler. Please report this as a bug.</source>
        <translation>Chybný klíč nastavení &apos;%1&apos; v ConfigHandler. Nahlaste to prosím jako chybu.</translation>
    </message>
</context>
<context>
    <name>ConfigResolver</name>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="14"/>
        <source>Resolve configuration errors</source>
        <translation>Vyřešit chyby v nastavení</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="50"/>
        <source>&lt;b&gt;You must resolve all errors before continuing:&lt;/b&gt;</source>
        <translation>&lt;b&gt;Před pokračováním musíte vyřešit všechny chyby:&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="61"/>
        <source>Reset</source>
        <translation>Obnovit výchozí</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="63"/>
        <source>Reset to the default value.</source>
        <translation>Obnovit výchozí hodnotu.</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="77"/>
        <source>Remove</source>
        <translation>Odstranit</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="79"/>
        <source>Remove this setting.</source>
        <translation>Odstranit toto nastavení.</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="90"/>
        <source>Some keyboard shortcuts have conflicts.
This will NOT prevent flameshot from starting.
Please solve them manually in the configuration file.</source>
        <translation>Některé klávesové zkratky jsou ve střetu.
To NEZABRÁNÍ spuštění Flameshotu.
Vyřešte je, prosím, ručně v souboru s nastavením.</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="112"/>
        <source>Resolve all</source>
        <translation>Vyřešit vše</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="113"/>
        <source>Resolve all listed errors.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="125"/>
        <source>Details</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>ConfigWindow</name>
    <message>
        <location filename="../../src/config/configwindow.cpp" line="42"/>
        <source>Configuration</source>
        <translation>Nastavení</translation>
    </message>
    <message>
        <location filename="../../src/config/configwindow.cpp" line="61"/>
        <source>Interface</source>
        <translation>Rozhraní</translation>
    </message>
    <message>
        <location filename="../../src/config/configwindow.cpp" line="71"/>
        <source>Filename Editor</source>
        <translation>Editor názvů souborů</translation>
    </message>
    <message>
        <location filename="../../src/config/configwindow.cpp" line="80"/>
        <source>General</source>
        <translation>Obecné</translation>
    </message>
    <message>
        <location filename="../../src/config/configwindow.cpp" line="89"/>
        <source>Shortcuts</source>
        <translation>Klávesové zkratky</translation>
    </message>
    <message>
        <location filename="../../src/config/configwindow.cpp" line="122"/>
        <source>Resolve</source>
        <translation>Vyřešit</translation>
    </message>
    <message>
        <location filename="../../src/config/configwindow.cpp" line="126"/>
        <source>&lt;b&gt;Configuration file has errors. Resolve them before continuing.&lt;/b&gt;</source>
        <translation>&lt;b&gt;Soubor s nastavení obsahuje chyby. Před pokračováním je vyřešte.&lt;/b&gt;</translation>
    </message>
</context>
<context>
    <name>Controller</name>
    <message>
        <location filename="../../src/core/controller.cpp" line="217"/>
        <source>New version %1 is available</source>
        <translation>Je dostupná nová verze %1</translation>
    </message>
    <message>
        <location filename="../../src/core/controller.cpp" line="226"/>
        <source>You have the latest version</source>
        <translation>Máte nejnovější verzi</translation>
    </message>
    <message>
        <location filename="../../src/core/controller.cpp" line="234"/>
        <source>Failed to get information about the latest version.</source>
        <translation>Nepodařilo se získat informace o nejnovější verzi.</translation>
    </message>
    <message>
        <location filename="../../src/core/controller.cpp" line="317"/>
        <source>Error</source>
        <translation>Chyba</translation>
    </message>
    <message>
        <location filename="../../src/core/controller.cpp" line="317"/>
        <source>Unable to close active modal widgets</source>
        <translation>Činné modální prvky nelze zavřít</translation>
    </message>
    <message>
        <location filename="../../src/core/controller.cpp" line="463"/>
        <source>&amp;Take Screenshot</source>
        <translation>&amp;Zachytit obrazovku</translation>
    </message>
    <message>
        <location filename="../../src/core/controller.cpp" line="479"/>
        <source>&amp;Open Launcher</source>
        <translation>&amp;Otevřít spouštěč</translation>
    </message>
    <message>
        <location filename="../../src/core/controller.cpp" line="484"/>
        <source>&amp;Configuration</source>
        <translation>&amp;Nastavení</translation>
    </message>
    <message>
        <location filename="../../src/core/controller.cpp" line="487"/>
        <source>&amp;About</source>
        <translation>O &amp;programu</translation>
    </message>
    <message>
        <location filename="../../src/core/controller.cpp" line="490"/>
        <source>Check for updates</source>
        <translation>Kontrola aktualizací</translation>
    </message>
    <message>
        <location filename="../../src/core/controller.cpp" line="497"/>
        <source>&amp;Latest Uploads</source>
        <translation>&amp;Nejnovější nahrané položky</translation>
    </message>
    <message>
        <location filename="../../src/core/controller.cpp" line="678"/>
        <source>URL copied to clipboard.</source>
        <translation>Adresa (URL) zkopírována do schránky.</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation type="vanished">&amp;Informace</translation>
    </message>
    <message>
        <location filename="../../src/core/controller.cpp" line="493"/>
        <source>&amp;Quit</source>
        <translation>&amp;Ukončit</translation>
    </message>
</context>
<context>
    <name>CopyTool</name>
    <message>
        <location filename="../../src/tools/copy/copytool.cpp" line="24"/>
        <source>Copy</source>
        <translation>Kopírovat</translation>
    </message>
    <message>
        <location filename="../../src/tools/copy/copytool.cpp" line="34"/>
        <source>Copy selection to clipboard</source>
        <translation>Kopírovat výběr do schránky</translation>
    </message>
    <message>
        <source>Copy the selection into the clipboard</source>
        <translation type="vanished">Kopírovat výběr do schránky</translation>
    </message>
</context>
<context>
    <name>DBusUtils</name>
    <message>
        <source>Unable to connect via DBus</source>
        <translation type="vanished">Nelze se spojit přes DBus</translation>
    </message>
</context>
<context>
    <name>ExitTool</name>
    <message>
        <location filename="../../src/tools/exit/exittool.cpp" line="23"/>
        <source>Exit</source>
        <translation>Ukončit</translation>
    </message>
    <message>
        <location filename="../../src/tools/exit/exittool.cpp" line="33"/>
        <source>Leave the capture screen</source>
        <translation>Opustit zachytávací obrazovku</translation>
    </message>
</context>
<context>
    <name>FileNameEditor</name>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="24"/>
        <source>Edit the name of your captures:</source>
        <translation>Upravit názvy zachycených obrazovek:</translation>
    </message>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="28"/>
        <source>Edit:</source>
        <translation>Upravit:</translation>
    </message>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="30"/>
        <source>Preview:</source>
        <translation>Náhled:</translation>
    </message>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="73"/>
        <source>Save</source>
        <translation>Uložit</translation>
    </message>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="76"/>
        <source>Saves the pattern</source>
        <translation>Uloží vzor</translation>
    </message>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="78"/>
        <source>Restore</source>
        <translation>Obnovit</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="vanished">Nastavit znovu</translation>
    </message>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="81"/>
        <source>Restores the saved pattern</source>
        <translation>Obnoví uložený vzor</translation>
    </message>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="83"/>
        <source>Clear</source>
        <translation>Smazat</translation>
    </message>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="89"/>
        <source>Deletes the name</source>
        <translation>Smaže název</translation>
    </message>
</context>
<context>
    <name>FlameshotDaemon</name>
    <message>
        <location filename="../../src/core/flameshotdaemon.cpp" line="264"/>
        <source>Unable to connect via DBus</source>
        <translation>Nelze se spojit přes DBus</translation>
    </message>
</context>
<context>
    <name>GeneneralConf</name>
    <message>
        <source>Import</source>
        <translation type="vanished">Zavést</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="vanished">Chyba</translation>
    </message>
    <message>
        <source>Unable to read file.</source>
        <translation type="vanished">Nelze přečíst soubor.</translation>
    </message>
    <message>
        <source>Unable to write file.</source>
        <translation type="vanished">Nelze zapsat soubor.</translation>
    </message>
    <message>
        <source>Save File</source>
        <translation type="vanished">Uložit soubor</translation>
    </message>
    <message>
        <source>Confirm Reset</source>
        <translation type="vanished">Potvrdit vrácení na výchozí</translation>
    </message>
    <message>
        <source>Are you sure you want to reset the configuration?</source>
        <translation type="vanished">Opravdu chcete nastavení vrátit do výchozího stavu?</translation>
    </message>
    <message>
        <source>Show help message</source>
        <translation type="vanished">Ukázat zprávu s nápovědou</translation>
    </message>
    <message>
        <source>Show the help message at the beginning in the capture mode.</source>
        <translation type="vanished">Ukázat zprávu s nápovědou na začátku v režimu zachytávání.</translation>
    </message>
    <message>
        <source>Show the side panel button</source>
        <translation type="vanished">Ukázat tlačítko na postranním panelu</translation>
    </message>
    <message>
        <source>Show the side panel toggle button in the capture mode.</source>
        <translation type="vanished">V režimu zachytávání ukazovat tlačítko na postranním panelu.</translation>
    </message>
    <message>
        <source>Show desktop notifications</source>
        <translation type="vanished">Ukázat oznámení</translation>
    </message>
    <message>
        <source>Show tray icon</source>
        <translation type="vanished">Ukázat ikonu v oznamovací oblasti panelu</translation>
    </message>
    <message>
        <source>Show the systemtray icon</source>
        <translation type="vanished">Ukázat ikonu v oznamovací oblasti panelu</translation>
    </message>
    <message>
        <source>Configuration File</source>
        <translation type="vanished">Soubor s nastavením</translation>
    </message>
    <message>
        <source>Export</source>
        <translation type="vanished">Vyvést</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="vanished">Nastavit znovu</translation>
    </message>
    <message>
        <source>Launch at startup</source>
        <translation type="vanished">Spustit při spuštění</translation>
    </message>
    <message>
        <source>Launch Flameshot</source>
        <translation type="vanished">Spustit Flameshot</translation>
    </message>
    <message>
        <source>Close after capture</source>
        <translation type="vanished">Zavřít po vytvoření snímku</translation>
    </message>
    <message>
        <source>Close after taking a screenshot</source>
        <translation type="vanished">Zavřít po vytvoření snímku obrazovky</translation>
    </message>
    <message>
        <source>Copy URL after upload</source>
        <translation type="vanished">Kopírovat adresu (URL) po nahrání</translation>
    </message>
    <message>
        <source>Copy URL and close window after upload</source>
        <translation type="vanished">Po nahrání zkopírovat URL a zavřít okno</translation>
    </message>
    <message>
        <source>Save image after copy</source>
        <translation type="vanished">Uložit obrázek po kopírování</translation>
    </message>
    <message>
        <source>Save image file after copying it</source>
        <translation type="vanished">Uložit obrázek se souborem po jeho zkopírování</translation>
    </message>
    <message>
        <source>Save Path</source>
        <translation type="vanished">Cesta pro ukládání</translation>
    </message>
    <message>
        <source>Change...</source>
        <translation type="vanished">Změnit...</translation>
    </message>
    <message>
        <source>Choose a Folder</source>
        <translation type="vanished">Vyberte složku</translation>
    </message>
    <message>
        <source>Unable to write to directory.</source>
        <translation type="vanished">Nelze zapsat do adresáře.</translation>
    </message>
</context>
<context>
    <name>GeneralConf</name>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="149"/>
        <location filename="../../src/config/generalconf.cpp" line="306"/>
        <source>Import</source>
        <translation>Zavést</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="156"/>
        <location filename="../../src/config/generalconf.cpp" line="164"/>
        <location filename="../../src/config/generalconf.cpp" line="188"/>
        <location filename="../../src/config/generalconf.cpp" line="626"/>
        <source>Error</source>
        <translation>Chyba</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="156"/>
        <source>Unable to read file.</source>
        <translation>Nelze přečíst soubor.</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="164"/>
        <location filename="../../src/config/generalconf.cpp" line="188"/>
        <source>Unable to write file.</source>
        <translation>Nelze zapsat soubor.</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="175"/>
        <source>Save File</source>
        <translation>Uložit soubor</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="197"/>
        <source>Confirm Reset</source>
        <translation>Potvrdit obnovení výchozí hodnoty</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="198"/>
        <source>Are you sure you want to reset the configuration?</source>
        <translation>Opravdu chcete nastavení vrátit do výchozího stavu?</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="229"/>
        <source>Show help message</source>
        <translation>Ukázat zprávu s nápovědou</translation>
    </message>
    <message>
        <source>Show the help message at the beginning in the capture mode.</source>
        <translation type="obsolete">Ukázat zprávu s nápovědou na začátku v režimu zachytávání.</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="240"/>
        <source>Show the side panel button</source>
        <translation>Ukázat tlačítko na postranním panelu</translation>
    </message>
    <message>
        <source>Show the side panel toggle button in the capture mode.</source>
        <translation type="obsolete">V režimu zachytávání ukazovat tlačítko na postranním panelu.</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="253"/>
        <source>Show desktop notifications</source>
        <translation>Ukázat oznámení na ploše</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="266"/>
        <source>Show tray icon</source>
        <translation>Ukázat ikonu v oznamovací oblasti panelu</translation>
    </message>
    <message>
        <source>Show the systemtray icon</source>
        <translation type="obsolete">Ukázat ikonu v oznamovací oblasti panelu</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="279"/>
        <source>Confirmation required to delete screenshot from the latest uploads</source>
        <translation>Pro smazání snímku obrazovky v nejnověji nahraných souborech je vyžadováno potvrzení</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="294"/>
        <source>Configuration File</source>
        <translation>Soubor s nastavením</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="299"/>
        <source>Export</source>
        <translation>Vyvést</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="313"/>
        <source>Reset</source>
        <translation>Obnovit výchozí</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="323"/>
        <source>Automatic check for updates</source>
        <translation>Automaticky se dívat po aktualizacích</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="336"/>
        <source>Allow multiple flameshot GUI instances simultaneously</source>
        <translation>Povolit více instancí grafického uživatelského rozhraní Flameshotu současně</translation>
    </message>
    <message>
        <source>This allows you to take screenshots of flameshot itself for example.</source>
        <translation type="vanished">This allows you to take screenshots of flameshot itself for example.</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="349"/>
        <location filename="../../src/config/generalconf.cpp" line="351"/>
        <source>Automatically close daemon when it is not needed</source>
        <translation>Automaticky zavřít démona, když není potřeba</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="361"/>
        <source>Launch at startup</source>
        <translation>Spustit při spuštění</translation>
    </message>
    <message>
        <source>Launch Flameshot</source>
        <translation type="obsolete">Spustit Flameshot</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="373"/>
        <source>Show welcome message on launch</source>
        <translation>Zobrazit uvítací zprávu při spuštění</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="388"/>
        <source>Use large predefined color palette</source>
        <translation>Použít velkou předem stanovenou paletu barev</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="402"/>
        <source>Copy URL after upload</source>
        <translation>Kopírovat adresu (URL) po nahrání</translation>
    </message>
    <message>
        <source>Copy URL and close window after upload</source>
        <translation type="obsolete">Po nahrání zkopírovat URL a zavřít okno</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="414"/>
        <source>Save image after copy</source>
        <translation>Uložit obrázek po kopírování</translation>
    </message>
    <message>
        <source>Save image file after copying it</source>
        <translation type="obsolete">Uložit obrázek se souborem po jeho zkopírování</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="230"/>
        <source>Show the help message at the beginning in the capture mode</source>
        <translation>Ukázat zprávu s nápovědou na začátku v režimu zachytávání</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="242"/>
        <source>Show the side panel toggle button in the capture mode</source>
        <translation>V režimu zachytávání ukazovat tlačítko na postranním panelu</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="254"/>
        <source>Enable desktop notifications</source>
        <translation>Povolit oznámení na ploše</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="267"/>
        <source>Show icon in the system tray</source>
        <translation>Ukázat ikonu v oznamovací oblasti panelu</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="282"/>
        <source>Ask for confirmation to delete screenshot from the latest uploads</source>
        <translation>PožádT o potvrzení pro odstranĚNÍ snímKU obrazovky z nejnověji nahraných videí</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="324"/>
        <source>Check for updates automatically</source>
        <translation>Automaticky se dívat po aktualizacích</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="337"/>
        <source>This allows you to take screenshots of Flameshot itself for example</source>
        <translation>To vám například umožňuje pořizovat snímky obrazovky se samotným Flameshotem</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="363"/>
        <source>Launch Flameshot daemon when computer is booted</source>
        <translation>Spustit démona Flameshotu při spuštění počítače</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="376"/>
        <source>Show the welcome message box in the middle of the screen while taking a screenshot</source>
        <translation>Při pořizování snímku obrazovky zobrazit okno s uvítací zprávou uprostřed obrazovky</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="390"/>
        <source>Use a large predefined color palette</source>
        <translation>Použít velkou předem stanovenou paletu barev</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="404"/>
        <source>Copy URL and close window after uploading was successful</source>
        <translation>Po úspěšném nahrání zkopírovat adresu (URL) a zavřít okno</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="416"/>
        <source>After copying the screenshot, save it to a file as well</source>
        <translation>Po zkopírování snímku obrazovky jej uložit do souboru</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="423"/>
        <source>Save Path</source>
        <translation>Cesta pro ukládání</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="439"/>
        <source>Change...</source>
        <translation>Změnit...</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="447"/>
        <source>Use fixed path for screenshots to save</source>
        <translation>Pro uložení snímků obrazovky použít pevnou cestu</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="459"/>
        <source>Preferred save file extension:</source>
        <translation>Upřednostňovaná přípona souboru při uložení:</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="489"/>
        <source>Latest Uploads Max Size</source>
        <translation>Největší velikost nejnověji nahraných souborů</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="516"/>
        <source>Undo limit</source>
        <translation>Omezení pro počet kroků zpět</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="542"/>
        <location filename="../../src/config/generalconf.cpp" line="544"/>
        <source>Use JPG format for clipboard (PNG default)</source>
        <translation>Použít pro schránku formát JPG (výchozí PNG)</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="574"/>
        <source>Copy file path after save</source>
        <translation>Po uložení zkopírovat cestu k souboru</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="575"/>
        <source>Copy the file path to clipboard after the file is saved</source>
        <translation>Po uložení souboru zkopírovat cestu k souboru do schránky</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="586"/>
        <source>Anti-aliasing image when zoom the pinned image</source>
        <translation>Vyhlazení obrazu při přiblížení připnutého obrázku</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="588"/>
        <source>After zooming the pinned image, should the image get smoothened or stay pixelated</source>
        <translation>Po přiblížení připnutého obrázku se má obrázek vyhladit nebo má zůstat rozčtverečkovaný</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="599"/>
        <location filename="../../src/config/generalconf.cpp" line="601"/>
        <source>Upload image without confirmation</source>
        <translation>Nahrát obrázek bez potvrzení</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="617"/>
        <source>Choose a Folder</source>
        <translation>Vyberte složku</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="626"/>
        <source>Unable to write to directory.</source>
        <translation>Nelze zapsat do adresáře.</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="635"/>
        <source>Show magnifier</source>
        <translation>Ukázat lupu</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="636"/>
        <source>Enable a magnifier while selecting the screenshot area</source>
        <translation>Při výběru oblasti snímku obrazovky povolit lupu</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="647"/>
        <source>Square shaped magnifier</source>
        <translation>Lupa čtvercového tvaru</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="648"/>
        <source>Make the magnifier to be square-shaped</source>
        <translation>Zobrazit lupu tak, aby měla čtvercový tvar</translation>
    </message>
</context>
<context>
    <name>HistoryWidget</name>
    <message>
        <source>Latest Uploads</source>
        <translation type="vanished">Latest Uploads</translation>
    </message>
    <message>
        <source>Screenshots history is empty</source>
        <translation type="vanished">Screenshots history is empty</translation>
    </message>
    <message>
        <source>Copy URL</source>
        <translation type="obsolete">Kopírovat adresu (URL)</translation>
    </message>
    <message>
        <source>URL copied to clipboard.</source>
        <translation type="obsolete">Adresa (URL) zkopírována do schránky.</translation>
    </message>
    <message>
        <source>Open in browser</source>
        <translation type="vanished">Open in browser</translation>
    </message>
    <message>
        <source>Confirm to delete</source>
        <translation type="vanished">Confirm to delete</translation>
    </message>
    <message>
        <source>Are you sure you want to delete a screenshot from the latest uploads and server?</source>
        <translation type="vanished">Are you sure you want to delete a screenshot from the latest uploads and server?</translation>
    </message>
</context>
<context>
    <name>ImgS3Uploader</name>
    <message>
        <source>Uploading Image</source>
        <translation type="obsolete">Nahrává se obrázek</translation>
    </message>
    <message>
        <source>URL copied to clipboard.</source>
        <translation type="obsolete">Adresa (URL) zkopírována do schránky.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="obsolete">Chyba</translation>
    </message>
</context>
<context>
    <name>ImgUploadDialog</name>
    <message>
        <location filename="../../src/widgets/imguploaddialog.cpp" line="18"/>
        <source>Upload Confirmation</source>
        <translation>Potvrzení nahrání</translation>
    </message>
    <message>
        <location filename="../../src/widgets/imguploaddialog.cpp" line="22"/>
        <source>Do you want to upload this capture?</source>
        <translation>Chcete nahrát tento záběr  zachycené obrazovky?</translation>
    </message>
    <message>
        <location filename="../../src/widgets/imguploaddialog.cpp" line="35"/>
        <location filename="../../src/widgets/imguploaddialog.cpp" line="36"/>
        <source>Upload without confirmation</source>
        <translation>Nahrát bez potvrzení</translation>
    </message>
</context>
<context>
    <name>ImgUploader</name>
    <message>
        <source>Uploading Image</source>
        <translation type="obsolete">Nahrává se obrázek</translation>
    </message>
    <message>
        <source>Unable to open the URL.</source>
        <translation type="obsolete">Nelze otevřít adresu (URL).</translation>
    </message>
    <message>
        <source>URL copied to clipboard.</source>
        <translation type="obsolete">Adresa (URL) zkopírována do schránky.</translation>
    </message>
    <message>
        <source>Screenshot copied to clipboard.</source>
        <translation type="obsolete">Snímek obrazovky zkopírován do schránky.</translation>
    </message>
    <message>
        <source>Copy URL</source>
        <translation type="obsolete">Kopírovat adresu (URL)</translation>
    </message>
    <message>
        <source>Open URL</source>
        <translation type="obsolete">Otevřít adresu (URL)</translation>
    </message>
    <message>
        <source>Delete image</source>
        <translation type="obsolete">Smazat obrázek</translation>
    </message>
    <message>
        <source>Image to Clipboard.</source>
        <translation type="obsolete">Obrázek do schránky.</translation>
    </message>
</context>
<context>
    <name>ImgUploaderBase</name>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="37"/>
        <source>Upload image</source>
        <translation>Nahrát obrázek</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="51"/>
        <source>Uploading Image</source>
        <translation>Nahrává se obrázek</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="130"/>
        <source>Copy URL</source>
        <translation>Kopírovat adresu (URL)</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="131"/>
        <source>Open URL</source>
        <translation>Otevřít adresu (URL)</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="132"/>
        <source>Delete image</source>
        <translation>Smazat obrázek</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="133"/>
        <source>Image to Clipboard.</source>
        <translation>Obrázek do schránky.</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="134"/>
        <source>Save image</source>
        <translation>Uložit obrázek</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="164"/>
        <source>Unable to open the URL.</source>
        <translation>Nelze otevřít adresu (URL).</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="171"/>
        <source>URL copied to clipboard.</source>
        <translation>Adresa (URL) zkopírována do schránky.</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="177"/>
        <source>Screenshot copied to clipboard.</source>
        <translation>Snímek obrazovky zkopírován do schránky.</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="191"/>
        <source>Unable to save the screenshot to disk.</source>
        <translation>Snímek obrazovky nelze uložit na disk.</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="194"/>
        <source>Screenshot saved.</source>
        <translation>Snímek obrazovky uložen.</translation>
    </message>
</context>
<context>
    <name>ImgUploaderTool</name>
    <message>
        <location filename="../../src/tools/imgupload/imguploadertool.cpp" line="23"/>
        <source>Image Uploader</source>
        <translation>Nahrávač obrázků</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/imguploadertool.cpp" line="33"/>
        <source>Upload the selection</source>
        <translation>Nahrát výběr</translation>
    </message>
</context>
<context>
    <name>ImgurUploader</name>
    <message>
        <source>Upload to Imgur</source>
        <translation type="vanished">Nahrát do Imgur</translation>
    </message>
    <message>
        <source>Uploading Image</source>
        <translation type="vanished">Nahrává se obrázek</translation>
    </message>
    <message>
        <source>Copy URL</source>
        <translation type="vanished">Kopírovat adresu (URL)</translation>
    </message>
    <message>
        <source>Open URL</source>
        <translation type="vanished">Otevřít adresu (URL)</translation>
    </message>
    <message>
        <source>Delete image</source>
        <translation type="vanished">Smazat obrázek</translation>
    </message>
    <message>
        <source>Image to Clipboard.</source>
        <translation type="vanished">Obrázek do schránky.</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imgur/imguruploader.cpp" line="92"/>
        <source>Unable to open the URL.</source>
        <translation>Nelze otevřít adresu (URL).</translation>
    </message>
    <message>
        <source>URL copied to clipboard.</source>
        <translation type="vanished">Adresa (URL) zkopírována do schránky.</translation>
    </message>
    <message>
        <source>Screenshot copied to clipboard.</source>
        <translation type="vanished">Snímek obrazovky zkopírován do schránky.</translation>
    </message>
</context>
<context>
    <name>ImgurUploaderTool</name>
    <message>
        <source>Image Uploader</source>
        <translation type="vanished">Nahrávač obrázků</translation>
    </message>
    <message>
        <source>Upload the selection to Imgur</source>
        <translation type="vanished">Nahrát výběr do Imgur</translation>
    </message>
</context>
<context>
    <name>InfoWindow</name>
    <message>
        <location filename="../../src/widgets/infowindow.ui" line="14"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_infowindow.h" line="117"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_infowindow.h" line="117"/>
        <source>About</source>
        <translation>O programu</translation>
    </message>
    <message>
        <location filename="../../src/widgets/infowindow.ui" line="26"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_infowindow.h" line="118"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_infowindow.h" line="118"/>
        <source>Icon</source>
        <translation>Ikona</translation>
    </message>
    <message>
        <location filename="../../src/widgets/infowindow.ui" line="43"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_infowindow.h" line="119"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_infowindow.h" line="119"/>
        <source>License</source>
        <translation>Povolení</translation>
    </message>
    <message>
        <location filename="../../src/widgets/infowindow.ui" line="56"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_infowindow.h" line="120"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_infowindow.h" line="120"/>
        <source>GPLv3+</source>
        <translation>GPLv3+</translation>
    </message>
    <message>
        <location filename="../../src/widgets/infowindow.ui" line="89"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_infowindow.h" line="121"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_infowindow.h" line="121"/>
        <source>Version</source>
        <translation>Verze</translation>
    </message>
    <message>
        <location filename="../../src/widgets/infowindow.ui" line="102"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_infowindow.h" line="122"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_infowindow.h" line="122"/>
        <source>Flameshot v</source>
        <translation>Flameshot v</translation>
    </message>
    <message>
        <location filename="../../src/widgets/infowindow.ui" line="115"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_infowindow.h" line="123"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_infowindow.h" line="123"/>
        <source>OS Info</source>
        <translation>Informace o operačním systému</translation>
    </message>
    <message>
        <location filename="../../src/widgets/infowindow.ui" line="128"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_infowindow.h" line="124"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_infowindow.h" line="124"/>
        <source>Copy Info</source>
        <translation>Informace o kopírování</translation>
    </message>
    <message>
        <source>SPACEBAR</source>
        <translation type="vanished">MEZERNÍK</translation>
    </message>
    <message>
        <source>Right Click</source>
        <translation type="vanished">Klepnutí pravým tlačítkem myši</translation>
    </message>
    <message>
        <source>Mouse Wheel</source>
        <translation type="vanished">Kolečko myši</translation>
    </message>
    <message>
        <source>Move selection 1px</source>
        <translation type="vanished">Posunout výběr o 1 px</translation>
    </message>
    <message>
        <source>Resize selection 1px</source>
        <translation type="vanished">Změnit velikost výběru o 1 px</translation>
    </message>
    <message>
        <source>Quit capture</source>
        <translation type="vanished">Ukončit zachytávání obrazovky</translation>
    </message>
    <message>
        <source>Copy to clipboard</source>
        <translation type="vanished">Kopírovat do schránky</translation>
    </message>
    <message>
        <source>Save selection as a file</source>
        <translation type="vanished">Uložit výběr jako soubor</translation>
    </message>
    <message>
        <source>Undo the last modification</source>
        <translation type="vanished">Zrušit poslední změnu</translation>
    </message>
    <message>
        <source>Toggle visibility of sidebar with options of the selected tool</source>
        <translation type="vanished">Přepnout viditelnost postranního panelu s volbali pro vybraný nástroj</translation>
    </message>
    <message>
        <source>Show color picker</source>
        <translation type="vanished">Ukázat volič barev</translation>
    </message>
    <message>
        <source>Change the tool&apos;s thickness</source>
        <translation type="vanished">Změnit tloušťku nástroje</translation>
    </message>
    <message>
        <source>Available shortcuts in the screen capture mode.</source>
        <translation type="vanished">Dostupné zkratky v režimu zachytávání obrazovky.</translation>
    </message>
    <message>
        <source>Key</source>
        <translation type="vanished">Klávesa</translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="vanished">Popis</translation>
    </message>
    <message>
        <source>&lt;u&gt;&lt;b&gt;License&lt;/b&gt;&lt;/u&gt;</source>
        <translation type="vanished">&lt;u&gt;&lt;b&gt;Licence&lt;/b&gt;&lt;/u&gt;</translation>
    </message>
    <message>
        <source>&lt;u&gt;&lt;b&gt;Version&lt;/b&gt;&lt;/u&gt;</source>
        <translation type="vanished">&lt;u&gt;&lt;b&gt;Verze&lt;/b&gt;&lt;/u&gt;</translation>
    </message>
    <message>
        <source>&lt;u&gt;&lt;b&gt;Shortcuts&lt;/b&gt;&lt;/u&gt;</source>
        <translation type="vanished">&lt;u&gt;&lt;b&gt;Zkratky&lt;/b&gt;&lt;/u&gt;</translation>
    </message>
</context>
<context>
    <name>InvertTool</name>
    <message>
        <location filename="../../src/tools/invert/inverttool.cpp" line="25"/>
        <source>Invert</source>
        <translation>Obrátit</translation>
    </message>
    <message>
        <location filename="../../src/tools/invert/inverttool.cpp" line="35"/>
        <source>Set Inverter as the paint tool</source>
        <translation>Nastavit obraceč jako nástroj malování</translation>
    </message>
</context>
<context>
    <name>LineTool</name>
    <message>
        <location filename="../../src/tools/line/linetool.cpp" line="22"/>
        <source>Line</source>
        <translation>Čára</translation>
    </message>
    <message>
        <location filename="../../src/tools/line/linetool.cpp" line="32"/>
        <source>Set the Line as the paint tool</source>
        <translation>Nastavit čáru jako malovací nástroj</translation>
    </message>
</context>
<context>
    <name>MarkerTool</name>
    <message>
        <location filename="../../src/tools/marker/markertool.cpp" line="23"/>
        <source>Marker</source>
        <translation>Zvýrazňovač</translation>
    </message>
    <message>
        <location filename="../../src/tools/marker/markertool.cpp" line="33"/>
        <source>Set the Marker as the paint tool</source>
        <translation>Nastavit zvýrazňovač jako malovací nástroj</translation>
    </message>
</context>
<context>
    <name>MoveTool</name>
    <message>
        <location filename="../../src/tools/move/movetool.cpp" line="23"/>
        <source>Move</source>
        <translation>Posunutí</translation>
    </message>
    <message>
        <location filename="../../src/tools/move/movetool.cpp" line="33"/>
        <source>Move the selection area</source>
        <translation>Posunout oblast výběru</translation>
    </message>
</context>
<context>
    <name>PencilTool</name>
    <message>
        <location filename="../../src/tools/pencil/penciltool.cpp" line="18"/>
        <source>Pencil</source>
        <translation>Tužka</translation>
    </message>
    <message>
        <location filename="../../src/tools/pencil/penciltool.cpp" line="28"/>
        <source>Set the Pencil as the paint tool</source>
        <translation>Nastavit tužku jako malovací nástroj</translation>
    </message>
</context>
<context>
    <name>PinTool</name>
    <message>
        <location filename="../../src/tools/pin/pintool.cpp" line="25"/>
        <source>Pin Tool</source>
        <translation>Přišpendlení</translation>
    </message>
    <message>
        <location filename="../../src/tools/pin/pintool.cpp" line="35"/>
        <source>Pin image on the desktop</source>
        <translation>Přišpendlit obrázek na plochu</translation>
    </message>
</context>
<context>
    <name>PixelateTool</name>
    <message>
        <location filename="../../src/tools/pixelate/pixelatetool.cpp" line="24"/>
        <source>Pixelate</source>
        <translation>Rozčtverečkování</translation>
    </message>
    <message>
        <location filename="../../src/tools/pixelate/pixelatetool.cpp" line="34"/>
        <source>Set Pixelate as the paint tool</source>
        <translation>Nastaviť rozčtverečkování jako nástroj pro úpravy</translation>
    </message>
</context>
<context>
    <name>QHotkey</name>
    <message>
        <location filename="../../external/QHotkey/qhotkey.cpp" line="307"/>
        <source>Failed to register %1. Error: %2</source>
        <translation>Nepodařilo se zaregistrovat %1. Chyba: %2</translation>
    </message>
    <message>
        <location filename="../../external/QHotkey/qhotkey.cpp" line="329"/>
        <source>Failed to unregister %1. Error: %2</source>
        <translation>Nepodařilo se zrušit registraci %1. Chyba: %2</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../src/utils/screenshotsaver.cpp" line="214"/>
        <source>Save Error</source>
        <translation>Chyba při ukládání</translation>
    </message>
    <message>
        <location filename="../../src/utils/screenshotsaver.cpp" line="46"/>
        <location filename="../../src/utils/screenshotsaver.cpp" line="198"/>
        <source>Capture saved as </source>
        <translation>Zachycená obrazovka uložena jako </translation>
    </message>
    <message>
        <location filename="../../src/utils/screenshotsaver.cpp" line="136"/>
        <location filename="../../src/utils/screenshotsaver.cpp" line="138"/>
        <source>Capture saved to clipboard.</source>
        <translation>Zachycená obrazovka uložena do schránky.</translation>
    </message>
    <message>
        <source>Capture saved to clipboard</source>
        <translation type="vanished">Zachycená obrazovka uložena do schránky</translation>
    </message>
    <message>
        <location filename="../../src/utils/screenshotsaver.cpp" line="122"/>
        <source>Error while saving to clipboard</source>
        <translation>Chyba při ukládání do schránky</translation>
    </message>
    <message>
        <location filename="../../src/utils/screenshotsaver.cpp" line="50"/>
        <location filename="../../src/utils/screenshotsaver.cpp" line="207"/>
        <source>Error trying to save as </source>
        <translation>Chyba při ukládání jako </translation>
    </message>
    <message>
        <location filename="../../src/utils/screenshotsaver.cpp" line="181"/>
        <source>Save screenshot</source>
        <translation>Uložit snímek obrazovky</translation>
    </message>
    <message>
        <location filename="../../src/utils/screenshotsaver.cpp" line="203"/>
        <source>Path copied to clipboard as </source>
        <translation>Cesta zkopírována do schránky jako </translation>
    </message>
    <message>
        <source>Saving canceled</source>
        <translation type="vanished">Saving canceled</translation>
    </message>
    <message>
        <source>Save canceled</source>
        <translation type="vanished">Save canceled</translation>
    </message>
    <message>
        <source>Capture is saved and copied to the clipboard as </source>
        <translation type="vanished">Capture is saved and copied to the clipboard as </translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="135"/>
        <source>Unable to connect via DBus</source>
        <translation>Nelze se spojit přes DBus</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="151"/>
        <source>Powerful yet simple to use screenshot software.</source>
        <translation>Silný, ale zároveň též jednoduchý program na zachytávání obrazovky.</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="152"/>
        <source>See</source>
        <translation>Podívejte se</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="155"/>
        <source>Capture the entire desktop.</source>
        <translation>Zachytit celou plochu.</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="157"/>
        <source>Open the capture launcher.</source>
        <translation>Otevřít spouštěč zachytávání.</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="160"/>
        <source>Start a manual capture in GUI mode.</source>
        <translation>Spustit ruční zachytávání v režimu uživatelského rozhraní.</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="162"/>
        <source>Configure</source>
        <translation>Nastavit</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="164"/>
        <source>Capture a single screen.</source>
        <translation>Zachytit jednu obrazovku.</translation>
    </message>
    <message>
        <source>Path where the capture will be saved</source>
        <translation type="vanished">Cesta, kam bude snímek uložen</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="169"/>
        <source>Existing directory or new file to save to</source>
        <translation>Stávající adresář nebo nový soubor k uložení</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="172"/>
        <source>Save the capture to the clipboard</source>
        <translation>Uložit snímek do schránky</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="174"/>
        <source>Pin the capture to the screen</source>
        <translation>Připnout záběr se zachycenou obrazovkou k obrazovce</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="176"/>
        <source>Upload screenshot</source>
        <translation>Nahrát snímek obrazovky</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="178"/>
        <source>Delay time in milliseconds</source>
        <translation>Čas zpoždění v milisekundách</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="181"/>
        <source>Screenshot region to select</source>
        <translation>Oblast snímku obrazovky k vybrání</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="184"/>
        <source>Set the filename pattern</source>
        <translation>Nastavit vzor pro pojmenování souborů</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="188"/>
        <source>Accept capture as soon as a selection is made</source>
        <translation>Přijmout zachycení obrazovky, jakmile se provede výběr</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="190"/>
        <source>Enable or disable the trayicon</source>
        <translation>Povolit nebo zakázat ikonu v oznamovací oblasti panelu</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="194"/>
        <source>Enable or disable run at startup</source>
        <translation>Povolit nebo zakázat spuštění při spuštění systému</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="197"/>
        <source>Check the configuration for errors</source>
        <translation>Zkontrolovat nastavení, zda neobsahuje chyby</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="200"/>
        <source>Show the help message in the capture mode</source>
        <translation>Ukazovat nápovědu v režimu zachytávání</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="203"/>
        <source>Define the main UI color</source>
        <translation>Nastavit barvu hlavního uživatelského rozhraní</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="207"/>
        <source>Define the contrast UI color</source>
        <translation>Nastavit kontrastní barvu uživatelského rozhraní</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="210"/>
        <source>Print raw PNG capture</source>
        <translation>Zobrazit nezpracovaný PNG snímek</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="213"/>
        <source>Print geometry of the selection in the format W H X Y. Does nothing if raw is specified</source>
        <translation>Zobrazit natočení výběru ve formátu Š V X Y. Nedělá nic, pokud je zadáno nezpracovaný</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="217"/>
        <source>Define the screen to capture (starting from 0)</source>
        <translation>Stanovit obrazovku, která bude zachytávána (od 0)</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="237"/>
        <source>Invalid delay, it must be a number greater than 0</source>
        <translation>Neplatné zpoždění, musí to být číslo větší než 0</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="240"/>
        <source>Invalid region, use &apos;WxH+X+Y&apos; or &apos;all&apos; or &apos;screen0/screen1/...&apos;.</source>
        <translation>Neplatná oblast, použijte „ŠxV+X+Y“ nebo „vše“ nebo „screen0/screen1/...“.</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="253"/>
        <source>Invalid path, must be an existing directory or a new file in an existing directory</source>
        <translation>Neplatná cesta, musí se jednat o stávající adresář nebo nový soubor v existujícím adresáři</translation>
    </message>
    <message>
        <source>Define the screen to capture</source>
        <translation type="vanished">Nastavit monitor, který bude zachytáván</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="218"/>
        <source>default: screen containing the cursor</source>
        <translation>výchozí: obrazovka, na které je ukazovátko myši</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="219"/>
        <source>Screen number</source>
        <translation>Číslo obrazovky</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="228"/>
        <source>Invalid color, this flag supports the following formats:
- #RGB (each of R, G, and B is a single hex digit)
- #RRGGBB
- #RRRGGGBBB
- #RRRRGGGGBBBB
- Named colors like &apos;blue&apos; or &apos;red&apos;
You may need to escape the &apos;#&apos; sign as in &apos;\#FFF&apos;</source>
        <translation>Neplatná barva, tento přepínač podporuje následující formáty:
- #RGB (každá ze složek R, G a B je samostatným hexadecimálním číslem)
- #RRGGBB
- #RRRGGGBBB
- #RRRRGGGGBBBB
- anglické názvy barev jako &apos;blue&apos; nebo &apos;red&apos;
Možná budete muset napsat před &apos;#&apos; opačné (obrácené) lomítko, tedy &apos;\#FFF&apos;</translation>
    </message>
    <message>
        <source>Invalid delay, it must be higher than 0</source>
        <translation type="vanished">Neplatné zpoždění, musí být vyšší než 0</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="239"/>
        <source>Invalid screen number, it must be non negative</source>
        <translation>Neplatné číslo obrazovky, může být jen kladné</translation>
    </message>
    <message>
        <source>Invalid path, it must be a real path in the system</source>
        <translation type="vanished">Neplatná cesta, musí se jednat o skutečnou cestu v systému</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="266"/>
        <source>Invalid value, it must be defined as &apos;true&apos; or &apos;false&apos;</source>
        <translation>Neplatná hodnota, musí být vymezenná jako &apos;pravda&apos; nebo &apos;nepravda&apos;</translation>
    </message>
    <message>
        <location filename="../../src/tools/launcher/openwithprogram.cpp" line="30"/>
        <source>Error</source>
        <translation>Chyba</translation>
    </message>
    <message>
        <location filename="../../src/tools/launcher/openwithprogram.cpp" line="31"/>
        <source>Unable to write in</source>
        <translation>Nelze zapsat</translation>
    </message>
    <message>
        <location filename="../../src/cli/commandlineparser.cpp" line="54"/>
        <source>Options</source>
        <translation>Volby</translation>
    </message>
    <message>
        <location filename="../../src/cli/commandlineparser.cpp" line="68"/>
        <source>Arguments</source>
        <translation>Argumenty</translation>
    </message>
    <message>
        <location filename="../../src/cli/commandlineparser.cpp" line="329"/>
        <source>arguments</source>
        <translation>argumenty</translation>
    </message>
    <message>
        <location filename="../../src/cli/commandlineparser.cpp" line="330"/>
        <source>Usage</source>
        <translation>Použití</translation>
    </message>
    <message>
        <location filename="../../src/cli/commandlineparser.cpp" line="330"/>
        <source>options</source>
        <translation>volby</translation>
    </message>
    <message>
        <location filename="../../src/cli/commandlineparser.cpp" line="337"/>
        <source>Per default runs Flameshot in the background and adds a tray icon for configuration.</source>
        <translation>Ve výchozím nastavení spustí Flameshot na pozadí a v oznamovacím panelu přidá ikonu pro nastavení.</translation>
    </message>
    <message>
        <source>Per default runs Flameshot in the background and   adds a tray icon for configuration.</source>
        <translation type="vanished">Obvykle se Flameshot spouští na pozadí a přidává do oznamovací oblasti panelu ikonu, kterou je ho možné ovládat.</translation>
    </message>
    <message>
        <location filename="../../src/core/controller.cpp" line="656"/>
        <source>Full screen screenshot pinned to screen</source>
        <translation>Snímek celé obrazovky připnutý na obrazovku</translation>
    </message>
    <message>
        <source>URL copied to clipboard.</source>
        <translation type="vanished">Adresa (URL) zkopírována do schránky.</translation>
    </message>
    <message>
        <location filename="../../src/core/controller.cpp" line="569"/>
        <source>Hello, I&apos;m here! Click icon in the tray to take a screenshot or click with a right button to see more options.</source>
        <translation>Ahoj, jsem tady! Klepnutím na ikonu v oznamovacím panelu pořídíte snímek obrazovky nebo klepnutím pravým tlačítkem zobrazíte další možnosti.</translation>
    </message>
    <message>
        <source>Toggle side panel</source>
        <translation type="vanished">Toggle side panel</translation>
    </message>
    <message>
        <source>Resize selection left 1px</source>
        <translation type="vanished">Resize selection left 1px</translation>
    </message>
    <message>
        <source>Resize selection right 1px</source>
        <translation type="vanished">Resize selection right 1px</translation>
    </message>
    <message>
        <source>Resize selection up 1px</source>
        <translation type="vanished">Resize selection up 1px</translation>
    </message>
    <message>
        <source>Resize selection down 1px</source>
        <translation type="vanished">Resize selection down 1px</translation>
    </message>
    <message>
        <source>Select entire screen</source>
        <translation type="vanished">Select entire screen</translation>
    </message>
    <message>
        <source>Move selection left 1px</source>
        <translation type="vanished">Move selection left 1px</translation>
    </message>
    <message>
        <source>Move selection right 1px</source>
        <translation type="vanished">Move selection right 1px</translation>
    </message>
    <message>
        <source>Move selection up 1px</source>
        <translation type="vanished">Move selection up 1px</translation>
    </message>
    <message>
        <source>Move selection down 1px</source>
        <translation type="vanished">Move selection down 1px</translation>
    </message>
    <message>
        <source>Commit text in text area</source>
        <translation type="vanished">Commit text in text area</translation>
    </message>
    <message>
        <source>Delete current tool</source>
        <translation type="vanished">Delete current tool</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="187"/>
        <source>Quit capture</source>
        <translation>Ukončit zachytávání obrazovky</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="195"/>
        <source>Screenshot history</source>
        <translation>Historie snímků obrazovky</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="198"/>
        <source>Capture screen</source>
        <translation>Zachytit obrazovku</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="205"/>
        <source>Show color picker</source>
        <translation>Ukázat volič barev</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="206"/>
        <source>Change the tool&apos;s size</source>
        <translation>Změnit velikost nástroje</translation>
    </message>
    <message>
        <source>Change the tool&apos;s thickness</source>
        <translation type="obsolete">Změnit tloušťku nástroje</translation>
    </message>
</context>
<context>
    <name>RectangleTool</name>
    <message>
        <location filename="../../src/tools/rectangle/rectangletool.cpp" line="22"/>
        <source>Rectangle</source>
        <translation>Obdélník</translation>
    </message>
    <message>
        <location filename="../../src/tools/rectangle/rectangletool.cpp" line="32"/>
        <source>Set the Rectangle as the paint tool</source>
        <translation>Nastavit obdélník jako malovací nástroj</translation>
    </message>
</context>
<context>
    <name>RedoTool</name>
    <message>
        <location filename="../../src/tools/redo/redotool.cpp" line="23"/>
        <source>Redo</source>
        <translation>Znovu</translation>
    </message>
    <message>
        <location filename="../../src/tools/redo/redotool.cpp" line="33"/>
        <source>Redo the next modification</source>
        <translation>Znovu udělat další změnu</translation>
    </message>
</context>
<context>
    <name>SaveTool</name>
    <message>
        <location filename="../../src/tools/save/savetool.cpp" line="24"/>
        <source>Save</source>
        <translation>Uložit</translation>
    </message>
    <message>
        <location filename="../../src/tools/save/savetool.cpp" line="34"/>
        <source>Save screenshot to a file</source>
        <translation>Uložit snímek obrazovky do souboru</translation>
    </message>
    <message>
        <source>Save the capture</source>
        <translation type="vanished">Uložit zachycenou obrazovku</translation>
    </message>
</context>
<context>
    <name>ScreenGrabber</name>
    <message>
        <location filename="../../src/utils/screengrabber.cpp" line="131"/>
        <source>Unable to capture screen</source>
        <translation>Nelze zachytit obrazovku</translation>
    </message>
</context>
<context>
    <name>SelectionTool</name>
    <message>
        <location filename="../../src/tools/selection/selectiontool.cpp" line="25"/>
        <source>Rectangular Selection</source>
        <translation>Obdélníkový výběr</translation>
    </message>
    <message>
        <location filename="../../src/tools/selection/selectiontool.cpp" line="35"/>
        <source>Set Selection as the paint tool</source>
        <translation>Nastavit výběr jako malovací nástroj</translation>
    </message>
</context>
<context>
    <name>SetShortcutDialog</name>
    <message>
        <location filename="../../src/config/setshortcutwidget.cpp" line="17"/>
        <source>Set Shortcut</source>
        <translation>Nastavit klávesovou zkratku</translation>
    </message>
    <message>
        <location filename="../../src/config/setshortcutwidget.cpp" line="23"/>
        <source>Enter new shortcut to change </source>
        <translation>Zadejte novou zkratku, kterou chcete změnit </translation>
    </message>
    <message>
        <location filename="../../src/config/setshortcutwidget.cpp" line="37"/>
        <source>Press Esc to cancel or ⌘+Backspace to disable the keyboard shortcut.</source>
        <translation>Stiskněte Esc pro zrušení nebo ⌘+Backspace pro vypnutí klávesové zkratky.</translation>
    </message>
    <message>
        <location filename="../../src/config/setshortcutwidget.cpp" line="41"/>
        <source>Press Esc to cancel or Backspace to disable the keyboard shortcut.</source>
        <translation>Stiskněte Esc pro zrušení nebo Backspace pro vypnutí klávesové zkratky.</translation>
    </message>
    <message>
        <location filename="../../src/config/setshortcutwidget.cpp" line="46"/>
        <source>Flameshot must be restarted for changes to take effect.</source>
        <translation>Aby se změny projevily, musí být Flameshot restartován.</translation>
    </message>
</context>
<context>
    <name>ShortcutsWidget</name>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="30"/>
        <source>Hot Keys</source>
        <translation>Klávesové zkratky</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="53"/>
        <source>Available shortcuts in the screen capture mode.</source>
        <translation>Dostupné zkratky v režimu zachytávání obrazovky.</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="64"/>
        <source>Description</source>
        <translation>Popis</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="64"/>
        <source>Key</source>
        <translation>Klávesa</translation>
    </message>
</context>
<context>
    <name>SidePanelWidget</name>
    <message>
        <source>Active color:</source>
        <translation type="vanished">Nynější barva:</translation>
    </message>
    <message>
        <source>Press ESC to cancel</source>
        <translation type="vanished">Stiskněte Esc pro zrušení</translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/sidepanelwidget.cpp" line="36"/>
        <source>Active tool size: </source>
        <translation>Velikost činného nástroje: </translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/sidepanelwidget.cpp" line="48"/>
        <source>Active Color: </source>
        <translation>Nynější barva: </translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/sidepanelwidget.cpp" line="69"/>
        <source>Grab Color</source>
        <translation>Chytit barvu</translation>
    </message>
    <message>
        <source>Active thickness:</source>
        <translation type="vanished">Nynější tloušťka:</translation>
    </message>
</context>
<context>
    <name>SizeDecreaseTool</name>
    <message>
        <location filename="../../src/tools/sizedecrease/sizedecreasetool.cpp" line="37"/>
        <source>Decrease Tool Size</source>
        <translation>Zmenšit velikost nástroje</translation>
    </message>
    <message>
        <location filename="../../src/tools/sizedecrease/sizedecreasetool.cpp" line="47"/>
        <source>Decrease the size of the other tools</source>
        <translation>Zmenšit velikost ostatních nástrojů</translation>
    </message>
</context>
<context>
    <name>SizeIncreaseTool</name>
    <message>
        <location filename="../../src/tools/sizeincrease/sizeincreasetool.cpp" line="37"/>
        <source>Increase Tool Size</source>
        <translation>Zvětšit velikost nástroje</translation>
    </message>
    <message>
        <location filename="../../src/tools/sizeincrease/sizeincreasetool.cpp" line="47"/>
        <source>Increase the size of the other tools</source>
        <translation>Zvětšit velikost ostatních nástrojů</translation>
    </message>
</context>
<context>
    <name>SizeIndicatorTool</name>
    <message>
        <location filename="../../src/tools/sizeindicator/sizeindicatortool.cpp" line="23"/>
        <source>Selection Size Indicator</source>
        <translation>Ukazatel velikosti výběru</translation>
    </message>
    <message>
        <location filename="../../src/tools/sizeindicator/sizeindicatortool.cpp" line="33"/>
        <source>Show X and Y dimensions of the selection</source>
        <translation>Zobrazit rozměry X a Y výběru</translation>
    </message>
    <message>
        <source>Show the dimensions of the selection (X Y)</source>
        <translation type="vanished">Ukázat rozměry výběru (X Y)</translation>
    </message>
</context>
<context>
    <name>StrftimeChooserWidget</name>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="37"/>
        <source>Century (00-99)</source>
        <translation>Století (00-99)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="38"/>
        <source>Year (00-99)</source>
        <translation>Rok (00-99)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="39"/>
        <source>Year (2000)</source>
        <translation>Rok (2000)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="42"/>
        <source>Month Name (jan)</source>
        <translation>Název měsíce (led)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="43"/>
        <source>Month Name (january)</source>
        <translation>Název měsíce (leden)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="45"/>
        <source>Month (01-12)</source>
        <translation>Měsíc (01-12)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="46"/>
        <source>Week Day (1-7)</source>
        <translation>Den v týdnu (1-7)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="47"/>
        <source>Week (01-53)</source>
        <translation>Týden (01-53)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="50"/>
        <source>Day Name (mon)</source>
        <translation>Název dne (pon)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="51"/>
        <source>Day Name (monday)</source>
        <translation>Název dne (pondělí)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="53"/>
        <source>Day (01-31)</source>
        <translation>Den (01-31)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="54"/>
        <source>Day of Month (1-31)</source>
        <translation>Den v měsíci (1-31)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="55"/>
        <source>Day (001-366)</source>
        <translation>Den v roce (001-366)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="58"/>
        <source>Time (%H-%M-%S)</source>
        <translation>Čas (%H-%M-%S)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="59"/>
        <source>Time (%H-%M)</source>
        <translation>Čas (%H-%M)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="61"/>
        <source>Hour (00-23)</source>
        <translation>Hodina (00-23)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="62"/>
        <source>Hour (01-12)</source>
        <translation>Hodina (01-12)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="63"/>
        <source>Minute (00-59)</source>
        <translation>Minuta (00-59)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="64"/>
        <source>Second (00-59)</source>
        <translation>Sekunda (00-59)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="67"/>
        <source>Full Date (%m/%d/%y)</source>
        <translation>Celé datum (%m/%d/%y)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="69"/>
        <source>Full Date (%Y-%m-%d)</source>
        <translation>Celé datum (%Y-%m-%d)</translation>
    </message>
</context>
<context>
    <name>SystemNotification</name>
    <message>
        <location filename="../../src/utils/systemnotification.cpp" line="30"/>
        <source>Flameshot Info</source>
        <translation>Informace Flameshotu</translation>
    </message>
</context>
<context>
    <name>TextConfig</name>
    <message>
        <location filename="../../src/tools/text/textconfig.cpp" line="47"/>
        <source>StrikeOut</source>
        <translation>Přeškrtnutí</translation>
    </message>
    <message>
        <location filename="../../src/tools/text/textconfig.cpp" line="56"/>
        <source>Underline</source>
        <translation>Podtržení</translation>
    </message>
    <message>
        <location filename="../../src/tools/text/textconfig.cpp" line="65"/>
        <source>Bold</source>
        <translation>Tučné</translation>
    </message>
    <message>
        <location filename="../../src/tools/text/textconfig.cpp" line="74"/>
        <source>Italic</source>
        <translation>Kurzíva</translation>
    </message>
    <message>
        <location filename="../../src/tools/text/textconfig.cpp" line="84"/>
        <source>Left Align</source>
        <translation>Zarovnání vlevo</translation>
    </message>
    <message>
        <location filename="../../src/tools/text/textconfig.cpp" line="93"/>
        <source>Center Align</source>
        <translation>Zarovnání na střed</translation>
    </message>
    <message>
        <location filename="../../src/tools/text/textconfig.cpp" line="102"/>
        <source>Right Align</source>
        <translation>Zarovnání vpravo</translation>
    </message>
</context>
<context>
    <name>TextTool</name>
    <message>
        <location filename="../../src/tools/text/texttool.cpp" line="73"/>
        <source>Text</source>
        <translation>Text</translation>
    </message>
    <message>
        <location filename="../../src/tools/text/texttool.cpp" line="97"/>
        <source>Add text to your capture</source>
        <translation>Přidat text do zachyceného záběru</translation>
    </message>
</context>
<context>
    <name>UIcolorEditor</name>
    <message>
        <source>UI Color Editor</source>
        <translation type="vanished">Editor barvy rozhraní</translation>
    </message>
    <message>
        <location filename="../../src/config/uicoloreditor.cpp" line="88"/>
        <source>Change the color moving the selectors and see the changes in the preview buttons.</source>
        <translation>Měňte barvu pohybováním voličů a dívejte se na změny v náhledových tlačítcích.</translation>
    </message>
    <message>
        <location filename="../../src/config/uicoloreditor.cpp" line="99"/>
        <source>Select a Button to modify it</source>
        <translation>Vybrat tlačítko pro jeho změnění</translation>
    </message>
    <message>
        <location filename="../../src/config/uicoloreditor.cpp" line="109"/>
        <source>Main Color</source>
        <translation>Hlavní barva</translation>
    </message>
    <message>
        <location filename="../../src/config/uicoloreditor.cpp" line="113"/>
        <source>Click on this button to set the edition mode of the main color.</source>
        <translation>Klepněte na toto tlačítko pro stanovení režimu upravení hlavní barvy.</translation>
    </message>
    <message>
        <location filename="../../src/config/uicoloreditor.cpp" line="124"/>
        <source>Contrast Color</source>
        <translation>Kontrastní barva</translation>
    </message>
    <message>
        <location filename="../../src/config/uicoloreditor.cpp" line="129"/>
        <source>Click on this button to set the edition mode of the contrast color.</source>
        <translation>Klepněte na toto tlačítko pro stanovení režimu upravení kontrastní barvy.</translation>
    </message>
</context>
<context>
    <name>UndoTool</name>
    <message>
        <location filename="../../src/tools/undo/undotool.cpp" line="23"/>
        <source>Undo</source>
        <translation>Zpět</translation>
    </message>
    <message>
        <location filename="../../src/tools/undo/undotool.cpp" line="33"/>
        <source>Undo the last modification</source>
        <translation>Zrušit poslední změnu</translation>
    </message>
</context>
<context>
    <name>UpdateNotificationWidget</name>
    <message>
        <location filename="../../src/widgets/updatenotificationwidget.cpp" line="69"/>
        <source>New Flameshot version %1 is available</source>
        <translation>Je dostupná nová verze Flameshotu  %1</translation>
    </message>
    <message>
        <location filename="../../src/widgets/updatenotificationwidget.cpp" line="122"/>
        <source>Ignore</source>
        <translation>Přehlížet</translation>
    </message>
    <message>
        <location filename="../../src/widgets/updatenotificationwidget.cpp" line="130"/>
        <source>Later</source>
        <translation>Později</translation>
    </message>
    <message>
        <location filename="../../src/widgets/updatenotificationwidget.cpp" line="138"/>
        <source>Update</source>
        <translation>Aktualizovat</translation>
    </message>
</context>
<context>
    <name>UploadHistory</name>
    <message>
        <location filename="../../src/widgets/uploadhistory.ui" line="14"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_uploadhistory.h" line="67"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_uploadhistory.h" line="67"/>
        <source>Upload History</source>
        <translation>Historie nahrávání</translation>
    </message>
    <message>
        <location filename="../../src/widgets/uploadhistory.cpp" line="62"/>
        <source>Screenshots history is empty</source>
        <translation>Historie snímků obrazovky je prázdná</translation>
    </message>
</context>
<context>
    <name>UploadLineItem</name>
    <message>
        <location filename="../../src/widgets/uploadlineitem.ui" line="20"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_uploadlineitem.h" line="113"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_uploadlineitem.h" line="113"/>
        <source>Form</source>
        <translation>Formulář</translation>
    </message>
    <message>
        <location filename="../../src/widgets/uploadlineitem.ui" line="49"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_uploadlineitem.h" line="114"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_uploadlineitem.h" line="114"/>
        <source>TextLabel</source>
        <translation>Textový štítek</translation>
    </message>
    <message>
        <location filename="../../src/widgets/uploadlineitem.ui" line="82"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_uploadlineitem.h" line="115"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_uploadlineitem.h" line="115"/>
        <source>Copy URL</source>
        <translation>Kopírovat adresu (URL)</translation>
    </message>
    <message>
        <location filename="../../src/widgets/uploadlineitem.ui" line="95"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_uploadlineitem.h" line="116"/>
        <location filename="../../cmake-build-debug/src/flameshot_autogen/include/ui_uploadlineitem.h" line="116"/>
        <source>Open In Browser</source>
        <translation>Otevřít v prohlížeči</translation>
    </message>
    <message>
        <location filename="../../src/widgets/uploadlineitem.cpp" line="50"/>
        <source>Confirm to delete</source>
        <translation>Pro smazání potvrďte</translation>
    </message>
    <message>
        <location filename="../../src/widgets/uploadlineitem.cpp" line="51"/>
        <source>Are you sure you want to delete a screenshot from the latest uploads and server?</source>
        <translation>Opravdu chcete smazat snímek obrazovky z nejnověji nahraných souborů a serveru?</translation>
    </message>
</context>
<context>
    <name>UtilityPanel</name>
    <message>
        <location filename="../../src/widgets/panel/utilitypanel.cpp" line="190"/>
        <source>Close</source>
        <translation>Zavřít</translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/utilitypanel.cpp" line="200"/>
        <source>&lt;Empty&gt;</source>
        <translation>&lt;Prázdný&gt;</translation>
    </message>
</context>
<context>
    <name>VisualsEditor</name>
    <message>
        <location filename="../../src/config/visualseditor.cpp" line="41"/>
        <source>Opacity of area outside selection:</source>
        <translation>Neprůhlednost oblasti vně výběru:</translation>
    </message>
    <message>
        <location filename="../../src/config/visualseditor.cpp" line="68"/>
        <source>UI Color Editor</source>
        <translation>Editor barvy rozhraní</translation>
    </message>
    <message>
        <location filename="../../src/config/visualseditor.cpp" line="74"/>
        <source>Colorpicker Editor</source>
        <translation>Editor voliče barev</translation>
    </message>
    <message>
        <location filename="../../src/config/visualseditor.cpp" line="79"/>
        <source>Button Selection</source>
        <translation>Tlačítko výběru</translation>
    </message>
    <message>
        <location filename="../../src/config/visualseditor.cpp" line="85"/>
        <source>Select All</source>
        <translation>Vybrat vše</translation>
    </message>
</context>
<context>
    <name>color_widgets::ColorDialog</name>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_dialog.cpp" line="79"/>
        <source>Pick</source>
        <translation>Zvolit</translation>
    </message>
</context>
<context>
    <name>color_widgets::ColorPalette</name>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette.cpp" line="428"/>
        <source>Unnamed</source>
        <translation>Nepojmenovaná</translation>
    </message>
</context>
<context>
    <name>color_widgets::ColorPaletteModel</name>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_model.cpp" line="70"/>
        <source>Unnamed</source>
        <translation>Nepojmenovaná</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_model.cpp" line="144"/>
        <source>%1 (%2 colors)</source>
        <translation>%1 (%2 barev)</translation>
    </message>
</context>
<context>
    <name>color_widgets::ColorPaletteWidget</name>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.ui" line="59"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="209"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="209"/>
        <source>Open a new palette from file</source>
        <translation>Otevřít novou paletu ze souboru</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.ui" line="71"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="212"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="212"/>
        <source>Create a new palette</source>
        <translation>Vytvořit novou paletu</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.ui" line="83"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="215"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="215"/>
        <source>Duplicate the current palette</source>
        <translation>Zdvojit nynější paletu</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.ui" line="121"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="218"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="218"/>
        <source>Delete the current palette</source>
        <translation>Smazat nynější paletu</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.ui" line="133"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="221"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="221"/>
        <source>Revert changes to the current palette</source>
        <translation>Vrátit změny v nynější paletě</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.ui" line="145"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="224"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="224"/>
        <source>Save changes to the current palette</source>
        <translation>Uložit změny v nynější paletě</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.ui" line="170"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="227"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="227"/>
        <source>Add a color to the palette</source>
        <translation>Přidat barvu do palety</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.ui" line="182"/>
        <location filename="../../build/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="230"/>
        <location filename="../../cmake-build-debug/external/Qt-Color-Widgets/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="230"/>
        <source>Remove the selected color from the palette</source>
        <translation>Odstranit vybranou barvu z palety</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.cpp" line="186"/>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.cpp" line="201"/>
        <source>New Palette</source>
        <translation>Nová paleta</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.cpp" line="187"/>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.cpp" line="202"/>
        <source>Name</source>
        <translation>Název</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.cpp" line="228"/>
        <source>GIMP Palettes (*.gpl)</source>
        <translation>Palety GIMP (*.gpl)</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.cpp" line="229"/>
        <source>Palette Image (%1)</source>
        <translation>Obrázek palety (%1)</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.cpp" line="230"/>
        <source>All Files (*)</source>
        <translation>Všechny soubory (*)</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.cpp" line="231"/>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.cpp" line="244"/>
        <source>Open Palette</source>
        <translation>Otevřít paletu</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/color_palette_widget.cpp" line="245"/>
        <source>Failed to load the palette file
%1</source>
        <translation>Nepodařilo se nahrát soubor palety
%1</translation>
    </message>
</context>
<context>
    <name>color_widgets::GradientEditor</name>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/gradient_editor.cpp" line="335"/>
        <source>Add Color</source>
        <translation>Přidat barvu</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/gradient_editor.cpp" line="344"/>
        <source>Remove Color</source>
        <translation>Odstranit barvu</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/gradient_editor.cpp" line="352"/>
        <source>Edit Color...</source>
        <translation>Upravit barvu...</translation>
    </message>
</context>
<context>
    <name>color_widgets::GradientListModel</name>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/gradient_list_model.cpp" line="231"/>
        <source>%1 (%2 colors)</source>
        <translation>%1 (%2 barev)</translation>
    </message>
</context>
<context>
    <name>color_widgets::Swatch</name>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/swatch.cpp" line="824"/>
        <source>Clear Color</source>
        <translation>Smazat barvu</translation>
    </message>
    <message>
        <location filename="../../external/Qt-Color-Widgets/src/QtColorWidgets/swatch.cpp" line="833"/>
        <source>%1 (%2)</source>
        <translation>%1 (%2)</translation>
    </message>
</context>
</TS>
