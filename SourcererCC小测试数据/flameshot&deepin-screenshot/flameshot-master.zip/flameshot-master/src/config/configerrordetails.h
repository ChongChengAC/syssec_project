#include <QDialog>

#pragma once

class ConfigErrorDetails : public QDialog
{
public:
    ConfigErrorDetails(QWidget* parent = nullptr);
};
